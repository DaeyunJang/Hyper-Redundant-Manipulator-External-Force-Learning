"""Row-major, constant-memory XLSX output for large prediction tables.

``nullable_columns`` in table details is the explicit allowlist for missing
cells. Other NaN values, every infinity, and unsupported objects are errors.
The workbook always starts with readable ``_INFO`` and ``_FILES`` sheets.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
import numbers
from pathlib import Path
import re
import time
from typing import Any

import numpy as np
import pandas as pd
import xlsxwriter


MAX_EXCEL_ROWS = 1_048_576
MAX_EXCEL_COLUMNS = 16_384
MAX_CELL_CHARACTERS = 32_767
MAX_EXACT_INTEGER = 2 ** 53
_INVALID_SHEET_CHARACTERS = re.compile(r"[\[\]:*?/\\]")


def _check_text(value: str, context: str) -> str:
    if len(value) > MAX_CELL_CHARACTERS:
        raise ValueError(f"{context}: text exceeds Excel's {MAX_CELL_CHARACTERS}-character cell limit")
    return value


def _metadata_cell(value: Any, context: str) -> Any:
    """Convert descriptive metadata explicitly; never invoke formula parsing."""
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, Path):
        value = str(value)
    if value is None or isinstance(value, (str, bool, int, float)):
        if isinstance(value, str):
            return _check_text(value, context)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError(f"{context}: metadata numbers must be finite or explicitly None")
        if isinstance(value, int) and not isinstance(value, bool) and abs(value) > MAX_EXACT_INTEGER:
            # Metadata can contain nanosecond identities. Store these as literal
            # text; prediction-table numeric integers have a stricter contract.
            return str(value)
        return value
    if isinstance(value, (dict, list, tuple)):
        def convert(item):
            if isinstance(item, np.generic):
                return item.item()
            if isinstance(item, Path):
                return str(item)
            raise TypeError(f"Unsupported metadata object: {type(item).__name__}")
        return _check_text(json.dumps(value, ensure_ascii=False, allow_nan=False, default=convert), context)
    raise TypeError(f"{context}: unsupported metadata object {type(value).__name__}")


def _missing(value: Any) -> bool:
    return value is None or value is pd.NA or value is pd.NaT or (
        isinstance(value, numbers.Real) and not isinstance(value, numbers.Integral)
        and math.isnan(float(value))
    )


def _validate_table(frame: pd.DataFrame, details: dict) -> tuple[list[str], set[int]]:
    if not isinstance(frame, pd.DataFrame):
        raise TypeError("frame must be a pandas DataFrame")
    if len(frame) + 1 > MAX_EXCEL_ROWS:
        raise ValueError(f"Table has {len(frame)} data rows; at most {MAX_EXCEL_ROWS - 1} fit with its header")
    columns = frame.columns.tolist()
    if not columns or len(columns) > MAX_EXCEL_COLUMNS:
        raise ValueError(f"A table must contain 1..{MAX_EXCEL_COLUMNS} columns")
    if any(not isinstance(name, str) or not name for name in columns):
        raise ValueError("Table column names must be nonempty strings")
    if len(columns) != len(set(columns)):
        raise ValueError("Duplicate table column names are not allowed")
    for name in columns:
        _check_text(name, "column name")
    nullable = details.get("nullable_columns", [])
    if not isinstance(nullable, (list, tuple, set, frozenset)) or any(not isinstance(name, str) for name in nullable):
        raise ValueError("details['nullable_columns'] must be a collection of column names")
    unknown = set(nullable) - set(columns)
    if unknown:
        raise ValueError(f"Nullable columns not present in table: {sorted(unknown)}")
    nullable_indices = {index for index, name in enumerate(columns) if name in nullable}
    for index, name in enumerate(columns):
        series = frame.iloc[:, index]
        missing = series.isna().to_numpy(dtype=bool)
        if missing.any() and index not in nullable_indices:
            raise ValueError(f"Unexpected missing value in nonnullable column {name!r}")
        kind = series.dtype.kind
        present = series[~missing]
        if kind in "iuf":
            values = present.to_numpy()
            if not np.isfinite(values).all():
                raise ValueError(f"Infinity is not allowed in column {name!r}")
            if kind in "iu" and len(values) and (values.min() < -MAX_EXACT_INTEGER or values.max() > MAX_EXACT_INTEGER):
                raise ValueError(f"Integer in column {name!r} exceeds exact Excel numeric precision")
        elif kind == "b":
            continue
        elif kind in "OU" or isinstance(series.dtype, pd.StringDtype):
            for value in present:
                if isinstance(value, str):
                    _check_text(value, f"column {name!r}")
                elif isinstance(value, (bool, np.bool_)):
                    continue
                elif isinstance(value, numbers.Integral):
                    if abs(int(value)) > MAX_EXACT_INTEGER:
                        raise ValueError(f"Integer in column {name!r} exceeds exact Excel numeric precision")
                elif isinstance(value, numbers.Real):
                    if not math.isfinite(float(value)):
                        raise ValueError(f"Infinity is not allowed in column {name!r}")
                else:
                    raise TypeError(f"Unsupported {type(value).__name__} in column {name!r}; convert it explicitly")
        else:
            raise TypeError(f"Unsupported dtype {series.dtype} in column {name!r}; convert it explicitly")
    return columns, nullable_indices


class WorkbookWriter:
    """Write a new XLSX file without retaining millions of cells in memory.

    ``write_table`` returns a manifest with ``sheet``, integer ``rows``, ordered
    ``columns``, ``column_count``, missing-cell counts, and write duration. Numeric
    values use Excel's general format; no application-level rounding is applied.
    Existing paths are rejected atomically, including existing symlinks.
    """

    def __init__(self, path: str | Path, metadata: dict, files: list[dict]):
        if not isinstance(metadata, dict) or not isinstance(files, list) or any(not isinstance(item, dict) for item in files):
            raise TypeError("metadata must be a dict and files must be a list of dicts")
        self.path = Path(path)
        self._closed = False
        self._failure = None
        self._sheet_names = {"_info", "_files"}
        self._tables = []
        # Validate descriptive cells before creating the destination.
        prepared_metadata = [(str(key), _metadata_cell(value, f"metadata {key!r}")) for key, value in metadata.items()]
        file_columns = list(dict.fromkeys(str(key) for item in files for key in item))
        if not file_columns:
            file_columns = ["file_id", "source_file"]
        if len(files) + 1 > MAX_EXCEL_ROWS or len(file_columns) > MAX_EXCEL_COLUMNS:
            raise ValueError("File manifest exceeds Excel worksheet dimensions")
        prepared_files = [[_metadata_cell(item.get(key), f"file metadata {key!r}") for key in file_columns] for item in files]
        for key, _ in prepared_metadata:
            _check_text(key, "metadata key")
        for key in file_columns:
            _check_text(key, "file metadata key")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.path.open("xb")
        try:
            self._book = xlsxwriter.Workbook(self._handle, {
                "constant_memory": True,
                "strings_to_formulas": False,
                "strings_to_urls": False,
                "strings_to_numbers": False,
                "nan_inf_to_errors": False,
            })
            self._book.use_zip64()
            self._header = self._book.add_format({"bold": True, "bg_color": "#E5EDF5", "bottom": 1})
            self._info = self._book.add_worksheet("_INFO")
            self._info.write_row(0, 0, ["section", "key", "value"], self._header)
            self._info.freeze_panes(1, 0)
            self._info.set_column(0, 0, 22)
            self._info.set_column(1, 1, 32)
            self._info.set_column(2, 2, 100)
            self._info_row = 1
            self._info_entry("workbook", "created_utc", datetime.now(timezone.utc).isoformat())
            self._info_entry("workbook", "file_mapping", "file_id values map to sources in the _FILES sheet")
            self._info_entry("workbook", "number_storage", "Numeric values are not rounded by this writer; Excel uses double-precision numeric cells.")
            for key, value in prepared_metadata:
                self._info_entry("metadata", key, value)
            worksheet = self._book.add_worksheet("_FILES")
            worksheet.write_row(0, 0, file_columns, self._header)
            worksheet.freeze_panes(1, 0)
            for column, name in enumerate(file_columns):
                width = 80 if any(token in name.lower() for token in ("path", "file")) and name != "file_id" else 20
                if "sha256" in name.lower() or "hash" in name.lower():
                    width = 66
                worksheet.set_column(column, column, max(width, min(len(name) + 2, 35)))
            for row, values in enumerate(prepared_files, start=1):
                worksheet.write_row(row, 0, values)
            worksheet.autofilter(0, 0, len(prepared_files), len(file_columns) - 1)
        except BaseException:
            self._handle.close()
            raise

    def _info_entry(self, section: str, key: str, value: Any) -> None:
        if self._info_row >= MAX_EXCEL_ROWS:
            raise ValueError("_INFO metadata exceeds Excel row limit")
        self._info.write_row(self._info_row, 0, [section, key, _metadata_cell(value, key)])
        self._info_row += 1

    def write_table(self, sheet_name: str, frame: pd.DataFrame, details: dict | None = None) -> dict:
        if self._closed:
            raise ValueError("Workbook is already closed")
        if self._failure is not None:
            raise ValueError("Workbook has a previous write failure")
        if not isinstance(sheet_name, str) or not sheet_name.strip() or len(sheet_name) > 31:
            raise ValueError("Sheet name must be nonempty and at most 31 characters")
        if _INVALID_SHEET_CHARACTERS.search(sheet_name) or sheet_name.startswith("'") or sheet_name.endswith("'"):
            raise ValueError(f"Invalid Excel sheet name: {sheet_name!r}")
        if sheet_name.casefold() in self._sheet_names:
            raise ValueError(f"Duplicate or reserved sheet name: {sheet_name!r}")
        details = {} if details is None else details
        if not isinstance(details, dict):
            raise TypeError("details must be a dict")
        columns, nullable = _validate_table(frame, details)
        # Details are checked before any data sheet is created.
        detail_cells = [(str(key), _metadata_cell(value, f"table detail {key!r}")) for key, value in details.items()]
        worksheet = self._book.add_worksheet(sheet_name)
        if not self._tables:
            worksheet.activate()
            worksheet.set_first_sheet()
        self._sheet_names.add(sheet_name.casefold())
        worksheet.write_row(0, 0, columns, self._header)
        worksheet.freeze_panes(1, 0)
        for column, name in enumerate(columns):
            width = max(12, min(30, len(name) + 2))
            worksheet.set_column(column, column, width)
        worksheet.autofilter(0, 0, len(frame), len(columns) - 1)
        null_counts = {columns[index]: int(frame.iloc[:, index].isna().sum()) for index in sorted(nullable)}
        started = time.perf_counter()
        try:
            # Pandas.to_excel writes column-major and silently loses cells in
            # constant-memory mode. Row-major iteration is essential here.
            for row_index, values in enumerate(frame.itertuples(index=False, name=None), start=1):
                if nullable:
                    values = list(values)
                    for column in nullable:
                        if _missing(values[column]):
                            values[column] = None
                result = worksheet.write_row(row_index, 0, values)
                if result != 0:
                    raise ValueError(f"Excel write failed for sheet {sheet_name!r}, row {row_index}: code {result}")
            manifest = {"sheet": sheet_name, "rows": len(frame), "columns": columns,
                        "column_count": len(columns), "null_counts": null_counts,
                        "elapsed_seconds": time.perf_counter() - started}
            self._tables.append(manifest)
            self._info_entry("table", sheet_name, manifest)
            for key, value in detail_cells:
                self._info_entry(sheet_name, key, value)
            return manifest
        except BaseException as error:
            self._failure = f"{type(error).__name__}: {error}"
            raise

    def close(self) -> None:
        if self._closed:
            return
        try:
            self._info_entry("workbook", "status", "failed" if self._failure else "complete")
            if self._failure:
                self._info_entry("workbook", "error", self._failure)
            self._info_entry("workbook", "table_count", len(self._tables))
            self._info.autofilter(0, 0, self._info_row - 1, 2)
            self._book.close()
        finally:
            self._handle.close()
            self._closed = True

    def __enter__(self):
        if self._closed:
            raise ValueError("Workbook is already closed")
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        if exception_value is not None:
            self._failure = f"{exception_type.__name__}: {exception_value}"
        self.close()
        return False


__all__ = ["WorkbookWriter"]
