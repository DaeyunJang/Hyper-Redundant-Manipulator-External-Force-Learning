"""Assemble aligned spreadsheet rows without changing predictions or targets.

References address loaded trial positions, mapped back to source CSV rows. These helpers preserve their
order and fail on invalid references / predictions instead of dropping rows.
The caller chooses the split, force scope, and whether uncertain ID truth is
exported. No split, load-state filter, or model selection happens here.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .independent_evaluation import location_predictions


def _row_refs(refs: Any, trial_count: int) -> np.ndarray:
    values = np.asarray(refs)
    if values.ndim != 2 or values.shape[1] != 2:
        raise ValueError("refs must have shape (N, 2): trial index, original row")
    if values.dtype.kind not in "iu" or values.dtype.kind == "b":
        raise ValueError("refs must contain integer indices")
    if np.any(values < 0) or np.any(values[:, 0] >= trial_count):
        raise ValueError("refs contain an out-of-range trial or negative row")
    if values.dtype.kind == "u" and np.any(values > np.iinfo(np.int64).max):
        raise ValueError("refs indices exceed int64 range")
    return values.astype(np.int64, copy=False)


def _median_dt_ns(trial: Any) -> float:
    median = trial.info.get("median_dt_ms")
    if median is not None:
        median = float(median) * 1e6
        if not np.isfinite(median) or median <= 0:
            raise ValueError("trial median_dt_ms must be finite and positive")
        return median
    delta = np.diff(np.asarray(trial.timestamps))
    positive = delta[np.isfinite(delta) & (delta > 0)]
    return float(np.median(positive)) if len(positive) else float("inf")


def _base_table(
    trials: Sequence[Any], refs: Any, *, gap_factor: float,
    window_samples: int | None,
) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    references = _row_refs(refs, len(trials))
    if not np.isfinite(gap_factor) or gap_factor <= 0:
        raise ValueError("gap_factor must be finite and positive")
    if window_samples is not None and (
        isinstance(window_samples, (bool, np.bool_))
        or not isinstance(window_samples, (int, np.integer))
        or window_samples < 1
    ):
        raise ValueError("window_samples must be a positive integer")
    count = len(references)
    files = np.empty(count, dtype=object)
    timestamps = np.empty(count, dtype=np.float64)
    limits = np.empty(count, dtype=np.float64)
    states = np.empty(count, dtype=np.int8)
    original_ids = np.empty(count, dtype=np.int64)
    effective_ids = np.empty(count, dtype=np.int64)
    targets = np.empty((count, 3), dtype=np.float64)
    source_rows = np.empty(count, dtype=np.int64)
    timestamp_available = np.ones(count, dtype=bool)

    for trial_index in np.unique(references[:, 0]):
        trial = trials[int(trial_index)]
        positions = np.flatnonzero(references[:, 0] == trial_index)
        rows = references[positions, 1]
        original_rows = getattr(trial, 'source_rows', None)
        force = np.asarray(trial.force)
        inputs = np.asarray(trial.x)
        times = np.asarray(trial.timestamps)
        if force.ndim != 2 or force.shape[1] != 3 or inputs.ndim != 2:
            raise ValueError("Trial force and input arrays must have shape (rows, 3 / features)")
        size = len(force)
        if len(inputs) != size or times.shape != (size,) or np.any(rows >= size):
            raise ValueError("refs row is out of range or trial arrays are misaligned")
        source_rows[positions] = original_rows[rows] if original_rows is not None else rows
        timestamp_available[positions] = trial.info.get('timestamps_available', True)
        input_valid = np.asarray(trial.input_valid, dtype=bool)
        force_valid = np.asarray(trial.force_valid, dtype=bool)
        load_state = np.asarray(trial.load_state)
        if any(values.shape != (size,) for values in (input_valid, force_valid, load_state)):
            raise ValueError("Trial flags / load_state must align with original rows")
        if not np.isin(rows, np.asarray(trial.endpoints)).all():
            raise ValueError("Every ref must belong to trial.endpoints (valid supervised windows)")
        if not (
            input_valid[rows].all() and force_valid[rows].all()
            and np.isfinite(inputs[rows]).all() and np.isfinite(force[rows]).all()
            and np.isfinite(times[rows]).all()
        ):
            raise ValueError("Selected refs contain invalid flags, inputs, targets, or timestamps")
        if not np.isin(load_state[rows], [-1, 0, 1]).all():
            raise ValueError("Selected refs must have loaded, unloaded, or uncertain state")
        median = _median_dt_ns(trial)
        if window_samples is not None:
            starts = rows - window_samples + 1
            if np.any(starts < 0):
                raise ValueError("Selected refs have insufficient window history")
            valid = (
                input_valid & force_valid & np.isfinite(inputs).all(axis=1)
                & np.isfinite(force).all(axis=1) & np.isfinite(times)
            )
            invalid_prefix = np.r_[0, np.cumsum(~valid, dtype=np.int64)]
            if np.any(invalid_prefix[rows + 1] - invalid_prefix[starts]):
                raise ValueError("Selected window history contains invalid input / target rows")
            delta = np.diff(times)
            breaks = np.r_[False, ~np.isfinite(delta) | (delta <= 0) | (delta > median * gap_factor)]
            break_prefix = np.r_[0, np.cumsum(breaks, dtype=np.int64)]
            if trial.info.get('preprocessing') != 'numeric_compact' and np.any(break_prefix[rows + 1] - break_prefix[starts + 1]):
                raise ValueError("Selected window history crosses a timestamp boundary")
        if int(trial.effective_id) not in range(1, 19):
            raise ValueError("effective_id must be a segment ID in 1..18")
        files[positions] = Path(trial.path).name
        timestamps[positions] = times[rows]
        limits[positions] = median * gap_factor
        states[positions] = load_state[rows]
        original_ids[positions] = trial.segment_id_raw
        effective_ids[positions] = trial.effective_id
        targets[positions] = force[rows]

    new_block = np.ones(count, dtype=bool)
    if count > 1:
        delta = np.diff(timestamps)
        new_block[1:] = (
            (references[1:, 0] != references[:-1, 0])
            | (np.diff(source_rows) != 1)
            | (timestamp_available[1:] & timestamp_available[:-1] & ((delta <= 0) | (delta > limits[1:])))
        )
    state_labels = np.empty(count, dtype=object)
    for value, label in ((-1, "uncertain"), (0, "unloaded"), (1, "loaded")):
        state_labels[states == value] = label
    table = pd.DataFrame({
        "source_file": files,
        "source_row": source_rows,
        "elapsed_s": np.where(timestamp_available, timestamps / 1e9, np.nan),
        "continuous_block": np.cumsum(new_block, dtype=np.int64),
        "load_state": state_labels,
        "contact_id_original": original_ids,
        "contact_id_effective": effective_ids,
    })
    table.attrs.update({
        "source_row_basis": "zero-based original CSV data row, excluding header",
        "elapsed_s_basis": "trial relative timestamp in nanoseconds divided by 1e9; blank when unavailable",
        "continuous_block_basis": (
            "1-based; new trial, nonadjacent original row, nonincreasing timestamp, "
            "or timestamp gap > median_dt_ms * gap_factor"
        ),
        "gap_factor": float(gap_factor),
        "window_samples_revalidated": window_samples,
        "row_selection": "provided refs; all must be valid supervised trial.endpoints; no rows dropped",
    })
    return table, targets, states


def force_table(
    trials: Sequence[Any], refs: Any, predictions_N: Any, *,
    gap_factor: float = 1.5, window_samples: int | None = None,
) -> pd.DataFrame:
    """Return GT and raw continuous predicted XYZ in mN, including uncertain rows.

    Conversion uses float64 before multiplying by 1000, matching the metrics
    contract. No sign inversion, load-based zeroing, or force-scope filtering
    occurs. ``window_samples`` optionally revalidates every history row in
    addition to the mandatory saved endpoint and current endpoint checks.
    """
    table, targets, _ = _base_table(
        trials, refs, gap_factor=gap_factor, window_samples=window_samples,
    )
    prediction = np.asarray(predictions_N, dtype=np.float64)
    if prediction.shape != targets.shape:
        raise ValueError("Force predictions must have shape (len(refs), 3)")
    if not np.isfinite(prediction).all():
        raise ValueError("Nonfinite force prediction on a valid export row")
    for index, axis in enumerate(("fx", "fy", "fz")):
        table[f"gt_{axis}_mN"] = targets[:, index] * 1000.0
    for index, axis in enumerate(("fx", "fy", "fz")):
        table[f"pred_{axis}_mN"] = prediction[:, index] * 1000.0
    table.attrs.update({
        "force_unit": "mN",
        "force_sign": "recorded aligned force sign; no controller sign inversion",
        "prediction_semantics": "raw inverse-scaled continuous XYZ, without no-load zeroing",
    })
    return table


def id_table(
    trials: Sequence[Any], refs: Any, probabilities: Any, mode: str,
    active_ids: Sequence[int], *, gap_factor: float = 1.5,
    include_p0: bool = False, window_samples: int | None = None,
) -> pd.DataFrame:
    """Decode ID predictions without consulting ground-truth load state.

    GT is effective ID for loaded rows, zero for unloaded rows, and NaN for
    uncertain rows. Masked ``pred_id`` is conditional contact location on every
    row; its operational ID is unavailable. Class0 ``pred_id`` is the full
    argmax including zero. Location accuracy for masked models is meaningful
    only on supported, ground-truth loaded rows.
    """
    table, _, states = _base_table(
        trials, refs, gap_factor=gap_factor, window_samples=window_samples,
    )
    probability = np.asarray(probabilities)
    if probability.ndim != 2 or len(probability) != len(table):
        raise ValueError("Location probabilities must have one row per ref")
    decoded = location_predictions(probability, mode, active_ids)
    truth = np.full(len(table), np.nan)
    truth[states == 0] = 0
    truth[states == 1] = table.loc[states == 1, "contact_id_effective"]
    table["ground_truth_id"] = truth
    table["pred_id"] = decoded["final_id"] if mode == "class0" else decoded["conditional_id"]
    table["pred_id_conditional"] = decoded["conditional_id"]
    table["pred_id_operational"] = decoded["final_id"]
    if include_p0 and mode == "class0":
        table["pred_no_load_probability"] = decoded["no_load_probability"]
    table.attrs.update({
        "mode": mode,
        "active_ids": [int(value) for value in active_ids],
        "ground_truth_id_semantics": "loaded=effective ID; unloaded=0; uncertain=blank",
        "prediction_semantics": (
            "full class argmax including no-load 0" if mode == "class0" else
            "conditional contact ID on every row; no no-load detector; operational ID unavailable"
        ),
        "conditional_location_metric_scope": "GT loaded rows whose effective ID is in active_ids",
        "ground_truth_used_for_prediction": False,
    })
    return table
