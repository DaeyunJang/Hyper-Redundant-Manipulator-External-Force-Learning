"""Select a project-local NVIDIA library matching the already loaded kernel.

No kernel modules or system packages are changed. After a system driver restart,
the shim is automatically bypassed if the installed driver is already consistent.
"""
import os
import re
import sys
from pathlib import Path


def ensure_driver_runtime():
    root = Path(__file__).resolve().parents[1]
    version_file = Path('/proc/driver/nvidia/version')
    if not version_file.exists():
        return
    match = re.search(r'\b(\d{3}\.\d+\.\d+)\b', version_file.read_text())
    if not match:
        return
    version = match.group(1)
    local = root / '.runtime' / ('nvidia-' + version)
    system = Path('/usr/lib/x86_64-linux-gnu/libcuda.so.1')
    if system.exists() and system.resolve().name == 'libcuda.so.' + version:
        return
    if not (local / 'libcuda.so.1').exists() or os.environ.get('HRM_DRIVER_RUNTIME') == version:
        return
    env = dict(os.environ)
    env['LD_LIBRARY_PATH'] = str(local) + (':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    env['HRM_DRIVER_RUNTIME'] = version
    os.execve(sys.executable, [sys.executable, *sys.argv], env)
