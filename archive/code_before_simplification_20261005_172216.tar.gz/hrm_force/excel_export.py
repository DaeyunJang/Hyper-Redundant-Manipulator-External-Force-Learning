"""Replay frozen independent branches into one worksheet per architecture."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import pandas as pd
import torch

from .data import ROOT, sha256
from .independent_data import load_trial, trial_endpoints
from .independent_engine import WindowStore, predict_branch, restore_bundle, write_json
from .excel_tables import force_table, id_table
from .excel_writer import WorkbookWriter


SHEET_NAMES = {
    'mlp': 'MLP', 'cnn': 'CNN', 'convmixer': 'ConvMixer', 'resnet': 'ResNet',
    'lstm': 'LSTM', 'gru': 'GRU', 'tcn': 'TCN', 'transformer': 'Transformer',
    'kalmannet': 'KalmanNet', 'small_gru': 'Small_GRU', 'residual_tcn': 'Residual_TCN',
}
KEY_COLUMNS = ['file_id', 'source_row', 'elapsed_s', 'continuous_block', 'load_state']
FORCE_COLUMNS = [f'{prefix}_{axis}_mN' for prefix in ('gt', 'pred') for axis in ('fx', 'fy', 'fz')]
ID_COLUMNS = ['ground_truth_id', 'pred_id', 'contact_id_effective']


def checkpoint_path(train_dir, mode, force, location):
    return Path(train_dir) / 'models' / f'{mode}__force_{force}__location_{location}' / 'hrm_bundle.pt'


def _signature(bundle):
    return {
        'feature_columns': bundle['feature_columns'], 'split': bundle['split'],
        'trials': [(x['path'], x['sha256'], x['is_tip']) for x in bundle['data_audit']['trials']],
        'config': bundle['config'], 'calibration': bundle['calibration'],
        'force_scope': bundle['force_scope'], 'force_unit': bundle['force_unit'],
    }


def _public_frame(frame, file_ids, branch):
    identifiers = frame['source_file'].map(file_ids)
    if identifiers.isna().any():
        raise ValueError('Unknown or ambiguous source basename in an export table')
    frame = frame.copy(deep=False)
    frame['file_id'] = identifiers.astype(np.int64)
    columns = FORCE_COLUMNS if branch == 'force' else ID_COLUMNS
    return frame[columns + KEY_COLUMNS]


def _refs(trials, indices, branch, scope, role=None):
    pieces = []
    for index in indices:
        trial = trials[index]
        if branch == 'force' and scope == 'tip' and not trial.is_tip:
            continue
        ends = trial_endpoints(trial, role)
        pieces.append(np.column_stack((np.full(len(ends), index, dtype=np.int64), ends)))
    if not pieces:
        raise ValueError(f'No eligible {branch} trials')
    refs = np.concatenate(pieces)
    if not len(refs):
        raise ValueError(f'No eligible {branch} endpoints')
    return refs


def _states(trials, refs):
    result = np.empty(len(refs), dtype=np.int64)
    for index in np.unique(refs[:, 0]):
        mask = refs[:, 0] == index
        result[mask] = trials[index].load_state[refs[mask, 1]]
    return result


def _cohort_digest(refs):
    return hashlib.sha256(np.asarray(refs, dtype='<i8').tobytes()).hexdigest()


def export_workbooks(train_dir, roles=('train', 'validation', 'test'), models=None,
                     train_output=None, predict_output=None, device=None):
    start = time.perf_counter()
    train_dir = Path(train_dir).resolve()
    reference_path = next((path for mode in ('masked', 'class0')
                           if (path := checkpoint_path(train_dir, mode, 'mlp', 'mlp')).is_file()), None)
    if reference_path is None:
        raise ValueError('Excel export requires a trained MLP/MLP reference bundle in masked or class0 mode')
    reference = torch.load(reference_path, map_location='cpu', weights_only=True)
    if reference.get('kind') != 'independent_hrm':
        raise ValueError('This exporter requires frozen independent HRM bundles')
    cfg, split = reference['config'], reference['split']
    force_mode = reference['mode']
    location_modes = [mode for mode in ('masked', 'class0') if mode in cfg['no_load_modes']]
    roles = list(roles)
    if not roles or len(set(roles)) != len(roles) or set(roles) - set(split):
        raise ValueError('Roles must be distinct train/validation/test names')
    if models and (len(set(models)) != len(models) or set(models) - set(SHEET_NAMES)):
        raise ValueError('Invalid or duplicate model names')
    force_names = [x for x in cfg['force_candidates'] if not models or x in models]
    location_names = [x for x in cfg['location_candidates'] if not models or x in models]
    if not force_names or not location_names:
        raise ValueError('No requested frozen architectures')
    device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
    run_name = datetime.now().strftime('%Y%m%d_%H%M%S') + '_excel'
    destinations = {}
    if set(roles) & {'train', 'validation'}:
        folder = Path(train_output) if train_output else ROOT / 'results/train' / run_name
        folder.mkdir(parents=True, exist_ok=False)
        destinations['development'] = folder.resolve()
    if 'test' in roles:
        folder = Path(predict_output) if predict_output else ROOT / 'results/predict' / run_name
        folder.mkdir(parents=True, exist_ok=False)
        destinations['test'] = folder.resolve()
    print('Excel destinations: ' + ', '.join(str(p) for p in destinations.values()), flush=True)
    manifest = {
        'created_at': datetime.now().isoformat(), 'status': 'running',
        'source_training_run': str(train_dir), 'device': device,
        'force_unit': 'mN', 'frame': 'hrm_base', 'training_sign_retained': True,
        'control_minus_one_applied': False, 'new_training': False,
        'previous_model_selection_changed': False,
        'representative_policy': {
            'force': f'{force_mode}__force_MODEL__location_mlp; one fixed partner, not best-test selection',
            'location': 'MODE__force_mlp__location_MODEL; one fixed partner, not best-test selection',
            'reason': 'Branches are independent. Same seed/configuration repetitions can differ slightly under CUDA; each exact bundle is identified.'},
        'force_row_policy': 'Common history endpoints under the saved preprocessing policy, including loaded/unloaded/uncertain; verified force scope only.',
        'id_row_policy': 'Common valid history endpoints with known load state 0 or 1; uncertain GT omitted for every model/mode. Predictions never use GT as a gate.',
        'role_notes': {'train': 'In-sample replay; not generalization performance.',
                       'validation': 'Frozen development validation partition (file or per-file tail as configured); saved validation predictions reused.',
                       'test': 'Frozen test CSVs; all architectures replayed for requested analysis, not model selection.'},
        'workbooks': [], 'sources': [], 'completed_sheets': 0,
        'preprocessing': cfg.get('preprocessing', 'audited'),
        'validation_strategy': cfg.get('validation_strategy', 'whole_csv'),
        'test_evaluation_scope': cfg.get('test_evaluation_scope', 'historical_held_out_recordings'),
    }

    def save_progress():
        for folder in destinations.values():
            write_json(folder / 'export_manifest.json', manifest)

    save_progress()
    writers = []
    try:
        known = reference['data_audit']['trials']
        needed = sorted(set(i for role in roles for i in split[role]))
        trials = [None] * len(known)
        for index in needed:
            info = known[index]
            trial = load_trial(Path(info['path']), cfg, reference['calibration'], require_targets=True)
            if 'role_rows' in info:
                trial.info['role_rows'] = info['role_rows']
            if (trial.sha256 != info['sha256'] or len(trial.x) != info['rows']
                    or trial.is_tip != info['is_tip'] or len(trial.endpoints) != info['window_endpoints']):
                raise ValueError(f'Frozen source/endpoint contract changed: {trial.path}')
            trials[index] = trial
        basenames = [Path(known[i]['path']).name for i in needed]
        if len(set(basenames)) != len(basenames):
            raise ValueError('Duplicate source basenames require disambiguation')
        file_ids = {Path(known[i]['path']).name: i + 1 for i in needed}
        manifest['sources'] = [
            {'file_id': i + 1, 'source_file': Path(known[i]['path']).name,
             'path': known[i]['path'], 'sha256': known[i]['sha256'],
             'rows': known[i]['rows'], 'contact_id_original': known[i]['segment_id_raw'],
             'contact_id_effective': known[i]['effective_id'], 'is_tip': known[i]['is_tip']}
            for i in needed]
        common = {}
        for role in roles:
            for branch in ('force', 'location'):
                refs = _refs(trials, split[role], branch, reference['force_scope'], role)
                keep = np.ones(len(refs), dtype=bool) if branch == 'force' else np.isin(_states(trials, refs), [0, 1])
                common[role, branch] = (refs, keep)
        workbook_map = {}
        for role in roles:
            parent = destinations['test'] if role == 'test' else destinations['development'] / role
            parent.mkdir(parents=True, exist_ok=True)
            for branch, mode in [('force', force_mode)] + [('location', mode) for mode in location_modes]:
                name = 'force_estimation_all_models.xlsx' if branch == 'force' else f'id_estimation_{mode}.xlsx'
                refs, keep = common[role, branch]
                role_file_ids = sorted(set((refs[keep, 0] + 1).tolist()))
                metadata = {
                    'dataset_role': role, 'branch': branch, 'mode': mode,
                    'data_rows_per_model': int(keep.sum()), 'units': 'mN for all force columns; seconds for elapsed_s',
                    'source_row': 'Zero-based original CSV data-row index; source CSV itself is unchanged.',
                    'file_id': 'See _FILES. Numeric IDs keep MATLAB imports compact; they are not neural network inputs.',
                    'continuous_block': 'Do not connect across block changes. File changes, removed rows and time gaps start a new block.',
                    'ground_truth_id': 'Loaded: effective contact ID; unloaded: 0. Uncertain load rows excluded from ID sheets.',
                    'pred_id': 'Conditional segment argmax; no unload detector, never GT-gated.' if mode == 'masked'
                               else f'Argmax over trained classes {[0] + list(cfg["active_ids"])}; 0 is the learned no-load class.',
                    'active_segment_ids': cfg['active_ids'],
                    'masked_comparison': 'For loaded-conditional ID accuracy, use load_state=loaded; unloaded masked predictions do not constitute a load detector.',
                    'force_scope': reference['force_scope'],
                    'role_interpretation': manifest['role_notes'][role],
                    'representative_policy': manifest['representative_policy'][branch if branch == 'force' else 'location'],
                    'source_training_run': str(train_dir),
                    'force_transform': 'Inverse training target scaling, N to mN only; no forced zeros, no control sign inversion.',
                }
                writer = WorkbookWriter(parent / name, metadata, [x for x in manifest['sources'] if x['file_id'] in role_file_ids])
                writers.append(writer)
                entry = {'role': role, 'branch': branch, 'mode': mode, 'path': str(parent / name),
                         'rows_per_model': int(keep.sum()), 'cohort_sha256': _cohort_digest(refs[keep]),
                         'valid_history_endpoints_before_label_filter': len(refs),
                         'uncertain_rows_removed': int((~keep).sum()), 'sheets': []}
                workbook_map[role, branch, mode] = (writer, entry)
                manifest['workbooks'].append(entry)
        signature = _signature(reference)
        jobs = [('force', force_mode, name) for name in force_names]
        jobs += [('location', mode, name) for mode in location_modes for name in location_names]
        for job_index, (branch, mode, name) in enumerate(jobs, 1):
            checkpoint = checkpoint_path(train_dir, mode, name if branch == 'force' else 'mlp',
                                         'mlp' if branch == 'force' else name)
            model, bundle = restore_bundle(checkpoint, device)
            if _signature(bundle) != signature:
                raise ValueError(f'Inconsistent frozen contract: {checkpoint}')
            network = model.force_net if branch == 'force' else model.location_net
            scaler = {k: np.asarray(v) for k, v in bundle['scalers'][branch].items()}
            print(f'[{job_index}/{len(jobs)}] {branch}/{mode}/{name}', flush=True)
            for role in roles:
                refs, keep = common[role, branch]
                if role == 'validation':
                    with np.load(checkpoint.parent / 'validation_predictions.npz', allow_pickle=False) as cached:
                        ref_name = 'force_refs' if branch == 'force' else 'location_refs'
                        value_name = 'force_N' if branch == 'force' else 'location_probabilities'
                        if not np.array_equal(cached[ref_name], refs):
                            raise ValueError('Saved validation row references differ from the frozen cohort')
                        prediction = cached[value_name]
                    origin = 'saved_validation_predictions'
                else:
                    store = WindowStore(trials, split[role], scaler, cfg, device, branch, mode, prediction=False, role=role)
                    if not np.array_equal(np.asarray(store.refs), refs):
                        raise ValueError('Inference row references differ across models')
                    prediction = predict_branch(network, store, cfg['batch_size'])
                    del store
                    origin = 'replay_of_frozen_best_branch'
                if not np.isfinite(prediction).all():
                    raise ValueError('A model produced nonfinite values on the common cohort')
                kwargs = {'gap_factor': cfg['gap_factor'], 'window_samples': cfg['window_samples']}
                table = (force_table(trials, refs, prediction, **kwargs) if branch == 'force' else
                         id_table(trials, refs[keep], prediction[keep], mode, cfg['active_ids'], **kwargs))
                frame = _public_frame(table, file_ids, branch)
                if len(frame) != int(keep.sum()):
                    raise ValueError('Unexpected exported row count')
                writer, entry = workbook_map[role, branch, mode]
                details = {
                    'architecture': name, 'bundle': str(checkpoint), 'bundle_sha256': sha256(checkpoint),
                    'prediction_origin': origin, 'cohort_sha256': entry['cohort_sha256'],
                    'seed': bundle['training'][branch]['seed'],
                    'best_epoch': bundle['training'][branch]['best_epoch'], 'nullable_columns': ['elapsed_s'],
                }
                sheet = writer.write_table(SHEET_NAMES[name], frame, details)
                entry['sheets'].append(sheet)
                manifest['completed_sheets'] += 1
                save_progress()
                print(f'  {role}: {len(frame):,} rows -> {SHEET_NAMES[name]}', flush=True)
                del prediction, table, frame
            del model
        for writer in writers:
            writer.close()
        writers.clear()
        for entry in manifest['workbooks']:
            path = Path(entry['path'])
            entry.update(bytes=path.stat().st_size, sha256=sha256(path))
        # Verify source hashes again after replay. Original CSVs were only read.
        for item in manifest['sources']:
            if sha256(Path(item['path'])) != item['sha256']:
                raise ValueError('A source CSV changed during export')
        manifest.update(status='complete', completed_at=datetime.now().isoformat(),
                        elapsed_seconds=time.perf_counter() - start, source_hashes_unchanged=True)
        save_progress()
        print('Excel export complete: ' + ', '.join(str(p) for p in destinations.values()), flush=True)
        return destinations
    except BaseException as error:
        manifest.update(status='failed', error=repr(error))
        save_progress()
        for writer in writers:
            try:
                writer.close()
            except Exception:
                pass
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--train-dir', required=True)
    parser.add_argument('--roles', nargs='+', default=['train', 'validation', 'test'], choices=['train', 'validation', 'test'])
    parser.add_argument('--models', nargs='+', choices=list(SHEET_NAMES))
    parser.add_argument('--train-output')
    parser.add_argument('--predict-output')
    parser.add_argument('--device', choices=['cpu', 'cuda'])
    args = parser.parse_args(argv)
    export_workbooks(args.train_dir, args.roles, args.models, args.train_output, args.predict_output, args.device)
