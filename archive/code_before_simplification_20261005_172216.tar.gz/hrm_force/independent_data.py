"""Read-only CSV loading, frozen file/row splits, and no-load calibration.

Audited legacy loading breaks windows at invalid rows; numeric_compact drops
nonfinite selected X/Y rows and joins the remaining rows inside each role.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
import argparse
import csv
import json
import math
import re

import numpy as np
import pandas as pd
import yaml

from .data import ROOT, feature_spec, json_write, parse_timestamp, sha256, valid_endpoints


@dataclass
class Trial:
    path: str
    sha256: str
    segment_id_raw: int
    effective_id: int
    x: np.ndarray
    force: np.ndarray
    timestamps: np.ndarray
    input_valid: np.ndarray
    force_valid: np.ndarray
    load_state: np.ndarray
    endpoints: np.ndarray
    predict_endpoints: np.ndarray
    is_tip: bool
    info: dict = field(default_factory=dict)
    source_rows: np.ndarray | None = None


def trial_endpoints(trial, role=None, prediction=False):
    ends = trial.predict_endpoints if prediction else trial.endpoints
    spans = getattr(trial, 'info', {}).get('role_rows', {})
    if role in spans:
        start, stop = spans[role]
        window = trial.info['window_samples']
        ends = ends[(ends >= start + window - 1) & (ends < stop)]
    elif spans and role is None and not prediction:
        raise ValueError('A partitioned trial requires an explicit train/validation role')
    return ends


def _path(value, config):
    path = Path(value)
    return path.resolve() if path.is_absolute() else (Path(config.get("project_root", ROOT)) / path).resolve()


def load_config(path):
    path = Path(path).resolve()
    config = yaml.safe_load(path.read_text())
    if not isinstance(config, dict):
        raise ValueError("Configuration must be a mapping")
    contracts = json.loads((ROOT / 'hrm_force' / 'dataset_contracts.json').read_text())
    for key, value in contracts.items():
        config.setdefault(key, value)
    config.setdefault("project_root", str(ROOT))
    config["config_path"] = str(path)
    if config.get('preprocessing', 'audited') not in ('audited', 'numeric_compact'):
        raise ValueError('preprocessing must be audited or numeric_compact')
    if config.get('validation_strategy', 'whole_csv') not in ('whole_csv', 'per_file_tail'):
        raise ValueError('validation_strategy must be whole_csv or per_file_tail')
    if config.get('validation_strategy') == 'per_file_tail' and config.get('preprocessing') != 'numeric_compact':
        raise ValueError('per_file_tail currently requires numeric_compact')
    if not 0 < float(config["validation_fraction"]) < 1:
        raise ValueError("validation_fraction must be strictly between zero and one")
    if config.get("source_force_unit") != "mN":
        raise ValueError("This verified CSV contract requires explicit source_force_unit=mN")
    if config.get("force_source") not in ("kalman", "raw"):
        raise ValueError("force_source must be kalman or raw")
    if int(config["window_samples"]) < 1:
        raise ValueError("window_samples must be positive")
    config["feature_columns"] = feature_spec(config["feature_groups"])[0]
    config["force_columns"] = _force_contract(config)[1]
    for name in ("force_candidates", "location_candidates", "no_load_modes"):
        values = config[name]
        if not values or len(values) != len(set(values)):
            raise ValueError(f"{name} must be nonempty and contain no duplicates")
    if not set(config["no_load_modes"]) <= {"masked", "class0"}:
        raise ValueError("no_load_modes supports masked and class0")
    calibration = config["calibration"]
    if not 0 < calibration["off_quantile"] < calibration["on_quantile"] < 1:
        raise ValueError("Require 0 < off_quantile < on_quantile < 1")
    return config


def _frame(path, columns):
    with path.open(newline="") as handle:
        header = next(csv.reader(handle))
    if len(header) != len(set(header)):
        raise ValueError(f"Duplicate CSV headers: {path}")
    missing = set(columns) - set(header)
    if missing:
        raise ValueError(f"Missing selected columns in {path}: {sorted(missing)}")
    return pd.read_csv(path, usecols=list(dict.fromkeys(columns)), dtype=str, keep_default_na=False)


def _number(frame, columns):
    return frame[columns].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=np.float64)


def _times(frame):
    parsed = [parse_timestamp(value) for value in frame["source_time_ns"]]
    if not parsed:
        raise ValueError("Empty CSV")
    absolute = np.asarray([value for value, _ in parsed], dtype=np.int64)
    # Subtract integers before any conversion to floating point seconds.
    relative = absolute - absolute[0]
    return relative, int(absolute[0]), sum(flag for _, flag in parsed)


def _validity(frame, value_columns, flags, prefixes, config, frame_column=None):
    values = _number(frame, value_columns)
    valid = np.isfinite(values).all(axis=1)
    reasons = {"nonfinite": int((~valid).sum())}
    for flag in flags:
        ok = frame[flag].str.lower().eq("true").to_numpy()
        reasons[flag] = int((~ok).sum())
        valid &= ok
    for prefix in prefixes:
        name = f"{prefix}.time_difference_ms"
        skew = pd.to_numeric(frame[name], errors="coerce").to_numpy(dtype=float)
        ok = np.isfinite(skew) & (np.abs(skew) <= float(config["max_matching_skew_ms"]) + 1e-6)
        reasons[name] = int((~ok).sum())
        valid &= ok
    if frame_column:
        ok = frame[frame_column].eq("hrm_base").to_numpy()
        reasons["wrong_frame"] = int((~ok).sum())
        valid &= ok
    return values, valid, reasons


def _timing_audit(frame, prefixes, config):
    """Check source/receive association against its recorded matching skew.

    Topic timestamps are used only for this tolerant audit. The window anchor is
    parsed exactly by _times. A 20 us allowance accommodates scientific notation
    in legacy CSV exports without hiding millisecond-scale anchor shifts.
    """
    bad = np.zeros(len(frame), dtype=bool)
    reports = {}
    anchor_source = pd.to_numeric(frame["source_time_ns"], errors="coerce").to_numpy(dtype=float)
    anchor_receive = pd.to_numeric(frame["bag_receive_time_ns"], errors="coerce").to_numpy(dtype=float)
    tolerance = float(config.get("timestamp_rounding_tolerance_ms", 0.02))
    for prefix in prefixes:
        source = pd.to_numeric(frame[f"{prefix}.source_time_ns"], errors="coerce").to_numpy(dtype=float)
        receive = pd.to_numeric(frame[f"{prefix}.bag_receive_time_ns"], errors="coerce").to_numpy(dtype=float)
        basis = frame[f"{prefix}.time_basis"].to_numpy()
        reported = pd.to_numeric(frame[f"{prefix}.time_difference_ms"], errors="coerce").to_numpy(dtype=float)
        actual = np.where(basis == "source", source - anchor_source, receive - anchor_receive) / 1e6
        applicable = np.isfinite(actual) & np.isfinite(reported) & np.isin(basis, ["source", "receive"])
        mismatch = applicable & (np.abs(actual - reported) > tolerance)
        exceeds = applicable & (np.abs(actual) > float(config["max_matching_skew_ms"]) + tolerance)
        bad |= mismatch | exceeds
        reports[prefix] = {
            "checked_rows": int(applicable.sum()), "reported_skew_disagreement_rows": int(mismatch.sum()),
            "actual_skew_exceeds_limit_rows": int(exceeds.sum()),
            "max_reported_skew_disagreement_ms": float(np.max(np.abs(actual[applicable] - reported[applicable]))) if applicable.any() else None,
        }
    return bad, reports


def _timing_columns(prefixes):
    return [f"{p}.{suffix}" for p in prefixes for suffix in
            ("source_time_ns", "bag_receive_time_ns", "time_basis", "time_difference_ms")]


def _force_contract(config):
    prefix = {"kalman": "fts_kalman", "raw": "fts"}[config["force_source"]]
    columns = config.get("force_columns", [f"{prefix}.aligned_f{axis}" for axis in "xyz"])
    if len(columns) != 3 or columns != [f"{prefix}.aligned_f{axis}" for axis in "xyz"]:
        raise ValueError("Force outputs must remain ordered hrm_base aligned Fx,Fy,Fz for the selected source")
    return prefix, columns


def _recover_recorded_anchors(frame, policy, path, tolerance_ms):
    """Recover four explicitly identified stale-anchor exports from recorded clocks.

    This never changes a signal row. Shifted anchor entries are accepted only if
    every row independently agrees with motor and loadcell association arithmetic.
    The final rows use duplicated zero-skew angle-derived clocks. Original rounded
    timestamps retain their recorded precision; no exact original ns are claimed.
    """
    offset = int(policy["removed_signal_rows"])
    count = len(frame)
    if count != int(policy["expected_rows"]) or not 0 < offset < count or not policy.get("basis"):
        raise ValueError(f"Timestamp recovery row count/provenance mismatch: {path}")
    old_source = np.asarray([parse_timestamp(value)[0] for value in frame["source_time_ns"]], dtype=np.int64)
    old_receive = np.asarray([parse_timestamp(value)[0] for value in frame["bag_receive_time_ns"]], dtype=np.int64)
    tolerance_ns = int(tolerance_ms * 1e6)
    source_new, receive_new = [], []
    errors = {prefix: [] for prefix in ["motor", "loadcell", "fts", "fts_kalman", "estimated_tip", "fk_tip"]}
    receive_errors = {prefix: [] for prefix in ["wire", "wire_velocity"]}
    methods = {"shifted_recorded_anchor": 0, "duplicate_zero_skew_anchor": 0}
    clone_missing = 0
    for i, row in enumerate(frame.to_dict("records")):
        candidates = {}
        for prefix in errors:
            stamp, skew = row[f"{prefix}.source_time_ns"], row[f"{prefix}.time_difference_ms"]
            if stamp and skew and row[f"{prefix}.time_basis"] == "source":
                candidate = Decimal(stamp) - Decimal(skew) * 1_000_000
                if candidate.is_finite() and candidate == candidate.to_integral_value():
                    candidates[prefix] = int(candidate)
        # These two sources are independent checks; F/T and loadcell share stamps.
        if not {"motor", "loadcell"} <= candidates.keys():
            raise ValueError(f"Timestamp recovery lacks independent motor/loadcell evidence at row {i}: {path}")
        clones = [prefix for prefix in ["estimated_tip", "fk_tip"] if prefix in candidates and Decimal(row[f"{prefix}.time_difference_ms"]) == 0]
        if i + offset < count:
            anchor = int(old_source[i + offset])
            methods["shifted_recorded_anchor"] += 1
            clone_missing += not bool(clones)
        elif clones:
            anchor = candidates[clones[0]]
            methods["duplicate_zero_skew_anchor"] += 1
        else:
            raise ValueError(f"No recorded zero-skew tail anchor at row {i}; refusing inferred timestamp: {path}")
        for prefix, candidate in candidates.items():
            error = candidate - anchor
            if abs(error) > tolerance_ns:
                raise ValueError(f"Independent timestamp evidence conflicts for {prefix}, row {i}: {path}")
            errors[prefix].append(error)
        source_new.append(anchor)
        receive_candidates = {}
        for prefix in receive_errors:
            stamp, skew = row[f"{prefix}.bag_receive_time_ns"], row[f"{prefix}.time_difference_ms"]
            if stamp and skew and row[f"{prefix}.time_basis"] == "receive":
                value = Decimal(stamp) - Decimal(skew) * 1_000_000
                if value.is_finite() and value == value.to_integral_value():
                    receive_candidates[prefix] = int(value)
        if i + offset < count:
            anchor_receive = int(old_receive[i + offset])
        elif len(receive_candidates) == 2:
            anchor_receive = receive_candidates["wire"]
        else:
            raise ValueError(f"No paired receipt-clock evidence for timestamp tail row {i}: {path}")
        for prefix, candidate in receive_candidates.items():
            error = candidate - anchor_receive
            if abs(error) > tolerance_ns:
                raise ValueError(f"Receipt timestamp evidence conflicts for {prefix}, row {i}: {path}")
            receive_errors[prefix].append(error)
        receive_new.append(anchor_receive)
    source_new = np.asarray(source_new, dtype=np.int64)
    if np.any(np.diff(source_new) <= 0):
        raise ValueError(f"Recovered timestamps are not increasing: {path}")
    elapsed = pd.to_numeric(frame["elapsed_s"], errors="coerce").to_numpy(dtype=float)
    elapsed_error = np.abs(elapsed - (old_source - old_source[0]) / 1e9)
    if not np.isfinite(elapsed_error).all() or elapsed_error.max() > tolerance_ms / 1000:
        raise ValueError(f"Recorded elapsed_s does not confirm stale original anchor clock: {path}")
    frame = frame.copy()
    frame["source_time_ns"] = [str(value) for value in source_new]
    frame["bag_receive_time_ns"] = [str(value) for value in receive_new]
    evidence = {"method": "exact_hash_scoped_recorded_anchor_shift_and_independent_topic_skew_identity",
                "policy": policy, "rows_verified": count, "source_anchor_methods": methods,
                "overlap_rows_with_no_duplicate_zero_skew_topic": clone_missing,
                "independent_clock_errors_ns": {key: {"rows": len(value), "max_abs": max(map(abs, value)) if value else None} for key, value in errors.items()},
                "receive_clock_errors_ns": {key: {"rows": len(value), "max_abs": max(map(abs, value)) if value else None} for key, value in receive_errors.items()},
                "original_elapsed_anchor_max_error_s": float(elapsed_error.max()),
                "original_source_start_ns": int(old_source[0]), "recovered_source_start_ns": int(source_new[0]),
                "tolerance_ns": tolerance_ns, "source_csv_modified": False,
                "signal_rows_modified": False, "precision": "Recorded scientific-notation precision only; not original exact-ns reconstruction"}
    return frame, evidence


def calibrate_no_load(config):
    policy = config["calibration"]
    if not policy.get("confirmed_no_load") or not policy.get("basis"):
        raise ValueError("Calibration requires explicitly confirmed no-load provenance")
    center_method = policy.get('center_method', 'median')
    if center_method not in ('median', 'mean'):
        raise ValueError('calibration.center_method must be median or mean')
    width_multiplier = policy.get('range_multiplier', 1.0)
    if isinstance(width_multiplier, bool) or not isinstance(width_multiplier, (int, float)) or not np.isfinite(width_multiplier) or width_multiplier <= 0:
        raise ValueError('calibration.range_multiplier must be a finite positive number')
    path = _path(policy["path"], config)
    before = sha256(path)
    prefix, columns = _force_contract(config)
    flags = [f"{prefix}.matched", f"{prefix}.aligned_force_valid"]
    frame_col = f"{prefix}.aligned_frame_id"
    frame = _frame(path, columns + flags + [frame_col, "source_time_ns", "bag_receive_time_ns"] + _timing_columns([prefix]))
    values, valid, reasons = _validity(frame, columns, flags, [prefix], config, frame_col)
    time_bad, timing = _timing_audit(frame, [prefix], config)
    valid &= ~time_bad
    timestamps, origin, notation = _times(frame)
    if np.any(np.diff(timestamps) <= 0):
        raise ValueError("Calibration timestamps must increase")
    cut = int(len(frame) * float(policy["fit_fraction"]))
    fit = values[:cut][valid[:cut]] * 0.001
    hold = values[cut:][valid[cut:]] * 0.001
    if min(len(fit), len(hold)) < 20:
        raise ValueError("Too few valid calibration or holdout rows")
    center = np.mean(fit, axis=0) if center_method == 'mean' else np.median(fit, axis=0)
    scale = np.std(fit, axis=0, ddof=1)
    if not np.isfinite(scale).all() or (scale <= 0).any():
        raise ValueError("Calibration axis noise must be finite and nonzero")
    fit_scores = np.max(np.abs(fit - center) / scale, axis=1)
    hold_scores = np.max(np.abs(hold - center) / scale, axis=1)
    base_off, base_on = np.quantile(fit_scores, [policy["off_quantile"], policy["on_quantile"]])
    off, on = base_off * width_multiplier, base_on * width_multiplier
    if not 0 < off < on:
        raise ValueError("Calibration produced degenerate uncertainty thresholds")
    def distribution(array):
        return {"rows": len(array), "mean_N": array.mean(0), "median_N": np.median(array, axis=0),
                "std_N": array.std(0, ddof=1), "minimum_N": array.min(0), "maximum_N": array.max(0),
                "q005_N": np.quantile(array, .005, axis=0), "q995_N": np.quantile(array, .995, axis=0)}
    def coverage(scores):
        return {"unloaded_fraction": float(np.mean(scores <= off)),
                "uncertain_fraction": float(np.mean((scores > off) & (scores < on))),
                "loaded_false_alarm_fraction": float(np.mean(scores >= on)),
                "inside_on_threshold_fraction": float(np.mean(scores < on))}
    if sha256(path) != before:
        raise ValueError("Calibration source changed during reading")
    return {
        "path": str(path), "sha256": before, "force_source": config["force_source"], "force_columns": columns,
        "frame": "hrm_base", "source_unit": "mN", "unit": "N", "confirmed_no_load_basis": policy["basis"],
        "method": "max_axis_abs_residual_divided_by_fit_std_empirical_quantiles",
        "center_method": center_method, "range_multiplier": float(width_multiplier),
        "base_off_score": float(base_off), "base_on_score": float(base_on),
        "offset_to_subtract_N": center.tolist(),
        "corrected_force_definition": "F_corrected = F_recorded - offset_to_subtract_N; load labels only; do not subtract twice",
        "corrected_fit_mean_N": (fit - center).mean(axis=0).tolist(),
        "corrected_holdout_mean_N": (hold - center).mean(axis=0).tolist(),
        "corrected_off_lower_N": (-scale * off).tolist(), "corrected_off_upper_N": (scale * off).tolist(),
        "corrected_on_lower_N": (-scale * on).tolist(), "corrected_on_upper_N": (scale * on).tolist(),
        "fit_fraction": policy["fit_fraction"], "split_row": cut, "off_quantile": policy["off_quantile"],
        "on_quantile": policy["on_quantile"], "center_N": center.tolist(), "scale_N": scale.tolist(),
        "off_score": float(off), "on_score": float(on),
        "off_half_width_N": (scale * off).tolist(), "on_half_width_N": (scale * on).tolist(),
        "off_lower_N": (center - scale * off).tolist(), "off_upper_N": (center + scale * off).tolist(),
        "on_lower_N": (center - scale * on).tolist(), "on_upper_N": (center + scale * on).tolist(),
        "fit_distribution": distribution(fit), "holdout_distribution": distribution(hold),
        "fit_coverage": coverage(fit_scores), "holdout_coverage": coverage(hold_scores),
        "time_blocks": [distribution(block) for block in np.array_split(values[valid] * .001, 4)],
        "invalid_rows": int((~valid).sum()), "invalid_reasons_overlapping": reasons, "timing_audit": timing,
        "timestamp_origin_ns": origin, "scientific_notation_rows": notation,
        "regression_force_transform": "mN_to_N_only; calibration center is used only for load labels",
        "zero_transfer_assumption": policy["zero_transfer_basis"],
        "limitations": ["Temporal holdout in one known no-load recording, not independent calibration validation.",
                        "Loaded/uncertain/unloaded are threshold-defined operational labels, not physical contact truth.",
                        "Wider noise bounds may miss real small loads; no known-small-load sensitivity validation was provided.",
                        "Calibration-center transfer across experiments assumes unchanged frame, filter and tare convention; per-trial offset is not estimated."]}


def load_states(force, valid, calibration):
    result = np.full(len(force), -2, dtype=np.int8)
    score = np.max(np.abs(force[valid] - np.asarray(calibration["center_N"])) / np.asarray(calibration["scale_N"]), axis=1)
    state = np.full(len(score), -1, dtype=np.int8)
    state[score <= calibration["off_score"]] = 0
    state[score >= calibration["on_score"]] = 1
    result[valid] = state
    return result


def load_trial(path, config, calibration, require_targets=True):
    if config.get('preprocessing') == 'numeric_compact':
        from .numeric_data import load_numeric_trial
        return load_numeric_trial(path, config, calibration, require_targets)
    path = Path(path).resolve()
    before = sha256(path)
    columns, flags, prefixes = feature_spec(config["feature_groups"])
    force_prefix, force_columns = _force_contract(config)
    force_flags = [f"{force_prefix}.matched", f"{force_prefix}.aligned_force_valid"]
    frame_column = f"{force_prefix}.aligned_frame_id"
    all_prefixes = list(dict.fromkeys(prefixes + [force_prefix]))
    required = columns + flags + ["source_time_ns", "bag_receive_time_ns"] + _timing_columns(prefixes)
    target_required = force_columns + force_flags + [frame_column, "contact_segment_id"] + _timing_columns([force_prefix])
    with path.open(newline="") as handle:
        header = next(csv.reader(handle))
    required += target_required if require_targets else [name for name in target_required if name in header]
    recovery_policy = config.get("timestamp_recovery_by_sha256", {}).get(before)
    if recovery_policy:
        required += _timing_columns(["motor", "loadcell", "fts", "fts_kalman", "estimated_tip", "fk_tip", "wire", "wire_velocity"]) + ["elapsed_s"]
    if "relative_angle" in config["feature_groups"]:
        required.append("angle_frame_id")
    frame = _frame(path, required)
    recorded_notation_rows = sum(parse_timestamp(value)[1] for value in frame["source_time_ns"])
    recovery_evidence = None
    if recovery_policy:
        frame, recovery_evidence = _recover_recorded_anchors(frame, recovery_policy, path,
                                                            float(config.get("timestamp_rounding_tolerance_ms", .02)))
    for name in target_required:
        if name not in frame:
            frame[name] = ""
    x, input_valid, input_reasons = _validity(frame, columns, flags, prefixes, config,
                                            "angle_frame_id" if "relative_angle" in config["feature_groups"] else None)
    force, force_valid, force_reasons = _validity(frame, force_columns, force_flags, [force_prefix], config, frame_column)
    input_time_bad, input_timing = _timing_audit(frame, prefixes, config)
    force_time_bad, force_timing = _timing_audit(frame, [force_prefix], config)
    input_valid &= ~input_time_bad
    force_valid &= ~force_time_bad
    timestamps, origin, notation = _times(frame)
    raw_ids = pd.to_numeric(frame["contact_segment_id"], errors="coerce").to_numpy(dtype=float)
    has_id = np.isfinite(raw_ids).all() and len(np.unique(raw_ids)) == 1 and raw_ids[0] == int(raw_ids[0])
    if not has_id and require_targets:
        raise ValueError(f"A whole independent trial must have one finite integer raw contact ID: {path}")
    raw_id = int(raw_ids[0]) if has_id else 0
    effective = raw_id
    override = config.get("label_overrides_by_sha256", {}).get(before)
    if override:
        if override["original_id"] != raw_id or not override.get("basis"):
            raise ValueError(f"Invalid exact-hash label override: {path}")
        effective = int(override["effective_id"])
    if require_targets and effective not in range(1, 19):
        raise ValueError(f"Expected contact ID 1..18: {path}")
    match = re.search(r"seg-id-(\d+)|summary_(?:test_)?(\d+)", path.stem)
    if has_id and match and int(next(value for value in match.groups() if value is not None)) != effective:
        raise ValueError(f"Filename and effective contact ID disagree without approved hash override: {path}")
    force *= .001
    states = load_states(force, force_valid, calibration)
    window = int(config["window_samples"])
    endpoints, median = valid_endpoints(input_valid & force_valid, timestamps, window, config["gap_factor"])
    predict_ends, _ = valid_endpoints(input_valid, timestamps, window, config["gap_factor"])
    explicit_tip = {_path(name, config) for name in config.get("tip_train_files", [])}
    is_tip = path in explicit_tip or (effective == 18 and path.parent == _path(config["test_directory"], config))
    if path in explicit_tip and effective != 18:
        raise ValueError(f"Declared tip trial does not have effective ID18: {path}")
    if sha256(path) != before:
        raise ValueError(f"Source CSV changed during reading: {path}")
    info = {"path": str(path), "sha256": before, "rows": len(frame), "segment_id_raw": raw_id, "effective_id": effective,
            "label_override": override, "is_tip": is_tip, "timestamp_origin_ns": origin,
            "scientific_notation_rows": recorded_notation_rows, "median_dt_ms": median / 1e6,
            "nonincreasing_steps": int((np.diff(timestamps) <= 0).sum()),
            "gap_steps": int((np.diff(timestamps) > config["gap_factor"] * median).sum()),
            "input_invalid_rows": int((~input_valid).sum()), "force_invalid_rows": int((~force_valid).sum()),
            "input_reasons_overlapping": input_reasons, "force_reasons_overlapping": force_reasons,
            "input_timing_audit": input_timing, "force_timing_audit": force_timing,
            "window_endpoints": len(endpoints), "prediction_endpoints": len(predict_ends),
            "load_state_counts": {str(state): int((states == state).sum()) for state in [-2, -1, 0, 1]},
            "timestamp_repair": recovery_evidence, "has_location_target": bool(has_id),
            "has_force_targets": bool(force_valid.any())}
    return Trial(str(path), before, raw_id, effective, x.astype(np.float32), force.astype(np.float32), timestamps,
                 input_valid, force_valid, states, endpoints, predict_ends, is_tip, info)


def _reject_duplicates(trials):
    for index, trial in enumerate(trials):
        for previous in trials[:index]:
            if trial.sha256 == previous.sha256:
                raise ValueError(f"Duplicate CSV bytes: {previous.path} and {trial.path}")
            if len(trial.x) != len(previous.x):
                continue
            delta = trial.info["timestamp_origin_ns"] - previous.info["timestamp_origin_ns"]
            if abs(delta) <= 1_000_000 and np.max(np.abs(trial.timestamps + delta - previous.timestamps)) <= 1_000_000:
                if np.allclose(trial.x, previous.x, rtol=1e-7, atol=1e-8, equal_nan=True) and np.allclose(trial.force, previous.force, rtol=1e-7, atol=1e-8, equal_nan=True):
                    raise ValueError(f"Duplicate physical trial despite formatting/label changes: {previous.path} and {trial.path}")


def prepare_data(config, run_dir):
    """Freeze test files and partition development using the configured strategy."""
    calibration = calibrate_no_load(config)
    train_root = _path(config["train_directory"], config)
    test_root = _path(config["test_directory"], config)
    if train_root == test_root:
        raise ValueError("Train and test directories must differ")
    exclusions = config.get("excluded_files_by_sha256", {})
    excluded = []
    def discover(directory):
        selected = []
        for path in sorted(directory.glob("*.csv")):
            digest = sha256(path)
            if digest in exclusions:
                if not exclusions[digest].get("reason"):
                    raise ValueError(f"Excluded file needs an explicit reason: {path}")
                excluded.append({"path": str(path), "sha256": digest, **exclusions[digest]})
            else:
                selected.append(path)
        return selected
    development = discover(train_root)
    tests = discover(test_root)
    if not development:
        raise ValueError(f"No independent training CSVs: {train_root}")
    trials = [load_trial(path, config, calibration) for path in development + tests]
    _reject_duplicates(trials)
    protected_test = set(config.get("protected_test_hashes", []))
    protected_train = set(config.get("protected_development_hashes", []))
    for index, trial in enumerate(trials):
        if index < len(development) and trial.sha256 in protected_test:
            raise ValueError(f"Historical held-out test cannot enter development: {trial.path}")
        if index >= len(development) and trial.sha256 in protected_train:
            raise ValueError(f"Historical development cannot become independent test: {trial.path}")
        if not len(trial.endpoints):
            raise ValueError(f"No valid training/evaluation windows after timing and validity audit: {trial.path}; audit={json.dumps(trial.info)}")
    split = {"train": [], "validation": [], "test": list(range(len(development), len(trials)))}
    groups = {}
    for index, trial in enumerate(trials[:len(development)]):
        groups.setdefault(trial.effective_id, []).append(index)
    for segment_id, indices in sorted(groups.items()):
        if config.get('validation_strategy') == 'per_file_tail':
            for index in indices:
                trial = trials[index]
                count = len(trial.x)
                cut = int(count * (1 - float(config['validation_fraction'])))
                window = int(config['window_samples'])
                if min(cut, count - cut) < window:
                    raise ValueError(f'Not enough retained rows for separate train/validation windows: {trial.path}')
                trial.info['role_rows'] = {'train': [0, cut], 'validation': [cut, count]}
                trial.info['role_window_counts'] = {role: len(trial_endpoints(trial, role)) for role in ('train', 'validation')}
                split['train'].append(index)
                split['validation'].append(index)
            continue
        if len(indices) < 2:
            raise ValueError(f"ID{segment_id} needs at least two independent CSV trials; no temporal fallback")
        rng = np.random.default_rng(int(config["seed"]) + segment_id)
        count = min(len(indices) - 1, max(1, math.ceil(len(indices) * float(config["validation_fraction"]))))
        validation = set(rng.permutation(indices)[:count].tolist())
        split["validation"].extend(sorted(validation))
        split["train"].extend(index for index in indices if index not in validation)
    declared_tip = {_path(path, config) for path in config.get("tip_train_files", [])}
    if declared_tip - set(development):
        raise ValueError(f"Missing explicitly declared tip files: {declared_tip - set(development)}")
    if config.get('preprocessing') == 'numeric_compact':
        from .numeric_data import reject_shared_numeric_rows
        reject_shared_numeric_rows(trials[:len(development)], trials[len(development):])
    audit = {"schema_version": 1, "feature_columns": feature_spec(config["feature_groups"])[0],
             "force_columns": _force_contract(config)[1], "force_unit": "N", "force_frame": "hrm_base",
             "source_files": len(trials), "development_files": len(development), "test_files": len(tests),
             "trials": [trial.info for trial in trials], "split": split, "excluded_files": excluded,
             "split_policy": "whole_CSV_per_ID_seeded; no timestamps or rows shared across roles",
             "scaler_policy": "fit each eligible valid raw training row once for its branch; no window duplication or validation/test rows; fit performed by training runner",
             "test_usage": "source validation only before final prediction; no model or region selection",
             "timestamp_policy": "exact decimal anchor parsing; relative int64 ns; no guessed timestamp repair"}
    if config.get('preprocessing') == 'numeric_compact':
        audit['preprocessing'] = 'numeric_compact; finite selected X/Y only; remaining rows concatenated within each file'
        audit['timestamp_policy'] = 'provenance only; no flag/frame/matching-time filtering or time-gap window breaks'
        audit['test_evaluation_scope'] = config.get('test_evaluation_scope', 'user_defined')
    if config.get('validation_strategy') == 'per_file_tail':
        audit['split_policy'] = 'test directory fixed; each train CSV retained-row prefix train / tail validation; no window crosses roles'
    if run_dir is not None:
        output = Path(run_dir)
        output.mkdir(parents=True, exist_ok=True)
        json_write(output / "calibration.json", calibration)
        json_write(output / "data_audit.json", audit)
        json_write(output / "split_manifest.json", {part: [trials[i].info for i in indices] for part, indices in split.items()})
        json_write(output / "resolved_config.json", config)
    return {"trials": trials, "split": split, "calibration": calibration, "audit": audit,
            "feature_columns": audit["feature_columns"], "force_columns": audit["force_columns"]}


def load_prediction_trials(paths, config, calibration):
    """Use frozen train calibration; absent force/ID targets remain invalid, never zero."""
    trials = [load_trial(_path(path, config), config, calibration, require_targets=False) for path in paths]
    _reject_duplicates(trials)
    return trials


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    prepared = prepare_data(load_config(args.config), args.output)
    print(json.dumps({"files": len(prepared["trials"]), "split_files": {k: len(v) for k, v in prepared["split"].items()},
                      "calibration_holdout": prepared["calibration"]["holdout_coverage"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
