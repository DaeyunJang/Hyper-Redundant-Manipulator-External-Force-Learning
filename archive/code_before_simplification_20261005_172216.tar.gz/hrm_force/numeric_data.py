"""User-selected numeric X/Y rows, compacted without editing source CSVs."""
from pathlib import Path
import csv
import re

import numpy as np
import pandas as pd

from .data import feature_spec, parse_timestamp, sha256
from .independent_data import Trial, _force_contract, _frame, _number, _path, load_states


def load_numeric_trial(path, config, calibration, require_targets=True):
    path = Path(path).resolve()
    before = sha256(path)
    features = feature_spec(config['feature_groups'])[0]
    _, targets = _force_contract(config)
    with path.open(newline='') as stream:
        header = next(csv.reader(stream))
    has_targets = all(c in header for c in targets)
    required = features + (targets if require_targets else [c for c in targets if c in header])
    required += [c for c in ('source_time_ns', 'elapsed_s', 'contact_segment_id') if c in header]
    frame = _frame(path, required)
    x = _number(frame, features)
    force = _number(frame, targets) if has_targets else np.full((len(frame), 3), np.nan)
    x_ok = np.isfinite(x).all(1)
    y_ok = np.isfinite(force).all(1)
    # Recorded evaluation CSVs use the same finite-X/Y compact sequence as training.
    # A genuinely target-free input stream can still be inferred using X alone.
    keep = x_ok & y_ok if has_targets or require_targets else x_ok
    excluded = config.get('excluded_rows_by_sha256', {}).get(before)
    if excluded:
        rows = excluded.get('rows', [])
        if not excluded.get('reason') or any(type(i) is not int or i < 0 or i >= len(frame) for i in rows):
            raise ValueError(f'Invalid exact-hash excluded row rule: {path}')
        keep[rows] = False
    source_rows = np.flatnonzero(keep)
    if not len(source_rows):
        raise ValueError(f'No finite selected input/target rows: {path}')
    label = pd.to_numeric(frame.get('contact_segment_id', pd.Series(np.nan, index=frame.index)), errors='coerce').to_numpy()[keep]
    has_id = bool(np.isfinite(label).all() and len(np.unique(label)) == 1 and label[0] == int(label[0]))
    if require_targets and not has_id:
        raise ValueError(f'Retained rows must have one finite integer contact ID: {path}')
    raw_id = int(label[0]) if has_id else 0
    effective = raw_id
    override = config.get('label_overrides_by_sha256', {}).get(before)
    if override:
        if override.get('original_id') != raw_id or not override.get('basis'):
            raise ValueError(f'Invalid exact-hash ID override: {path}')
        effective = int(override['effective_id'])
    if require_targets and effective not in range(1, 19):
        raise ValueError(f'Expected ID1..18: {path}')
    match = re.search(r'seg-id-(\d+)|summary_(?:test_)?(\d+)', path.stem)
    if has_id and match and int(next(v for v in match.groups() if v is not None)) != effective:
        raise ValueError(f'Filename and recorded/effective ID disagree: {path}')
    times = []
    stamps = frame['source_time_ns'].to_numpy()[keep] if 'source_time_ns' in frame else [''] * len(source_rows)
    for stamp in stamps:
        try:
            times.append(parse_timestamp(stamp)[0])
        except ValueError:
            times.append(0)
    available = all(t > 0 for t in times)
    origin = times[0] if available else 0
    timestamps = np.asarray(times, dtype=np.int64) - origin if available else np.zeros(len(times), dtype=np.int64)
    delta = np.diff(timestamps)
    positive = delta[delta > 0]
    median_ms = float(np.median(positive) / 1e6) if len(positive) else None
    x = x[keep]
    force = force[keep] * .001
    force_valid = y_ok[keep]
    window = int(config['window_samples'])
    pred_ends = np.arange(window - 1, len(x), dtype=np.int64)
    ends = pred_ends[force_valid[pred_ends]] if has_targets else np.empty(0, dtype=np.int64)
    explicit_tip = {_path(p, config) for p in config.get('tip_train_files', [])}
    is_tip = effective == 18 if config.get('tip_scope_by_id', False) else (
        path in explicit_tip or (effective == 18 and path.parent == _path(config['test_directory'], config)))
    states = load_states(force, force_valid, calibration)
    info = {'path': str(path), 'sha256': before, 'rows': len(x), 'source_rows_total': len(frame),
            'dropped_rows': int((~keep).sum()), 'input_nonfinite_rows': int((~x_ok).sum()),
            'target_nonfinite_rows': int((~y_ok).sum()), 'explicit_row_exclusion': excluded,
            'segment_id_raw': raw_id, 'effective_id': effective, 'label_override': override,
            'is_tip': is_tip, 'has_location_target': has_id, 'has_force_targets': has_targets,
            'timestamp_origin_ns': origin, 'timestamps_available': available, 'median_dt_ms': median_ms,
            'preprocessing': 'numeric_compact', 'window_samples': window,
            'window_endpoints': len(ends), 'prediction_endpoints': len(pred_ends),
            'input_invalid_rows': 0, 'force_invalid_rows': int((~force_valid).sum()),
            'load_state_counts': {str(i): int((states[ends] == i).sum()) for i in (-2, -1, 0, 1)},
            'source_row_policy': 'source_rows maps compact positions to zero-based original CSV data rows',
            'timestamp_policy': 'preserved when parseable; not used to filter numeric rows or split windows',
            'force_frame_basis': 'configured aligned hrm_base columns; frame flags intentionally not inspected'}
    if sha256(path) != before:
        raise ValueError(f'CSV changed while reading: {path}')
    return Trial(str(path), before, raw_id, effective, x, force, timestamps,
                 np.ones(len(x), dtype=bool), force_valid, states, ends, pred_ends, is_tip, info, source_rows)


def reject_shared_numeric_rows(development, tests):
    """Reject copied X/Y rows across supplied folders even after CSV reformatting."""
    if not tests:
        return
    def values(trial):
        a = np.column_stack((trial.x, trial.force)).astype(np.float64)
        a[a == 0] = 0.0
        return a
    seen = {}
    arrays = [values(t) for t in development]
    for ti, a in enumerate(arrays):
        for row, key in enumerate(pd.util.hash_pandas_object(pd.DataFrame(a), index=False)):
            seen.setdefault(int(key), (ti, row))
    for trial in tests:
        a = values(trial)
        for row, key in enumerate(pd.util.hash_pandas_object(pd.DataFrame(a), index=False)):
            if int(key) in seen:
                ti, old_row = seen[int(key)]
                if np.array_equal(a[row], arrays[ti][old_row]):
                    raise ValueError(f'Train/test share selected X/Y data: {development[ti].path} row '
                                     f'{development[ti].source_rows[old_row]} / {trial.path} row {trial.source_rows[row]}')
