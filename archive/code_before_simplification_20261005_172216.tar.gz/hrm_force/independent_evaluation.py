"""Metrics and validation-only region search for independent HRM branches.

Forces enter in N and metrics use mN. Location probabilities retain their
original mass, including class0's no-load probability. GT labels select the
evaluation population only; ``location_predictions`` never takes GT inputs.
Undefined metrics are NaN so callers can export them as JSON null / CSV blanks.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np


DEFAULT_REGIONS = {
    "lower": list(range(1, 11)),
    "middle": list(range(11, 16)),
    "upper": list(range(16, 19)),
}


def _ratio(numerator: float, denominator: float) -> float:
    return float(numerator / denominator) if denominator else float("nan")


def _mean(values: np.ndarray | list[float]) -> float:
    values = np.asarray(values, dtype=float)
    finite = values[np.isfinite(values)]
    return float(finite.mean()) if len(finite) else float("nan")


def force_metrics(pred_N: Any, target_N: Any, valid: Any = None) -> dict[str, Any]:
    """Return axis/pooled XYZ RMSE and MAE; finite valid targets define support.

    Invalid target rows can be excluded, but nonfinite predictions on otherwise
    valid targets raise an error instead of making a failing model look better.
    ``valid`` is a row mask, independent of the location loss mask.
    """
    prediction = np.asarray(pred_N, dtype=float)
    target = np.asarray(target_N, dtype=float)
    if prediction.shape != target.shape or target.ndim != 2 or target.shape[1] != 3:
        raise ValueError("Force prediction and target must both have shape (N, 3)")
    selected = np.isfinite(target).all(axis=1)
    if valid is not None:
        mask = np.asarray(valid)
        if mask.shape != (len(target),) or not np.isin(mask, [0, 1]).all():
            raise ValueError("valid must contain one boolean / 0 or 1 per row")
        selected &= mask.astype(bool)
    if not np.isfinite(prediction[selected]).all():
        raise ValueError("Nonfinite force prediction on a valid target")
    error = (prediction[selected] - target[selected]) * 1000.0
    result: dict[str, Any] = {
        "force_support": int(selected.sum()),
        "force_excluded": int((~selected).sum()),
    }
    for column, axis in enumerate(("fx", "fy", "fz")):
        result[f"force_rmse_{axis}_mN"] = float(np.sqrt(np.mean(error[:, column] ** 2))) if len(error) else float("nan")
        result[f"force_mae_{axis}_mN"] = _mean(np.abs(error[:, column]))
    result["force_rmse_xyz_mN"] = float(np.sqrt(np.mean(error ** 2))) if len(error) else float("nan")
    result["force_mae_xyz_mN"] = _mean(np.abs(error).ravel())
    return result


def _probabilities(probabilities: Any, mode: str, active_ids: Sequence[int]) -> tuple[np.ndarray, np.ndarray]:
    if mode not in ("masked", "class0"):
        raise ValueError("mode must be masked or class0")
    ids = np.asarray(active_ids)
    if ids.ndim != 1 or not len(ids) or not np.isin(ids, np.arange(1, 19)).all() or len(np.unique(ids)) != len(ids):
        raise ValueError("active_ids must contain distinct integer segment IDs in 1..18")
    ids = ids.astype(int)
    probability = np.asarray(probabilities, dtype=float)
    if probability.ndim != 2 or probability.shape[1] != len(ids) + (mode == "class0"):
        raise ValueError("Probability columns must follow the saved active_ids and class0 mapping")
    if not np.isfinite(probability).all() or np.any(probability < 0) or np.any(probability > 1):
        raise ValueError("Probabilities must be finite values in [0, 1]")
    if not np.allclose(probability.sum(axis=1), 1.0, rtol=1e-5, atol=1e-7):
        raise ValueError("Each probability row must sum to 1; do not pass logits")
    return probability, ids


def _regions(regions: Mapping[str, Sequence[int]] | None, ids: np.ndarray) -> dict[str, list[int]]:
    source = DEFAULT_REGIONS if regions is None else regions
    if not source:
        raise ValueError("At least one region is required")
    result = {}
    seen: set[int] = set()
    for name, members in source.items():
        if not isinstance(name, str) or not name or not all(char.isalnum() or char == "_" for char in name):
            raise ValueError("Region names must contain letters, digits, or underscores")
        values = np.asarray(members)
        if values.ndim != 1 or not len(values) or not np.isin(values, np.arange(1, 19)).all():
            raise ValueError("Region IDs must be integer segments in 1..18")
        group = values.astype(int).tolist()
        if len(set(group)) != len(group) or seen.intersection(group):
            raise ValueError("Region IDs must not overlap or repeat")
        result[name] = group
        seen.update(group)
    if not set(ids.tolist()).issubset(seen):
        raise ValueError("Regions must cover every active segment exactly once")
    return result


def region_probabilities(
    probabilities: Any, mode: str, active_ids: Sequence[int],
    regions: Mapping[str, Sequence[int]] | None = None,
) -> dict[str, np.ndarray]:
    """Sum original segment probabilities; class0 sums remain 1 - p0."""
    probability, ids = _probabilities(probabilities, mode, active_ids)
    groups = _regions(regions, ids)
    segment = probability[:, int(mode == "class0"):]
    return {name: segment[:, np.isin(ids, members)].sum(axis=1) for name, members in groups.items()}


def location_predictions(
    probabilities: Any, mode: str, active_ids: Sequence[int],
    regions: Mapping[str, Sequence[int]] | None = None,
) -> dict[str, Any]:
    """Decode without GT; masked has no operational ID or no-load detector.

    Class0's candidate rule is argmax over all classes, including zero. Region
    candidates use summed probabilities independently of the global ID argmax.
    This explicit rule is evaluable; it does not itself establish deployment
    calibration. Ties follow saved class / region order.
    """
    probability, ids = _probabilities(probabilities, mode, active_ids)
    groups = _regions(regions, ids)
    segment = probability[:, int(mode == "class0"):]
    sums = region_probabilities(probability, mode, ids, groups)
    region_matrix = np.column_stack(list(sums.values()))
    region_index = region_matrix.argmax(axis=1)
    conditional = ids[segment.argmax(axis=1)]
    full = np.full((len(probability), 18), np.nan)
    full[:, ids - 1] = segment
    final = np.full(len(probability), np.nan)
    system_region = np.full(len(probability), np.nan)
    p0 = np.full(len(probability), np.nan)
    if mode == "class0":
        final = np.r_[0, ids][probability.argmax(axis=1)]
        system_region = np.where(final == 0, -1, region_index)
        p0 = probability[:, 0].copy()
    return {
        "conditional_id": conditional,
        "final_id": final,
        "segment_probabilities": full,
        "no_load_probability": p0,
        "region_names": list(groups),
        "region_probabilities": region_matrix,
        "conditional_region_index": region_index,
        "system_region_index": system_region,
        "decision_rule": "class_argmax" if mode == "class0" else "unavailable",
    }


def _labels(actual_ids: Any, load_state: Any, length: int) -> tuple[np.ndarray, np.ndarray]:
    actual = np.asarray(actual_ids, dtype=float)
    states = np.asarray(load_state, dtype=object)
    if actual.shape != (length,) or states.shape != (length,):
        raise ValueError("actual_ids and load_state must each have one value per row")
    mapping = {1: "loaded", 0: "unloaded", -1: "uncertain", -2: "invalid"}
    states = np.asarray([mapping.get(value, value) for value in states], dtype=object)
    if not np.isin(states, ["loaded", "unloaded", "uncertain", "invalid"]).all():
        raise ValueError("load_state must be loaded/unloaded/uncertain/invalid (or 1/0/-1/-2)")
    return actual, states


def _detection_metrics(true_loaded: np.ndarray, predicted_loaded: np.ndarray) -> dict[str, Any]:
    tp = int(np.sum(true_loaded & predicted_loaded))
    tn = int(np.sum(~true_loaded & ~predicted_loaded))
    fp = int(np.sum(~true_loaded & predicted_loaded))
    fn = int(np.sum(true_loaded & ~predicted_loaded))
    recall, specificity = _ratio(tp, tp + fn), _ratio(tn, tn + fp)
    return {
        "load_support": len(true_loaded),
        "load_tp": tp, "load_tn": tn, "load_fp": fp, "load_fn": fn,
        "load_precision": _ratio(tp, tp + fp),
        "load_recall": recall,
        "load_f1": _ratio(2 * tp, 2 * tp + fp + fn),
        "load_false_positive_rate": _ratio(fp, fp + tn),
        "load_false_negative_rate": _ratio(fn, fn + tp),
        "load_accuracy": _ratio(tp + tn, len(true_loaded)),
        "load_balanced_accuracy": (recall + specificity) / 2,
        "unload_precision": _ratio(tn, tn + fn),
        "unload_recall": specificity,
        "unload_f1": _ratio(2 * tn, 2 * tn + fp + fn),
    }


def location_metrics(
    probabilities: Any, actual_ids: Any, load_state: Any, mode: str,
    active_ids: Sequence[int], regions: Mapping[str, Sequence[int]] | None = None,
) -> dict[str, Any]:
    """Return flat metrics with diagnostic, detection, and system denominators.

    Location diagnostics use GT loaded rows whose ID is active, even if class0
    predicts no load. Detection/system metrics use those rows plus all known
    unloaded rows. Unsupported loaded contacts are counted separately, never
    relabelled as unloaded. ``region_id_macro_recall`` averages region success
    per supported true segment. ``region_balanced_id_macro_recall`` first
    averages those segment recalls within each region, then weights regions
    equally; it is undefined if any region has no supported GT samples.
    """
    probability, ids = _probabilities(probabilities, mode, active_ids)
    groups = _regions(regions, ids)
    actual, states = _labels(actual_ids, load_state, len(probability))
    decoded = location_predictions(probability, mode, ids, groups)
    selected = (states == "loaded") & np.isin(actual, ids)
    count = int(selected.sum())
    conditional = decoded["conditional_id"]
    lookup = {segment: index for index, members in enumerate(groups.values()) for segment in members}
    true_region = np.asarray([lookup.get(value, -1) for value in actual], dtype=int)
    region_prediction = decoded["conditional_region_index"]
    correct = conditional == actual
    region_correct = region_prediction == true_region
    result: dict[str, Any] = {
        "location_mode": mode,
        "location_interpretation": "loaded_conditional_diagnostic",
        "location_support": count,
        "location_loaded_outside_support": int(np.sum((states == "loaded") & ~np.isin(actual, ids))),
        "location_unloaded_support": int(np.sum(states == "unloaded")),
        "location_uncertain_support": int(np.sum(states == "uncertain")),
        "location_invalid_support": int(np.sum(states == "invalid")),
        "location_accuracy": _ratio(np.sum(correct[selected]), count),
        "location_within1_accuracy": _ratio(np.sum(np.abs(conditional[selected] - actual[selected]) <= 1), count),
        "region_accuracy": _ratio(np.sum(region_correct[selected]), count),
        "region_predicted_probability_mean": _mean(decoded["region_probabilities"][selected].max(axis=1)),
        "region_true_probability_mean": _mean(decoded["region_probabilities"][np.flatnonzero(selected), true_region[selected]]),
        "load_evaluation_scope": "active_loaded_and_all_unloaded",
        "system_decision_rule": decoded["decision_rule"],
        "system_available": mode == "class0",
    }
    id_recalls, id_region_recalls = [], []
    for segment in range(1, 19):
        subset = selected & (actual == segment)
        support = int(subset.sum())
        recall = _ratio(np.sum(correct[subset]), support)
        region_recall = _ratio(np.sum(region_correct[subset]), support)
        result[f"location_id_{segment:02d}_supported"] = bool(segment in ids)
        result[f"location_id_{segment:02d}_support"] = support
        result[f"location_id_{segment:02d}_recall"] = recall
        result[f"region_id_{segment:02d}_recall"] = region_recall
        id_recalls.append(recall)
        id_region_recalls.append(region_recall)
    result["location_macro_recall"] = _mean(id_recalls)
    result["location_macro_class_count"] = int(np.isfinite(id_recalls).sum())
    result["region_id_macro_recall"] = _mean(id_region_recalls)
    region_recalls, region_id_means = [], []
    for index, name in enumerate(groups):
        subset = selected & (true_region == index)
        support = int(subset.sum())
        recall = _ratio(np.sum(region_correct[subset]), support)
        result[f"region_{name}_support"] = support
        result[f"region_{name}_recall"] = recall
        result[f"region_{name}_true_probability_mean"] = _mean(decoded["region_probabilities"][subset, index])
        id_mean = _mean([result[f"region_id_{segment:02d}_recall"] for segment in groups[name]])
        result[f"region_{name}_id_macro_recall"] = id_mean
        region_id_means.append(id_mean)
        region_recalls.append(recall)
    result["region_macro_recall"] = _mean(region_recalls)
    result["region_macro_class_count"] = int(np.isfinite(region_recalls).sum())
    result["region_balanced_id_macro_recall"] = float(np.mean(region_id_means))
    evaluable = selected | (states == "unloaded")
    empty_detection = _detection_metrics(np.array([], dtype=bool), np.array([], dtype=bool))
    if mode == "class0":
        final = decoded["final_id"]
        result.update(_detection_metrics(states[evaluable] == "loaded", final[evaluable] != 0))
        target = np.where(states == "unloaded", 0, actual)
        final_region = decoded["system_region_index"]
        target_region = np.where(states == "unloaded", -1, true_region)
        total = int(evaluable.sum())
        result.update({
            "system_support": total,
            "system_id_accuracy": _ratio(np.sum(final[evaluable] == target[evaluable]), total),
            "system_region_accuracy": _ratio(np.sum(final_region[evaluable] == target_region[evaluable]), total),
            "system_loaded_id_accuracy": _ratio(np.sum(final[selected] == actual[selected]), count),
            "system_loaded_region_accuracy": _ratio(np.sum(final_region[selected] == true_region[selected]), count),
        })
    else:
        result.update({key: float("nan") for key in empty_detection})
        result.update({key: float("nan") for key in (
            "system_support", "system_id_accuracy", "system_region_accuracy",
            "system_loaded_id_accuracy", "system_loaded_region_accuracy",
        )})
    return result


def location_confusion(
    probabilities: Any, actual_ids: Any, load_state: Any, mode: str,
    active_ids: Sequence[int], *, system: bool = False,
) -> dict[str, Any]:
    """Return labels and count matrix separately from scalar comparison rows."""
    probability, ids = _probabilities(probabilities, mode, active_ids)
    actual, states = _labels(actual_ids, load_state, len(probability))
    decoded = location_predictions(probability, mode, ids)
    selected = (states == "loaded") & np.isin(actual, ids)
    labels = ids
    truth, predicted = actual, decoded["conditional_id"]
    if system:
        if mode != "class0":
            return {"available": False, "labels": [], "matrix": []}
        selected |= states == "unloaded"
        labels = np.r_[0, ids]
        truth = np.where(states == "unloaded", 0, actual)
        predicted = decoded["final_id"]
    matrix = np.zeros((len(labels), len(labels)), dtype=np.int64)
    lookup = {value: index for index, value in enumerate(labels)}
    for target, estimate in zip(truth[selected], predicted[selected]):
        matrix[lookup[target], lookup[estimate]] += 1
    return {"available": True, "labels": labels.tolist(), "matrix": matrix.tolist()}


def optimize_regions(
    probabilities: Any, actual_ids: Any, load_state: Any, mode: str,
    active_ids: Sequence[int], *, min_segments: int = 3, split: str = "validation",
) -> dict[str, Any]:
    """Evaluate all 136 contiguous 3-region partitions on validation only.

    Every boundary pair is retained with its constraint/support status. Select
    by region-balanced true-ID macro recall, then ordinary region macro recall,
    then true-ID macro region recall. Equal scores favor boundaries closest to
    the baseline (10, 15), then lower IDs.
    Each selected region must have at least one GT loaded validation sample;
    missing IDs remain explicit and are not treated as evidence of accuracy.
    The result is a validation search result, not an independent test estimate.
    """
    if split != "validation":
        raise ValueError("Region boundaries may only be selected using validation data")
    if isinstance(min_segments, bool) or not isinstance(min_segments, (int, np.integer)) or not 1 <= min_segments <= 6:
        raise ValueError("min_segments must be an integer in 1..6")
    probability, ids = _probabilities(probabilities, mode, active_ids)
    actual, states = _labels(actual_ids, load_state, len(probability))
    baseline = location_metrics(probability, actual, states, mode, ids, DEFAULT_REGIONS)
    selected = (states == "loaded") & np.isin(actual, ids)
    truth = actual[selected].astype(int)
    segment = probability[selected, int(mode == "class0"):]
    # Validate and select rows once. Use the same summation order as inference;
    # cumulative subtraction can change exact ties through floating-point error.
    id_support = np.bincount(truth, minlength=19)
    supported = id_support > 0
    common = {key: value for key, value in baseline.items() if key.startswith("location_id_") or key in ("location_support", "location_macro_class_count")}
    candidates = []
    for first in range(1, 17):
        for second in range(first + 1, 18):
            sums = np.column_stack((
                segment[:, ids <= first].sum(axis=1),
                segment[:, (ids > first) & (ids <= second)].sum(axis=1),
                segment[:, ids > second].sum(axis=1),
            ))
            prediction = sums.argmax(axis=1)
            target_region = (truth > first).astype(int) + (truth > second).astype(int)
            correct = prediction == target_region
            true_support = np.bincount(target_region, minlength=3)
            true_correct = np.bincount(target_region, weights=correct, minlength=3)
            recalls = np.full(3, np.nan)
            np.divide(true_correct, true_support, out=recalls, where=true_support > 0)
            id_correct = np.bincount(truth, weights=correct, minlength=19)
            id_recalls = np.full(19, np.nan)
            np.divide(id_correct, id_support, out=id_recalls, where=supported)
            metrics = {
                "region_accuracy": _ratio(correct.sum(), len(truth)),
                "region_macro_recall": _mean(recalls),
                "region_macro_class_count": int(np.sum(true_support > 0)),
                "region_id_macro_recall": _mean(id_recalls),
                "region_predicted_probability_mean": _mean(sums.max(axis=1)),
                "region_true_probability_mean": _mean(sums[np.arange(len(truth)), target_region]),
                **common,
            }
            within_region_means = []
            for index, (name, start, end) in enumerate((
                ("lower", 1, first), ("middle", first + 1, second), ("upper", second + 1, 18),
            )):
                metrics[f"region_{name}_support"] = int(true_support[index])
                metrics[f"region_{name}_recall"] = float(recalls[index])
                metrics[f"region_{name}_true_probability_mean"] = _mean(sums[target_region == index, index])
                id_mean = _mean(id_recalls[start:end + 1])
                metrics[f"region_{name}_id_macro_recall"] = id_mean
                within_region_means.append(id_mean)
            metrics["region_balanced_id_macro_recall"] = float(np.mean(within_region_means))
            for value in range(1, 19):
                metrics[f"region_id_{value:02d}_recall"] = float(id_recalls[value])
            sizes = (first, second - first, 18 - second)
            size_valid = min(sizes) >= min_segments
            has_support = bool(np.all(true_support > 0))
            row = {
                "lower_end": first, "middle_end": second,
                "lower_segments": sizes[0], "middle_segments": sizes[1], "upper_segments": sizes[2],
                "min_segments": int(min_segments), "meets_min_segments": size_valid,
                "has_support_all_regions": has_support,
                "eligible": bool(size_valid and has_support and np.isfinite(metrics["region_balanced_id_macro_recall"])),
                "is_baseline": first == 10 and second == 15,
                "selected": False,
                **metrics,
            }
            candidates.append(row)
    eligible = [row for row in candidates if row["eligible"]]
    best = max(eligible, key=lambda row: (
        row["region_balanced_id_macro_recall"], row["region_macro_recall"], row["region_id_macro_recall"],
        -(abs(row["lower_end"] - 10) + abs(row["middle_end"] - 15)),
        -row["lower_end"], -row["middle_end"],
    )) if eligible else None
    chosen = None
    if best is not None:
        best["selected"] = True
        first, second = best["lower_end"], best["middle_end"]
        chosen = {"lower": list(range(1, first + 1)), "middle": list(range(first + 1, second + 1)), "upper": list(range(second + 1, 19))}
    return {
        "selection_split": "validation",
        "selection_metric": "region_balanced_id_macro_recall",
        "selection_metric_definition": "Mean per-true-ID region recall within each region, then equal mean across all three regions; undefined when any region lacks GT support. Original probability sums are unchanged.",
        "selection_tie_breakers": ["region_macro_recall", "region_id_macro_recall", "closest_to_baseline_10_15", "smaller_boundaries"],
        "selection_status": "selected" if best is not None else "no_eligible_candidate",
        "min_segments": int(min_segments),
        "selected_regions": chosen,
        "selected_metrics": location_metrics(probability, actual, states, mode, ids, chosen) if chosen is not None else None,
        "baseline_regions": {name: members.copy() for name, members in DEFAULT_REGIONS.items()},
        "baseline_metrics": baseline,
        "candidates": candidates,
    }
