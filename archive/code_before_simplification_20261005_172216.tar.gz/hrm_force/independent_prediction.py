"""Restore complete independent bundles, replay CSV rows, and evaluate held-out data."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from .data import ROOT, feature_spec
from .independent_data import load_prediction_trials
from .independent_engine import (
    WindowStore, fresh_directory, predict_branch, restore_bundle, write_json,
)
from .independent_evaluation import (
    DEFAULT_REGIONS, force_metrics, location_confusion, location_metrics,
    location_predictions, optimize_regions,
)


DEFAULT_FORCE_TOLERANCE_MN = 1e-3


def _path(value: str | Path, bundle: dict) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (Path(bundle["config"].get("project_root", ROOT)) / path).resolve()


def _known_trials(bundle: dict) -> list[dict]:
    return bundle.get("data_audit", {}).get("trials", [])


def _tip_verified(trial: Any, bundle: dict) -> bool:
    """An ID18 filename alone cannot certify a tip-force evaluation trial."""
    if bundle.get("force_scope", bundle["config"].get("force_scope", "tip")) != "tip":
        return True
    return any(info.get("sha256") == trial.sha256 and info.get("is_tip") for info in _known_trials(bundle))


def _assert_held_out(trials: list, bundle: dict) -> None:
    known = _known_trials(bundle)
    forbidden = set(bundle["config"].get("protected_development_hashes", []))
    development = []
    for part in ("train", "validation"):
        for index in bundle.get("split", {}).get(part, []):
            if isinstance(index, int) and 0 <= index < len(known):
                forbidden.add(known[index]["sha256"])
                development.append(known[index])
    overlap = [trial.path for trial in trials if trial.sha256 in forbidden]
    if overlap:
        raise ValueError(f"Development trials cannot be reported as independent test: {overlap}")
    for trial in trials:
        origin = trial.info.get('timestamp_origin_ns')
        if not isinstance(origin, int) or origin <= 0:
            continue
        for info in development:
            previous = info.get('timestamp_origin_ns')
            if (isinstance(previous, int) and previous > 0 and info.get('rows') == len(trial.x)
                    and abs(previous - origin) <= 20000):
                raise ValueError(f'Development recording clock and row count recur after reformatting: {trial.path}')


def _initial_frame(trial: Any, bundle: dict, checkpoint: Path) -> pd.DataFrame:
    size = len(trial.x)
    has_id = trial.info.get("has_location_target", True)
    scope_verified = _tip_verified(trial, bundle)
    states = np.asarray(trial.load_state)
    state_names = {-2: "invalid", -1: "uncertain", 0: "unloaded", 1: "loaded"}
    frame = pd.DataFrame({
        "source_file": trial.path,
        "source_sha256": trial.sha256,
        "source_row": trial.source_rows if getattr(trial, 'source_rows', None) is not None else np.arange(size),
        "source_time_ns": np.asarray(trial.timestamps, dtype=np.int64) + int(trial.info.get("timestamp_origin_ns", 0)),
        "elapsed_s": np.asarray(trial.timestamps) / 1e9,
        "mode": bundle["mode"],
        "force_model": bundle["force_name"],
        "location_model": bundle["location_name"],
        "bundle": str(checkpoint),
        "actual_id_raw": trial.segment_id_raw if has_id else np.nan,
        "actual_id_effective": trial.effective_id if has_id else np.nan,
        "load_state_gt": [state_names[int(value)] for value in states],
        "input_valid": trial.input_valid,
        "force_target_valid": trial.force_valid,
        "force_scope": bundle.get("force_scope", bundle["config"].get("force_scope", "tip")),
        "force_scope_verified": scope_verified,
        "force_ready": False,
        "location_ready": False,
        "force_status": np.where(trial.input_valid, "warming_up", "invalid_input"),
        "location_status": np.where(trial.input_valid, "warming_up", "invalid_input"),
        "location_decision_rule": "class_argmax" if bundle["mode"] == "class0" else "unavailable",
        "deployment_gate_validated": False,
        "evaluation_scope": bundle['config'].get('test_evaluation_scope', 'historical_held_out_recordings'),
    })
    if not trial.info.get('timestamps_available', True):
        frame[['source_time_ns', 'elapsed_s']] = np.nan
    columns = {}
    for axis, name in enumerate(("fx", "fy", "fz")):
        columns[f"true_{name}_N"] = trial.force[:, axis]
        columns[f"true_{name}_mN"] = trial.force[:, axis] * 1000.0
        columns[f"pred_{name}_N"] = np.full(size, np.nan)
        columns[f"pred_{name}_mN"] = np.full(size, np.nan)
    for segment in range(19):
        columns[f"p{segment}"] = np.full(size, np.nan)
    columns["conditional_id"] = np.full(size, np.nan)
    columns["final_id"] = np.full(size, np.nan)
    return pd.concat([frame, pd.DataFrame(columns)], axis=1)


def _add_regions(frame: pd.DataFrame, ready: np.ndarray, probabilities: np.ndarray,
                 bundle: dict, regions: dict, prefix: str) -> None:
    active = bundle["config"].get("active_ids", list(range(1, 19)))
    decoded = location_predictions(probabilities, bundle["mode"], active, regions)
    additions: dict[str, Any] = {}
    for index, name in enumerate(decoded["region_names"]):
        values = np.full(len(frame), np.nan)
        values[ready] = decoded["region_probabilities"][:, index]
        additions[f"{prefix}_region_{name}_probability"] = values
    for key in ("region_candidate", "region_final"):
        additions[f"{prefix}_{key}"] = np.full(len(frame), None, dtype=object)
    additions[f"{prefix}_region_id_candidate"] = np.full(len(frame), np.nan)
    names = np.asarray(decoded["region_names"], dtype=object)
    chosen = decoded["conditional_region_index"]
    additions[f"{prefix}_region_candidate"][ready] = names[chosen]
    if bundle["mode"] == "class0":
        additions[f"{prefix}_region_final"][ready] = np.where(decoded["final_id"] == 0, "unloaded", names[chosen])
    segment = probabilities[:, int(bundle["mode"] == "class0"):]
    active_array = np.asarray(active)
    within_id = np.full(len(ready), np.nan)
    for index, name in enumerate(names):
        rows = chosen == index
        supported = np.isin(active_array, regions[name])
        if supported.any():
            within_id[rows] = active_array[supported][segment[rows][:, supported].argmax(axis=1)]
    additions[f"{prefix}_region_id_candidate"][ready] = within_id
    for name, values in additions.items():
        frame[name] = values


def predict_trials(model: Any, bundle: dict, trials: list, checkpoint: str | Path,
                   optimized_regions: dict | None = None, device: str = "cpu") -> pd.DataFrame:
    """Predict loaded trial histories with original row mapping and raw force output."""
    cfg = bundle["config"]
    mode = bundle["mode"]
    checkpoint = Path(checkpoint).resolve()
    expected = bundle.get("feature_columns")
    if expected is not None and list(expected) != feature_spec(cfg["feature_groups"])[0]:
        raise ValueError("Current feature mapping differs from the saved bundle input order")
    frames = [_initial_frame(trial, bundle, checkpoint) for trial in trials]
    indices = [index for index, trial in enumerate(trials) if len(trial.predict_endpoints)]
    for branch in ("force", "location"):
        if not indices:
            continue
        scaler = {name: np.asarray(values) for name, values in bundle["scalers"][branch].items()}
        store = WindowStore(trials, indices, scaler, cfg, device, branch, mode, prediction=True)
        network = model.force_net if branch == "force" else model.location_net
        predicted = predict_branch(network, store, int(cfg["batch_size"]))
        refs = np.asarray(store.refs, dtype=int)
        for index in indices:
            rows = refs[:, 0] == index
            source_rows = refs[rows, 1]
            values = predicted[rows]
            frame = frames[index]
            frame.loc[source_rows, f"{branch}_ready"] = True
            if branch == "force":
                for axis, name in enumerate(("fx", "fy", "fz")):
                    frame.loc[source_rows, f"pred_{name}_N"] = values[:, axis]
                    frame.loc[source_rows, f"pred_{name}_mN"] = values[:, axis] * 1000.0
                status = "ready" if _tip_verified(trials[index], bundle) else "scope_unverified"
                frame.loc[source_rows, "force_status"] = status
            else:
                active = cfg.get("active_ids", list(range(1, 19)))
                decoded = location_predictions(values, mode, active, cfg.get("regions"))
                frame.loc[source_rows, "p0"] = decoded["no_load_probability"]
                frame.loc[source_rows, [f"p{segment}" for segment in range(1, 19)]] = decoded["segment_probabilities"]
                frame.loc[source_rows, "conditional_id"] = decoded["conditional_id"]
                frame.loc[source_rows, "final_id"] = decoded["final_id"]
                status = np.where(decoded["final_id"] == 0, "unloaded", "valid") if mode == "class0" else "unverified"
                frame.loc[source_rows, "location_status"] = status
    for frame in frames:
        ready = np.flatnonzero(frame["location_ready"].to_numpy())
        classes = ([0] if mode == "class0" else []) + list(cfg.get("active_ids", range(1, 19)))
        probabilities = frame.loc[ready, [f"p{segment}" for segment in classes]].to_numpy(dtype=float)
        _add_regions(frame, ready, probabilities, bundle, cfg.get("regions", DEFAULT_REGIONS), "baseline")
        if optimized_regions is not None:
            _add_regions(frame, ready, probabilities, bundle, optimized_regions, "optimized")
    if not frames:
        raise ValueError("No CSV trials were supplied for prediction")
    return pd.concat(frames, ignore_index=True)


def evaluate_frame(frame: pd.DataFrame, bundle: dict, regions: dict | None = None) -> dict:
    """Evaluate scope-verified force and conditional/detection/system location separately."""
    force_valid = (frame["force_ready"] & frame["force_target_valid"] & frame["force_scope_verified"]).to_numpy()
    prediction = frame[[f"pred_{axis}_N" for axis in ("fx", "fy", "fz")]].to_numpy(dtype=float)
    target = frame[[f"true_{axis}_N" for axis in ("fx", "fy", "fz")]].to_numpy(dtype=float)
    metrics = force_metrics(prediction, target, force_valid)
    states = frame["load_state_gt"].to_numpy()
    for state in ("loaded", "unloaded"):
        metrics.update({f"{state}_{key}": value for key, value in force_metrics(prediction, target, force_valid & (states == state)).items()})
    active = bundle["config"].get("active_ids", list(range(1, 19)))
    classes = ([0] if bundle["mode"] == "class0" else []) + list(active)
    ready = frame["location_ready"].to_numpy()
    probability = frame.loc[ready, [f"p{segment}" for segment in classes]].to_numpy(dtype=float)
    ids = frame.loc[ready, "actual_id_effective"].to_numpy(dtype=float)
    selected_states = states[ready]
    metrics.update(location_metrics(probability, ids, selected_states, bundle["mode"], active, regions))
    metrics.update({
        "source_rows": len(frame),
        "force_prediction_rows": int(frame["force_ready"].sum()),
        "location_prediction_rows": int(ready.sum()),
        "force_scope_unverified_prediction_rows": int((frame["force_ready"] & ~frame["force_scope_verified"]).sum()),
    })
    return metrics


def prediction_report(frame: pd.DataFrame, bundle: dict, optimized_regions: dict | None) -> dict:
    baseline = bundle["config"].get("regions", DEFAULT_REGIONS)
    active = bundle["config"].get("active_ids", list(range(1, 19)))
    classes = ([0] if bundle["mode"] == "class0" else []) + list(active)
    ready = frame["location_ready"].to_numpy()
    probability = frame.loc[ready, [f"p{segment}" for segment in classes]].to_numpy(dtype=float)
    actual = frame.loc[ready, "actual_id_effective"].to_numpy(dtype=float)
    states = frame.loc[ready, "load_state_gt"].to_numpy()
    report = {
        "overall": evaluate_frame(frame, bundle, baseline),
        "files": {str(path): evaluate_frame(group, bundle, baseline) for path, group in frame.groupby("source_file", sort=False)},
        "baseline_regions": baseline,
        "optimized_regions": optimized_regions,
        "conditional_confusion": location_confusion(probability, actual, states, bundle["mode"], active),
        "system_confusion": location_confusion(probability, actual, states, bundle["mode"], active, system=True),
        "limitations": [
            "Raw force estimates are emitted outside the verified force scope; force metrics exclude those rows.",
            "Class0 uses the declared class-argmax decision rule; deployment gate calibration is not established by replay.",
            "Masked outputs are conditional location diagnostics without a deployment load detector.",
            "A test set containing only ID18 does not independently validate body-wide location accuracy or the three-region boundaries.",
            "Region boundaries are frozen from validation; validation search scores are not independent test results.",
        ],
    }
    if optimized_regions is not None:
        report["optimized_overall"] = evaluate_frame(frame, bundle, optimized_regions)
        report["optimized_files"] = {str(path): evaluate_frame(group, bundle, optimized_regions) for path, group in frame.groupby("source_file", sort=False)}
    return report


def predict_checkpoint(checkpoint: str | Path, input_dir: str | Path,
                       output: str | Path | None = None, device: str | None = None) -> Path:
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    model, bundle = restore_bundle(checkpoint, device)
    paths = sorted(Path(input_dir).resolve().glob("*.csv"))
    if not paths:
        raise ValueError(f"No CSV files found in {input_dir}")
    trials = load_prediction_trials(paths, bundle["config"], bundle["calibration"])
    _assert_held_out(trials, bundle)
    frame = predict_trials(model, bundle, trials, checkpoint, device=device)
    destination = fresh_directory("predict", output)
    frame.to_csv(destination / "predictions.csv", index=False)
    write_json(destination / "metrics.json", {"checkpoint": str(Path(checkpoint).resolve()), **prediction_report(frame, bundle, None)})
    write_json(destination / "input_manifest.json", [trial.info for trial in trials])
    return destination


def select_comparison_rows(comparison: pd.DataFrame, force_tolerance_mN: float = DEFAULT_FORCE_TOLERANCE_MN,
                           location_metric: str = 'location_macro_recall') -> list[tuple[int, pd.Series]]:
    """Select one existing pair per mode using validation columns only.

    The default 1e-3 mN (1 micro-newton) window absorbs CUDA rounding drift
    between independent same-seed force runs. It is a numerical tie policy,
    not a clinically meaningful performance margin or statistical equivalence.
    """
    if location_metric not in ('location_macro_recall', 'load_balanced_accuracy'):
        raise ValueError('Location selection must use a supported validation metric')
    if location_metric == 'load_balanced_accuracy' and set(comparison['mode']) != {'class0'}:
        raise ValueError('Load-balanced selection requires class0-only comparison rows')
    required = {"mode", "force_rmse_xyz_mN", location_metric, "force_model", "location_model", "bundle"}
    missing = required - set(comparison.columns)
    if missing:
        raise ValueError(f"Missing validation comparison fields: {sorted(missing)}")
    if force_tolerance_mN < 0 or not np.isfinite(force_tolerance_mN):
        raise ValueError("force_tolerance_mN must be finite and nonnegative")
    valid = comparison.copy()
    if "status" in valid:
        valid = valid.loc[valid["status"] == "complete"]
    valid = valid.loc[np.isfinite(valid["force_rmse_xyz_mN"]) & np.isfinite(valid[location_metric])]
    if valid.empty:
        raise ValueError("No complete comparison row has finite validation force and location metrics")
    selected = []
    for mode, rows in valid.groupby("mode", sort=True):
        if mode not in ("masked", "class0"):
            raise ValueError(f"Unsupported location mode in comparison: {mode}")
        minimum = rows["force_rmse_xyz_mN"].min()
        candidates = rows.loc[rows["force_rmse_xyz_mN"] <= minimum + force_tolerance_mN].copy()
        order, ascending = [location_metric], [False]
        if "location_validation_ce" in candidates:
            order.append("location_validation_ce")
            ascending.append(True)
        order.extend(["force_model", "location_model", "bundle"])
        ascending.extend([True, True, True])
        chosen = candidates.sort_values(order, ascending=ascending, kind="mergesort", na_position="last").iloc[0]
        selected.append((chosen.name, chosen))
    return selected


def select_and_evaluate(train_dir: str | Path, output: str | Path | None = None,
                        device: str | None = None, location_metric: str = 'location_macro_recall') -> Path:
    """Freeze mode-wise validation selections and evaluate their intact bundles."""
    train_dir = Path(train_dir).resolve()
    comparison_path = train_dir / "comparison.csv"
    comparison = pd.read_csv(comparison_path)
    selected = select_comparison_rows(comparison, location_metric=location_metric)
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    destination = fresh_directory("predict", output)
    all_frames, reports, selection, comparison_updates = [], {}, [], {}
    comparison["selected_for_test"] = False
    for index, row in selected:
        checkpoint = Path(row["bundle"])
        if not checkpoint.is_absolute():
            possibilities = [ROOT / checkpoint, train_dir / checkpoint]
            checkpoint = next((path for path in possibilities if path.exists()), possibilities[0])
        model, bundle = restore_bundle(checkpoint, device)
        if (bundle["mode"], bundle["force_name"], bundle["location_name"]) != (row["mode"], row["force_model"], row["location_model"]):
            raise ValueError("Selected comparison row does not match the saved bundle")
        with np.load(checkpoint.parent / "validation_predictions.npz", allow_pickle=False) as validation:
            region_search = optimize_regions(
                validation["location_probabilities"], validation["actual_ids"], validation["load_state"],
                bundle["mode"], bundle["config"].get("active_ids", list(range(1, 19))),
                min_segments=int(bundle["config"].get("region_search_min_segments", 3)), split="validation",
            )
        known = _known_trials(bundle)
        paths = [_path(known[position]["path"], bundle) for position in bundle.get("split", {}).get("test", [])]
        if not paths:
            raise ValueError("Selected bundle has no frozen held-out test trials")
        trials = load_prediction_trials(paths, bundle["config"], bundle["calibration"])
        expected_hashes = {known[position]["path"]: known[position]["sha256"] for position in bundle["split"]["test"]}
        for trial, old in zip(trials, (known[position] for position in bundle["split"]["test"])):
            if trial.sha256 != old["sha256"]:
                raise ValueError(f"Frozen test CSV changed since training: {trial.path}")
        _assert_held_out(trials, bundle)
        optimized = region_search["selected_regions"]
        frame = predict_trials(model, bundle, trials, checkpoint, optimized, device)
        report = prediction_report(frame, bundle, optimized)
        report["validation_region_search"] = region_search
        reports[bundle["mode"]] = report
        all_frames.append(frame)
        comparison.loc[index, "selected_for_test"] = True
        updated = {}
        for prefix, metrics in (("test_", report["overall"]), ("test_optimized_", report.get("optimized_overall", {}))):
            for key, value in metrics.items():
                if prefix == "test_optimized_" and not (key.startswith("region_") or key in ("system_region_accuracy", "system_loaded_region_accuracy")):
                    continue
                updated[prefix + key] = value
        if optimized is not None:
            updated["optimized_region_lower_end"] = max(optimized["lower"])
            updated["optimized_region_middle_end"] = max(optimized["middle"])
            updated["optimized_region_validation_id_macro_recall"] = region_search["selected_metrics"]["region_id_macro_recall"]
            updated["optimized_region_validation_balanced_id_macro_recall"] = region_search["selected_metrics"]["region_balanced_id_macro_recall"]
        comparison_updates[index] = updated
        selection.append({"comparison_row": int(index), "mode": bundle["mode"], "checkpoint": str(checkpoint.resolve()),
                          "validation_force_rmse_xyz_mN": row["force_rmse_xyz_mN"],
                          "validation_location_macro_recall": row["location_macro_recall"],
                          "location_selection_metric": location_metric,
                          "validation_location_selection_score": row[location_metric],
                          "validation_location_ce": row.get("location_validation_ce"),
                          "test_files": expected_hashes})
        del model
    pd.concat(all_frames, ignore_index=True).to_csv(destination / "predictions.csv", index=False)
    write_json(destination / "metrics.json", {
        "training_directory": str(train_dir),
        "selection_rule": f"Within each mode: lowest validation pooled force RMSE (absolute numerical tie tolerance 1e-3 mN = 1 micro-newton), then highest validation {location_metric}, lowest location CE, and deterministic model names; use the intact pair bundle. The tolerance handles floating-point drift, not a performance-equivalence margin.",
        "force_numerical_tie_tolerance_mN": DEFAULT_FORCE_TOLERANCE_MN,
        "selection": selection, "modes": reports,
    })
    updates = pd.DataFrame.from_dict(comparison_updates, orient="index").reindex(comparison.index)
    comparison = pd.concat([comparison.drop(columns=updates.columns.intersection(comparison.columns)), updates], axis=1)
    comparison.to_csv(comparison_path, index=False)
    return destination


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument("--checkpoint")
    choice.add_argument("--train-dir", help="Select by validation and evaluate the saved test manifest")
    parser.add_argument("--input-dir", default="datasets/test")
    parser.add_argument("--output")
    parser.add_argument("--device", choices=["cpu", "cuda"])
    parser.add_argument("--location-selection-metric", default='location_macro_recall',
                        choices=['location_macro_recall', 'load_balanced_accuracy'])
    args = parser.parse_args(argv)
    destination = select_and_evaluate(args.train_dir, args.output, args.device, args.location_selection_metric) if args.train_dir else predict_checkpoint(args.checkpoint, args.input_dir, args.output, args.device)
    print(f"Predictions and evaluation: {destination}")


if __name__ == "__main__":
    main()
