"""Inspect actual XLSX XML to catch streaming loss, formulas, and blank/zero bugs."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
import pandas as pd

from hrm_force.excel_writer import WorkbookWriter


NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def cells(root):
    return {cell.attrib["r"]: cell for cell in root.findall(".//x:sheetData/x:row/x:c", NS)}


def text(cell):
    return "".join(node.text or "" for node in cell.findall(".//x:t", NS))


class WorkbookWriterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "predictions.xlsx"

    def test_streamed_rows_preserve_all_columns_and_distinguish_zero_from_blank(self):
        frame = pd.DataFrame({"file_id": [1, 1, 2], "row": [0, 1, 2],
                              "fx_mN": [0., 0.123456789012345, -12.3456789012345],
                              "actual_id": [0., np.nan, 18.]})
        with WorkbookWriter(self.path, {"purpose": "comparison"}, [{"file_id": 1, "source_file": "one.csv"}]) as writer:
            manifest = writer.write_table("TCN", frame, {"nullable_columns": ["actual_id"], "model": "tcn"})
        self.assertEqual(manifest["rows"], 3)
        self.assertEqual(manifest["columns"], frame.columns.tolist())
        self.assertEqual(manifest["null_counts"], {"actual_id": 1})
        with zipfile.ZipFile(self.path) as archive:
            root = ET.fromstring(archive.read("xl/worksheets/sheet3.xml"))
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        self.assertEqual([node.attrib["name"] for node in workbook.findall("x:sheets/x:sheet", NS)], ["_INFO", "_FILES", "TCN"])
        values = cells(root)
        self.assertEqual(text(values["A1"]), "file_id")
        self.assertEqual(text(values["D1"]), "actual_id")
        self.assertIsNotNone(values["A1"].attrib.get("s"))
        self.assertEqual(values["D2"].find("x:v", NS).text, "0")
        self.assertNotIn("D3", values)
        self.assertEqual(values["D4"].find("x:v", NS).text, "18")
        self.assertAlmostEqual(float(values["C3"].find("x:v", NS).text), frame.loc[1, "fx_mN"], places=14)
        self.assertEqual(len(root.findall("x:sheetData/x:row", NS)), 4)
        self.assertEqual(root.find("x:autoFilter", NS).attrib["ref"], "A1:D4")
        self.assertEqual(root.find("x:sheetViews/x:sheetView/x:pane", NS).attrib["ySplit"], "1")

    def test_formula_and_url_like_sources_are_literal_strings(self):
        source = '=HYPERLINK("https://example.org", "x")'
        with WorkbookWriter(self.path, {"note": "=2+2"}, [{"file_id": 1, "source_file": source}]) as writer:
            writer.write_table("literal", pd.DataFrame({"label": ["=1+1", "https://example.org"], "value": [0, 1]}), {})
        with zipfile.ZipFile(self.path) as archive:
            for filename in ["xl/worksheets/sheet1.xml", "xl/worksheets/sheet2.xml", "xl/worksheets/sheet3.xml"]:
                root = ET.fromstring(archive.read(filename))
                self.assertFalse(root.findall(".//x:f", NS))
                self.assertFalse(root.findall(".//x:hyperlink", NS))
            root = ET.fromstring(archive.read("xl/worksheets/sheet2.xml"))
        self.assertEqual(text(cells(root)["B2"]), source)

    def test_existing_file_is_not_overwritten(self):
        self.path.write_bytes(b"preserve this original")
        with self.assertRaises(FileExistsError):
            WorkbookWriter(self.path, {}, [])
        self.assertEqual(self.path.read_bytes(), b"preserve this original")

    def test_row_limit_includes_header_and_sheet_names_are_guarded(self):
        with WorkbookWriter(self.path, {}, []) as writer:
            with patch("hrm_force.excel_writer.MAX_EXCEL_ROWS", 3):
                with self.assertRaisesRegex(ValueError, "at most 2"):
                    writer.write_table("too_long", pd.DataFrame({"x": [1, 2, 3]}), {})
            for name in ["a" * 32, "bad/name", "_info", "'quoted", ""]:
                with self.assertRaises(ValueError):
                    writer.write_table(name, pd.DataFrame({"x": [1]}), {})
            writer.write_table("GRU", pd.DataFrame({"x": [1]}), {})
            with self.assertRaisesRegex(ValueError, "Duplicate"):
                writer.write_table("gru", pd.DataFrame({"x": [2]}), {})

    def test_missing_infinity_and_unsupported_objects_fail_explicitly(self):
        with WorkbookWriter(self.path, {}, []) as writer:
            with self.assertRaisesRegex(ValueError, "nonnullable"):
                writer.write_table("nan", pd.DataFrame({"force": [np.nan]}), {})
            with self.assertRaisesRegex(ValueError, "Infinity"):
                writer.write_table("inf", pd.DataFrame({"force": [np.inf]}), {"nullable_columns": ["force"]})
            with self.assertRaises(TypeError):
                writer.write_table("object", pd.DataFrame({"force": [{"unexpected": 1}]}), {})
            with self.assertRaisesRegex(ValueError, "exact Excel"):
                writer.write_table("huge_integer", pd.DataFrame({"timestamp": [1_790_000_000_000_000_001]}), {})
            with self.assertRaisesRegex(ValueError, "not present"):
                writer.write_table("wrong_nullable", pd.DataFrame({"x": [1]}), {"nullable_columns": ["missing"]})

    def test_nullable_extension_dtype_and_repeated_close(self):
        writer = WorkbookWriter(self.path, {"timestamp_identity_ns": 1_790_000_000_000_000_001}, [])
        writer.write_table("nullable", pd.DataFrame({"id": pd.Series([0, pd.NA, 18], dtype="Int64")}), {"nullable_columns": ["id"]})
        writer.close()
        writer.close()
        with self.assertRaisesRegex(ValueError, "closed"):
            writer.write_table("new", pd.DataFrame({"x": [1]}), {})
        with zipfile.ZipFile(self.path) as archive:
            root = ET.fromstring(archive.read("xl/worksheets/sheet3.xml"))
        self.assertEqual(cells(root)["A2"].find("x:v", NS).text, "0")
        self.assertNotIn("A3", cells(root))


if __name__ == "__main__":
    unittest.main()
