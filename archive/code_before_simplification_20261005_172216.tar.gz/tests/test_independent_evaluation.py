"""Verify metric populations, original probability mass, and boundary search."""

import unittest

import numpy as np

from hrm_force.independent_evaluation import (
    force_metrics, location_confusion, location_metrics, location_predictions,
    optimize_regions, region_probabilities,
)


class IndependentEvaluationTests(unittest.TestCase):
    def test_force_pooled_definition_units_and_separate_validity(self):
        prediction = np.array([[0.003, 0.004, 0.0], [9.0, 9.0, 9.0]])
        target = np.zeros((2, 3))
        result = force_metrics(prediction, target, valid=[True, False])
        self.assertEqual(result["force_support"], 1)
        self.assertEqual(result["force_excluded"], 1)
        self.assertEqual(result["force_rmse_fx_mN"], 3.0)
        self.assertEqual(result["force_mae_fy_mN"], 4.0)
        self.assertAlmostEqual(result["force_rmse_xyz_mN"], np.sqrt(25 / 3))
        self.assertAlmostEqual(result["force_mae_xyz_mN"], 7 / 3)
        self.assertNotAlmostEqual(result["force_rmse_xyz_mN"], 5.0)

    def test_invalid_force_target_is_excluded_but_model_nan_fails(self):
        target = np.array([[np.nan, 0.0, 0.0]])
        result = force_metrics(np.ones((1, 3)), target)
        self.assertEqual(result["force_support"], 0)
        self.assertTrue(np.isnan(result["force_rmse_xyz_mN"]))
        with self.assertRaisesRegex(ValueError, "Nonfinite"):
            force_metrics(target, np.zeros((1, 3)))
        with self.assertRaisesRegex(ValueError, "boolean"):
            force_metrics(np.zeros((1, 3)), np.zeros((1, 3)), [np.nan])

    def test_class0_diagnostics_do_not_hide_detection_failure(self):
        probabilities = np.array([
            [0.60, 0.25, 0.15],  # GT 5, predicts no-load; conditional 5 is right.
            [0.10, 0.20, 0.70],  # GT 18, detected and located.
            [0.80, 0.10, 0.10],  # Correct no-load.
            [0.10, 0.80, 0.10],  # No-load false alarm.
            [0.10, 0.80, 0.10],  # Uncertain: not an evaluable label.
        ])
        actual = np.array([5, 18, 5, 18, 5])
        original = actual.copy()
        states = ["loaded", "loaded", "unloaded", "unloaded", "uncertain"]
        result = location_metrics(probabilities, actual, states, "class0", [5, 18])
        self.assertEqual(result["location_support"], 2)
        self.assertEqual(result["location_accuracy"], 1.0)
        self.assertEqual(result["system_loaded_id_accuracy"], 0.5)
        self.assertEqual(result["system_id_accuracy"], 0.5)
        for name in ("tp", "tn", "fp", "fn"):
            self.assertEqual(result[f"load_{name}"], 1)
        self.assertEqual(result["load_balanced_accuracy"], 0.5)
        self.assertEqual(result["unload_precision"], 0.5)
        self.assertEqual(result["unload_recall"], 0.5)
        self.assertEqual(result["location_uncertain_support"], 1)
        np.testing.assert_array_equal(actual, original)

    def test_masked_probabilities_cannot_be_used_as_a_load_detector(self):
        probability = np.array([[0.999, 0.001], [0.2, 0.8]])
        result = location_metrics(probability, [5, 18], [0, 1], "masked", [5, 18])
        self.assertEqual(result["location_accuracy"], 1.0)
        self.assertFalse(result["system_available"])
        self.assertEqual(result["system_decision_rule"], "unavailable")
        for key in ("load_precision", "load_support", "system_id_accuracy", "unload_recall"):
            self.assertTrue(np.isnan(result[key]))
        decoded = location_predictions(probability, "masked", [5, 18])
        self.assertTrue(np.isnan(decoded["final_id"]).all())
        self.assertTrue(np.isnan(decoded["no_load_probability"]).all())

    def test_real_segment_distance_and_absent_classes(self):
        result = location_metrics([[0.1, 0.9]], [5], [1], "masked", [5, 18])
        self.assertEqual(result["location_within1_accuracy"], 0.0)
        self.assertEqual(result["location_macro_class_count"], 1)
        self.assertEqual(result["location_id_18_support"], 0)
        self.assertTrue(np.isnan(result["location_id_18_recall"]))
        self.assertFalse(result["location_id_01_supported"])

    def test_outside_loaded_id_never_becomes_no_load(self):
        result = location_metrics([[0.9, 0.05, 0.05]], [1], [1], "class0", [5, 18])
        self.assertEqual(result["location_loaded_outside_support"], 1)
        self.assertEqual(result["location_support"], 0)
        self.assertEqual(result["load_support"], 0)
        self.assertEqual(result["system_support"], 0)
        self.assertTrue(np.isnan(result["system_id_accuracy"]))

    def test_region_probability_sums_preserve_p0_and_global_candidate(self):
        # Global ID5 wins, but the middle region has the largest probability sum.
        probability = np.array([[0.20, 0.30, 0.25, 0.25]])
        copy = probability.copy()
        ids = [5, 11, 12]
        sums = region_probabilities(probability, "class0", ids)
        self.assertAlmostEqual(sum(values[0] for values in sums.values()), 0.8)
        self.assertAlmostEqual(sums["middle"][0], 0.5)
        decoded = location_predictions(probability, "class0", ids)
        self.assertEqual(decoded["conditional_id"][0], 5)
        self.assertEqual(decoded["final_id"][0], 5)
        self.assertEqual(decoded["conditional_region_index"][0], 1)
        self.assertTrue(np.isnan(decoded["segment_probabilities"][0, 0]))
        result = location_metrics(probability, [11], ["loaded"], "class0", ids)
        self.assertEqual(result["location_accuracy"], 0.0)
        self.assertEqual(result["region_accuracy"], 1.0)
        self.assertAlmostEqual(result["region_true_probability_mean"], 0.5)
        np.testing.assert_array_equal(probability, copy)

    def test_region_id_macro_recall_does_not_weight_by_trial_length(self):
        probabilities = np.vstack([np.tile([1.0, 0.0], (9, 1)), [1.0, 0.0]])
        actual = [5] * 9 + [18]
        result = location_metrics(probabilities, actual, [1] * 10, "masked", [5, 18])
        self.assertAlmostEqual(result["region_accuracy"], 0.9)
        self.assertAlmostEqual(result["region_id_macro_recall"], 0.5)

    def test_balanced_region_score_does_not_reward_an_always_lower_predictor(self):
        ids = list(range(1, 19))
        probability = np.zeros((18, 18))
        probability[:, 0] = 1.0
        for lower_end, middle_end in ((10, 15), (12, 15)):
            groups = {"lower": list(range(1, lower_end + 1)),
                      "middle": list(range(lower_end + 1, middle_end + 1)),
                      "upper": list(range(middle_end + 1, 19))}
            result = location_metrics(probability, ids, [1] * 18, "masked", ids, groups)
            self.assertAlmostEqual(result["region_id_macro_recall"], lower_end / 18)
            self.assertAlmostEqual(result["region_balanced_id_macro_recall"], 1 / 3)
            self.assertEqual(result["region_lower_id_macro_recall"], 1.0)
            self.assertEqual(result["region_middle_id_macro_recall"], 0.0)
            self.assertEqual(result["region_upper_id_macro_recall"], 0.0)
        search = optimize_regions(probability, ids, [1] * 18, "masked", ids)
        for row in search["candidates"]:
            self.assertAlmostEqual(row["region_balanced_id_macro_recall"], 1 / 3)

    def test_balanced_region_score_weights_ids_before_regions(self):
        ids = [1, 2, 11, 18]
        actual = [1] * 99 + [2, 11, 18]
        probability = np.zeros((102, 4))
        probability[:99, 2] = 1.0  # Lower ID1 is mistaken for middle.
        probability[99:, :] = np.eye(4)[[1, 2, 3]]
        result = location_metrics(probability, actual, [1] * 102, "masked", ids)
        self.assertAlmostEqual(result["region_lower_recall"], 0.01)
        self.assertAlmostEqual(result["region_lower_id_macro_recall"], 0.5)
        self.assertAlmostEqual(result["region_balanced_id_macro_recall"], (0.5 + 1 + 1) / 3)
        only_tip = location_metrics([[0.0, 0.0, 0.0, 1.0]], [18], [1], "masked", ids)
        self.assertTrue(np.isnan(only_tip["region_lower_id_macro_recall"]))
        self.assertTrue(np.isnan(only_tip["region_balanced_id_macro_recall"]))

    def test_confusion_matches_diagnostic_and_system_populations(self):
        probability = [[0.8, 0.1, 0.1], [0.1, 0.1, 0.8]]
        conditional = location_confusion(probability, [5, 5], [1, 0], "class0", [5, 18])
        self.assertEqual(conditional["labels"], [5, 18])
        self.assertEqual(conditional["matrix"], [[1, 0], [0, 0]])
        system = location_confusion(probability, [5, 5], [1, 0], "class0", [5, 18], system=True)
        self.assertEqual(system["labels"], [0, 5, 18])
        self.assertEqual(system["matrix"], [[0, 0, 1], [1, 0, 0], [0, 0, 0]])
        unavailable = location_confusion([[1.0]], [5], [1], "masked", [5], system=True)
        self.assertFalse(unavailable["available"])

    def test_probability_and_group_contracts_are_validated(self):
        for probability in ([[2.0, -1.0]], [[np.nan, 1.0]], [[0.1, 0.1]]):
            with self.assertRaises(ValueError):
                location_predictions(probability, "masked", [5, 18])
        with self.assertRaisesRegex(ValueError, "overlap"):
            region_probabilities([[0.5, 0.5]], "masked", [5, 18], {"a": [5, 18], "b": [18]})
        with self.assertRaisesRegex(ValueError, "cover"):
            region_probabilities([[0.5, 0.5]], "masked", [5, 18], {"a": [5]})
        with self.assertRaisesRegex(ValueError, "load_state"):
            location_metrics([[1.0]], [5], [np.nan], "masked", [5])

    def test_empty_evaluation_is_explicitly_undefined(self):
        result = location_metrics(np.empty((0, 18)), [], [], "masked", list(range(1, 19)))
        self.assertEqual(result["location_support"], 0)
        self.assertTrue(np.isnan(result["location_accuracy"]))
        self.assertTrue(np.isnan(result["region_predicted_probability_mean"]))
        result = force_metrics(np.empty((0, 3)), np.empty((0, 3)))
        self.assertEqual(result["force_support"], 0)

    def test_region_search_keeps_all_boundaries_constraints_and_baseline(self):
        ids = list(range(1, 19))
        result = optimize_regions(np.eye(18), ids, [1] * 18, "masked", ids)
        self.assertEqual(len(result["candidates"]), 136)
        self.assertEqual(sum(row["meets_min_segments"] for row in result["candidates"]), 55)
        self.assertEqual(sum(row["selected"] for row in result["candidates"]), 1)
        selected = next(row for row in result["candidates"] if row["selected"])
        self.assertEqual((selected["lower_end"], selected["middle_end"]), (10, 15))
        self.assertEqual(result["selection_split"], "validation")
        self.assertEqual(result["selection_metric"], "region_balanced_id_macro_recall")
        self.assertEqual(selected["location_id_18_support"], 1)
        self.assertEqual(result["baseline_metrics"]["region_accuracy"], 1.0)

    def test_region_search_requires_validation_and_support_in_all_regions(self):
        with self.assertRaisesRegex(ValueError, "validation"):
            optimize_regions([[1.0]], [18], [1], "masked", [18], split="test")
        result = optimize_regions([[1.0]], [18], [1], "masked", [18])
        self.assertIsNone(result["selected_regions"])
        self.assertEqual(result["selection_status"], "no_eligible_candidate")
        self.assertEqual(len(result["candidates"]), 136)
        self.assertTrue(all(row["location_id_01_support"] == 0 for row in result["candidates"]))
        self.assertTrue(all(np.isnan(row["region_id_01_recall"]) for row in result["candidates"]))

    def test_region_search_uses_the_same_probability_tie_rule_as_inference(self):
        ids = list(range(1, 19))
        probabilities = np.full((18, 18), 1 / 18)
        result = optimize_regions(probabilities, ids, [1] * 18, "masked", ids)
        equal_bins = next(row for row in result["candidates"] if (row["lower_end"], row["middle_end"]) == (6, 12))
        expected = location_metrics(probabilities, ids, [1] * 18, "masked", ids,
                                    {"lower": list(range(1, 7)), "middle": list(range(7, 13)), "upper": list(range(13, 19))})
        for segment in ids:
            key = f"region_id_{segment:02d}_recall"
            self.assertEqual(equal_bins[key], expected[key])


if __name__ == "__main__":
    unittest.main()
