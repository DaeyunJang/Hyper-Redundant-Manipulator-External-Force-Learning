"""Verify independence, causal history, configuration and checkpoint reconstruction."""
import io
import unittest

import torch
from torch import nn

from hrm_force.independent_models import (
    DEFAULT_PARAMS, MODEL_NAMES, HRMEstimator, build_branch, build_estimator,
)
from hrm_force.models import build_model


class IndependentModelsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_threads = torch.get_num_threads()
        torch.set_num_threads(1)

    @classmethod
    def tearDownClass(cls):
        torch.set_num_threads(cls.original_threads)

    def test_defaults_reproduce_existing_force_only_models(self):
        x = torch.randn(2, 7, 4)
        for name in MODEL_NAMES:
            with self.subTest(name=name):
                torch.manual_seed(73)
                original = build_model(name, 4, task="force_only", seq_len=7).eval()
                torch.manual_seed(73)
                independent = build_branch(name, 4, 7, 3).eval()
                self.assertEqual(independent.params, DEFAULT_PARAMS[name])
                with torch.no_grad():
                    torch.testing.assert_close(original(x)["force"], independent(x), rtol=0, atol=0)

    def test_each_model_supports_force_and_class0_outputs_and_backward(self):
        for name in MODEL_NAMES:
            with self.subTest(name=name):
                estimator = build_estimator(name, name, 8, 6, 19)
                output = estimator(torch.randn(2, 6, 8))
                self.assertEqual(set(output), {"force", "location_logits"})
                self.assertEqual(output["force"].shape, (2, 3))
                self.assertEqual(output["location_logits"].shape, (2, 19))
                loss = output["force"].square().mean() + nn.functional.cross_entropy(
                    output["location_logits"], torch.tensor([0, 18]))
                loss.backward()
                for parameter in estimator.parameters():
                    self.assertIsNotNone(parameter.grad)
                    self.assertTrue(torch.isfinite(parameter.grad).all())

    def test_branch_updates_do_not_run_or_change_other_branch(self):
        for active_name, inactive_name in (("force_net", "location_net"),
                                            ("location_net", "force_net")):
            with self.subTest(active=active_name):
                estimator = build_estimator("transformer", "transformer", 4, 6, 18)
                active, inactive = getattr(estimator, active_name), getattr(estimator, inactive_name)
                before = {key: value.clone() for key, value in inactive.state_dict().items()}
                calls = []
                hook = inactive.register_forward_hook(lambda *_: calls.append(True))
                optimizer = torch.optim.Adam(active.parameters(), lr=0.01)
                optimizer.zero_grad()
                active(torch.randn(2, 6, 4)).square().mean().backward()
                optimizer.step()
                hook.remove()
                self.assertFalse(calls)
                self.assertTrue(all(parameter.grad is None for parameter in inactive.parameters()))
                for key, value in inactive.state_dict().items():
                    torch.testing.assert_close(value, before[key], rtol=0, atol=0)
                active_storage = {v.untyped_storage().data_ptr() for v in active.state_dict().values()}
                inactive_storage = {v.untyped_storage().data_ptr() for v in inactive.state_dict().values()}
                self.assertFalse(active_storage & inactive_storage)

    def test_shared_parameters_buffers_and_storage_aliases_rejected(self):
        branch = build_branch("mlp", 4, 6, 3)
        with self.assertRaises(ValueError):
            HRMEstimator(branch, branch)
        other = build_branch("mlp", 4, 6, 3)
        other.head.weight = nn.Parameter(branch.head.weight.detach())
        with self.assertRaises(ValueError):
            HRMEstimator(branch, other)
        first = build_branch("transformer", 4, 6, 3)
        second = build_branch("transformer", 4, 6, 18)
        second.encoder.causal_mask = first.encoder.causal_mask
        with self.assertRaises(ValueError):
            HRMEstimator(first, second)

    def test_configurable_architectures_remain_causal_and_reload_exactly(self):
        overrides = {
            "mlp": {"hidden_dims": [16, 7]},
            "cnn": {"channels": 12, "kernel_size": 5, "num_layers": 3},
            "convmixer": {"channels": 12, "num_blocks": 2},
            "resnet": {"channels": 12, "num_blocks": 3},
            "lstm": {"hidden_sizes": [12, 7, 5], "projection_dim": 9},
            "gru": {"hidden_sizes": [12], "projection_dim": 9},
            "tcn": {"channels": 12, "kernel_size": 5, "dilations": [1, 3]},
            "transformer": {"d_model": 15, "nhead": 3, "dim_feedforward": 24,
                            "dropout": 0.0, "num_layers": 2},
            "kalmannet": {"hidden_sizes": [12, 7], "projection_dim": None},
            "small_gru": {"hidden_sizes": [12, 7]},
            "residual_tcn": {"channels": 12, "dilations": [1, 3]},
        }
        for name, params in overrides.items():
            with self.subTest(name=name):
                branch = build_branch(name, 4, 8, 19, params).eval()
                x = torch.randn(2, 8, 4)
                changed = x.clone()
                changed[:, 5:] += 100
                with torch.no_grad():
                    torch.testing.assert_close(branch.encode_sequence(x)[:, :5],
                                               branch.encode_sequence(changed)[:, :5],
                                               atol=1e-5, rtol=1e-5)
                restored = build_branch(name, 4, 8, 19, branch.params).eval()
                restored.load_state_dict(branch.state_dict())
                with torch.no_grad():
                    self.assertEqual(branch(x).shape, (2, 19))
                    torch.testing.assert_close(branch(x), restored(x), rtol=0, atol=0)

    def test_bundle_round_trip_contains_both_independent_states(self):
        estimator = build_estimator("lstm", "transformer", 4, 5, 19,
                                    force_params={"hidden_sizes": [11]}).eval()
        bundle = {"state_dict": estimator.state_dict(),
                  "force_params": estimator.force_net.params,
                  "location_params": estimator.location_net.params}
        buffer = io.BytesIO()
        torch.save(bundle, buffer)
        buffer.seek(0)
        restored_bundle = torch.load(buffer, weights_only=True)
        restored = build_estimator("lstm", "transformer", 4, 5, 19,
                                   force_params=restored_bundle["force_params"],
                                   location_params=restored_bundle["location_params"]).eval()
        restored.load_state_dict(restored_bundle["state_dict"])
        x = torch.randn(2, 5, 4)
        with torch.no_grad():
            for key, value in estimator(x).items():
                torch.testing.assert_close(value, restored(x)[key], rtol=0, atol=0)

    def test_branch_initialization_is_partner_independent_and_preserves_rng(self):
        torch.manual_seed(107)
        before = torch.random.get_rng_state().clone()
        first = build_estimator("gru", "mlp", 4, 6, 18)
        torch.testing.assert_close(torch.random.get_rng_state(), before, rtol=0, atol=0)
        second = build_estimator("gru", "transformer", 4, 6, 19)
        for key, value in first.force_net.state_dict().items():
            torch.testing.assert_close(value, second.force_net.state_dict()[key], rtol=0, atol=0)
        third = build_estimator("cnn", "transformer", 4, 6, 19)
        for key, value in second.location_net.state_dict().items():
            torch.testing.assert_close(value, third.location_net.state_dict()[key], rtol=0, atol=0)

    def test_mlp_history_is_ignored_and_force_output_is_unclipped(self):
        branch = build_branch("mlp", 4, 6, 3).eval()
        x = torch.randn(2, 6, 4)
        changed = x.clone()
        changed[:, :-1] = 1000
        with torch.no_grad():
            torch.testing.assert_close(branch(x), branch(changed), rtol=0, atol=0)
            branch.head.weight.zero_()
            branch.head.bias.copy_(torch.tensor([-2.0, 0.0, 3.0]))
            torch.testing.assert_close(branch(x), torch.tensor([[-2., 0., 3.]]).expand(2, 3))

    def test_configuration_and_input_errors_are_explicit(self):
        invalid = [
            ("unknown", {}), ("mlp", {"width": 16}), ("mlp", {"hidden_dims": []}),
            ("cnn", {"channels": True}), ("lstm", {"hidden_sizes": [0]}),
            ("gru", {"projection_dim": -1}), ("tcn", {"dilations": "1,2,4"}),
            ("transformer", {"d_model": 15}), ("transformer", {"dropout": 1.0}),
            ("transformer", {"dropout": float("nan")}),
        ]
        for name, params in invalid:
            with self.subTest(name=name, params=params), self.assertRaises(ValueError):
                build_branch(name, 4, 6, 3, params)
        for dimensions in ((0, 6, 3), (4, False, 3), (4, 6, 0)):
            with self.subTest(dimensions=dimensions), self.assertRaises(ValueError):
                build_branch("mlp", *dimensions)
        branch = build_branch("mlp", 4, 6, 3)
        for x in (torch.zeros(2, 4), torch.zeros(2, 0, 4), torch.zeros(2, 6, 3)):
            with self.assertRaises(ValueError):
                branch(x)
        with self.assertRaises(ValueError):
            build_branch("transformer", 4, 6, 3)(torch.zeros(2, 7, 4))


if __name__ == "__main__":
    unittest.main()
