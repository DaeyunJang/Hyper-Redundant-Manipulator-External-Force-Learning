"""Aligned export rows retain GT/prediction meaning and real signal gaps."""

import unittest
from types import SimpleNamespace

import numpy as np

from hrm_force.excel_tables import force_table, id_table


def trial(*, path="/recording/example.csv", raw=1, effective=18, rows=8):
    return SimpleNamespace(
        path=path, segment_id_raw=raw, effective_id=effective,
        x=np.arange(rows * 2, dtype=np.float32).reshape(rows, 2),
        force=np.arange(rows * 3, dtype=np.float32).reshape(rows, 3) / 123.0,
        timestamps=np.arange(rows, dtype=np.int64) * 10_000_000,
        input_valid=np.ones(rows, dtype=bool), force_valid=np.ones(rows, dtype=bool),
        load_state=np.ones(rows, dtype=np.int8), endpoints=np.arange(rows),
        info={"median_dt_ms": 10.0},
    )


class ExcelTablesTests(unittest.TestCase):
    def test_force_preserves_original_refs_uncertain_and_float64_conversion(self):
        source = trial()
        source.load_state[[1, 3]] = [0, -1]
        refs = np.array([[0, 1], [0, 3], [0, 4]])
        prediction = source.force[[1, 3, 4]].copy() + np.float32(.001)
        result = force_table([source], refs, prediction)
        self.assertEqual(result.source_file.tolist(), ["example.csv"] * 3)
        self.assertEqual(result.source_row.tolist(), [1, 3, 4])
        np.testing.assert_allclose(result.elapsed_s, [.01, .03, .04])
        self.assertEqual(result.load_state.tolist(), ["unloaded", "uncertain", "loaded"])
        self.assertEqual(result.continuous_block.tolist(), [1, 2, 2])
        np.testing.assert_array_equal(
            result[["gt_fx_mN", "gt_fy_mN", "gt_fz_mN"]], source.force[[1, 3, 4]].astype(np.float64) * 1000,
        )
        np.testing.assert_array_equal(
            result[["pred_fx_mN", "pred_fy_mN", "pred_fz_mN"]], prediction.astype(np.float64) * 1000,
        )
        self.assertEqual(result.attrs["force_unit"], "mN")
        self.assertGreater(result.loc[0, "pred_fx_mN"], 0)  # No zeroing unloaded predictions.

    def test_continuity_splits_files_missing_rows_reversed_time_and_large_gap(self):
        first, second = trial(), trial(path="/other/example.csv")
        first.timestamps = np.array([0, 10, 20, 30, 30, 70, 80, 90], dtype=np.int64) * 1_000_000
        refs = np.array([[0, 0], [0, 1], [0, 3], [0, 4], [0, 5], [0, 6], [1, 0], [1, 1], [0, 7]])
        result = force_table([first, second], refs, np.zeros((len(refs), 3)))
        self.assertEqual(result.continuous_block.tolist(), [1, 1, 2, 3, 4, 4, 5, 5, 6])

    def test_masked_predictions_do_not_use_gt_and_effective_id_is_truth(self):
        source = trial()
        source.load_state[:3] = [1, 0, -1]
        refs = np.array([[0, 0], [0, 1], [0, 2]])
        probability = np.array([[.7, .3], [.7, .3], [.7, .3]])
        result = id_table([source], refs, probability, "masked", [5, 18], include_p0=True)
        self.assertEqual(result.ground_truth_id[:2].tolist(), [18, 0])
        self.assertTrue(np.isnan(result.ground_truth_id[2]))
        self.assertEqual(result.pred_id.tolist(), [5, 5, 5])
        self.assertEqual(result.pred_id_conditional.tolist(), [5, 5, 5])
        self.assertTrue(result.pred_id_operational.isna().all())
        self.assertEqual(result.contact_id_original.tolist(), [1, 1, 1])
        self.assertEqual(result.contact_id_effective.tolist(), [18, 18, 18])
        self.assertNotIn("pred_no_load_probability", result)
        self.assertFalse(result.attrs["ground_truth_used_for_prediction"])
        self.assertIn("conditional", result.attrs["prediction_semantics"])

    def test_class0_full_argmax_preserves_wrong_predictions_and_optional_p0(self):
        source = trial(effective=9)
        source.load_state[:3] = [1, 0, -1]
        refs = np.array([[0, 0], [0, 1], [0, 2]])
        probability = np.array([[.6, .3, .1], [.1, .2, .7], [.1, .8, .1]])
        result = id_table([source], refs, probability, "class0", [5, 18], include_p0=True)
        self.assertEqual(result.pred_id.tolist(), [0, 18, 5])
        self.assertEqual(result.pred_id_conditional.tolist(), [5, 18, 5])
        self.assertEqual(result.pred_id_operational.tolist(), [0, 18, 5])
        self.assertEqual(result.ground_truth_id[0], 9)  # Unsupported truth is preserved.
        np.testing.assert_array_equal(result.pred_no_load_probability, probability[:, 0])
        self.assertNotIn("pred_no_load_probability", id_table([source], refs, probability, "class0", [5, 18]))

    def test_invalid_endpoint_flags_targets_or_prediction_raise(self):
        mutations = {
            "not an endpoint": lambda value: setattr(value, "endpoints", np.array([0, 2])),
            "input flag": lambda value: value.input_valid.__setitem__(1, False),
            "target flag": lambda value: value.force_valid.__setitem__(1, False),
            "nonfinite input": lambda value: value.x.__setitem__((1, 0), np.nan),
            "nonfinite target": lambda value: value.force.__setitem__((1, 0), np.inf),
            "invalid load state": lambda value: value.load_state.__setitem__(1, -2),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                source = trial()
                mutate(source)
                with self.assertRaises(ValueError):
                    force_table([source], np.array([[0, 1]]), np.zeros((1, 3)))
        with self.assertRaisesRegex(ValueError, "Nonfinite force"):
            force_table([trial()], np.array([[0, 1]]), [[np.nan, 0, 0]])
        with self.assertRaises(ValueError):
            id_table([trial()], np.array([[0, 1]]), [[np.nan, 1]], "masked", [5, 18])

    def test_refs_and_prediction_alignment_fail_explicitly(self):
        for refs in (np.array([0, 1]), np.array([[0., 1.5]]), np.array([[1, 1]]), np.array([[0, 99]]), np.array([[0, -1]])):
            with self.subTest(refs=refs), self.assertRaises(ValueError):
                force_table([trial()], refs, np.zeros((1, 3)))
        with self.assertRaises(ValueError):
            force_table([trial()], np.array([[0, 1]]), np.zeros((2, 3)))
        with self.assertRaises(ValueError):
            id_table([trial()], np.array([[0, 1]]), np.ones((2, 1)), "masked", [18])

    def test_revalidate_whole_window_flags_finite_values_and_time_boundaries(self):
        refs = np.array([[0, 3]])
        for defect in ("flag", "nan", "gap", "nonincreasing"):
            with self.subTest(defect=defect):
                source = trial()
                if defect == "flag":
                    source.force_valid[2] = False
                elif defect == "nan":
                    source.x[2, 0] = np.nan
                elif defect == "gap":
                    source.timestamps[2:] += 30_000_000
                else:
                    source.timestamps[2] = source.timestamps[1]
                with self.assertRaises(ValueError):
                    force_table([source], refs, np.zeros((1, 3)), window_samples=3)
        # A boundary before the window, and invalid older history, are harmless.
        source = trial()
        source.force_valid[0] = False
        source.timestamps[1:] += 30_000_000
        result = force_table([source], refs, np.zeros((1, 3)), window_samples=3)
        self.assertEqual(len(result), 1)
        self.assertEqual(result.attrs["window_samples_revalidated"], 3)

    def test_empty_exports_have_columns_and_do_not_modify_trial(self):
        source = trial()
        previous = source.force.copy()
        refs = np.empty((0, 2), dtype=np.int64)
        force = force_table([source], refs, np.empty((0, 3)))
        location = id_table([source], refs, np.empty((0, 2)), "masked", [5, 18])
        self.assertEqual(len(force), 0)
        self.assertEqual(len(location), 0)
        self.assertIn("gt_fx_mN", force)
        self.assertIn("ground_truth_id", location)
        np.testing.assert_array_equal(source.force, previous)

    def test_sparse_trial_list_keeps_global_indices_without_touching_other_roles(self):
        trials = [None] * 49
        trials[47] = trial(path="/test/first.csv")
        trials[48] = trial(path="/test/second.csv")
        refs = np.array([[47, 2], [48, 3]])
        result = force_table(trials, refs, np.zeros((2, 3)), window_samples=3)
        self.assertEqual(result.source_file.tolist(), ["first.csv", "second.csv"])
        self.assertEqual(result.source_row.tolist(), [2, 3])
        self.assertEqual(result.continuous_block.tolist(), [1, 2])


if __name__ == "__main__":
    unittest.main()
