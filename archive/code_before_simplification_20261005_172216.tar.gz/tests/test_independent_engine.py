"""Training contract checks using tiny independent synthetic trials."""
import contextlib
import io
from pathlib import Path
import random
import tempfile
from types import SimpleNamespace
import unittest

import numpy as np
import torch

from hrm_force.independent_engine import (
    WindowStore, bundle_for, fit_scaler, predict_branch, restore_bundle,
    train_branch, validate_branch,
)
from hrm_force.independent_models import build_estimator


def trial(segment_id=18, *, is_tip=True, shift=0.0, states=None,
          endpoints=None, predict_endpoints=None, force_valid=None):
    rows = 8
    return SimpleNamespace(
        x=np.column_stack((np.arange(rows), np.arange(rows) * 2)).astype(np.float32) + shift,
        force=np.column_stack((np.arange(rows) * .01,
                               np.arange(rows) * -.02,
                               np.arange(rows) * .03)).astype(np.float32),
        input_valid=np.ones(rows, dtype=bool),
        force_valid=np.ones(rows, dtype=bool) if force_valid is None else np.asarray(force_valid, dtype=bool),
        effective_id=segment_id,
        is_tip=is_tip,
        load_state=np.asarray([0, 0, 0, 1, -1, 1, 0, 1] if states is None else states),
        endpoints=np.asarray([2, 3, 4, 5, 6, 7] if endpoints is None else endpoints),
        predict_endpoints=np.asarray([2, 3, 4, 5, 6, 7] if predict_endpoints is None else predict_endpoints),
    )


def config(**overrides):
    values = {"window_samples": 3, "active_ids": [5, 18], "force_scope": "tip",
              "seed": 19, "threads": 1, "max_epochs": 3, "patience": 3,
              "batch_size": 3, "learning_rate": .01, "weight_decay": 0.0}
    values.update(overrides)
    return values


def scaler():
    return {"x_mean": np.array([2., 4.]), "x_std": np.array([2., 4.]),
            "y_mean": np.array([.01, -.02, .03]), "y_std": np.array([.1, .2, .3])}


class IndependentEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_threads = torch.get_num_threads()
        torch.set_num_threads(1)

    @classmethod
    def tearDownClass(cls):
        torch.set_num_threads(cls.original_threads)

    def test_location_masks_keep_unloaded_and_uncertain_rows_in_history(self):
        source = trial(5, is_tip=False)
        original = source.x.copy()
        masked = WindowStore([source], [0], scaler(), config(), "cpu", "location", "masked")
        class0 = WindowStore([source], [0], scaler(), config(), "cpu", "location", "class0")
        self.assertEqual(masked.targets.tolist(), [-100, 0, -100, 0, -100, 0])
        self.assertEqual(class0.targets.tolist(), [0, 1, -100, 1, 0, 1])
        self.assertEqual(masked.eligible.tolist(), [1, 3, 5])
        self.assertEqual(class0.eligible.tolist(), [0, 1, 3, 4, 5])
        # The loaded endpoint at row3 consumes rows1/2, both unloaded.
        expected = (original[1:4] - scaler()["x_mean"]) / scaler()["x_std"]
        np.testing.assert_allclose(masked.batch(torch.tensor([1])).numpy()[0], expected)
        np.testing.assert_array_equal(source.x, original)

    def test_unsupported_loaded_contact_is_not_relabelled_unloaded(self):
        source = trial(1, is_tip=False)
        store = WindowStore([source], [0], scaler(), config(), "cpu", "location", "class0")
        self.assertEqual(store.targets.tolist(), [0, -100, -100, -100, 0, -100])
        self.assertEqual(store.actual_ids.tolist(), [1] * 6)

    def test_windows_never_join_files_and_force_uses_its_own_normalization(self):
        sources = [trial(5, is_tip=False), trial(18, shift=100.)]
        loc = WindowStore(sources, [0, 1], scaler(), config(), "cpu", "location")
        gathered = loc.batch(torch.tensor([0, 6])).numpy()
        expected = np.stack([(source.x[:3] - scaler()["x_mean"]) / scaler()["x_std"]
                             for source in sources])
        np.testing.assert_allclose(gathered, expected)
        self.assertEqual(loc.refs[6], (1, 2))
        force_scale = scaler()
        force_scale["x_mean"] = np.array([100., 100.])
        force = WindowStore(sources, [0, 1], force_scale, config(), "cpu", "force")
        self.assertEqual(force.refs, [(1, row) for row in range(2, 8)])
        np.testing.assert_allclose(force.batch(torch.tensor([0])).numpy()[0],
                                   (sources[1].x[:3] - force_scale["x_mean"]) / force_scale["x_std"])
        expected_y = (sources[1].force[2:] - force_scale["y_mean"]) / force_scale["y_std"]
        np.testing.assert_allclose(force.y.numpy(), expected_y, atol=1e-7)

    def test_scalers_exclude_holdout_and_keep_branch_scope_separate(self):
        sources = [trial(18), trial(5, is_tip=False, shift=100.), trial(18, shift=1e6)]
        force = fit_scaler(sources, [0, 1], "tip")
        location = fit_scaler(sources, [0, 1], "all")
        np.testing.assert_allclose(force["x_mean"], sources[0].x.mean(0))
        np.testing.assert_allclose(location["x_mean"], np.concatenate([t.x for t in sources[:2]]).mean(0))
        np.testing.assert_allclose(force["y_mean"], sources[0].force.mean(0), rtol=1e-6)

    def test_scaler_respects_input_and_force_validity_on_raw_train_rows(self):
        source = trial(endpoints=[2, 3])
        source.x[4:] = 1e6
        source.input_valid[4:] = False
        source.force[3:] = -1e6
        source.force_valid[3:] = False
        fitted = fit_scaler([source], [0], "tip")
        np.testing.assert_allclose(fitted["x_mean"], source.x[:4].mean(0))
        np.testing.assert_allclose(fitted["y_mean"], source.force[:3].mean(0), rtol=1e-6)

    def test_prediction_keeps_xyz_without_contact_labels_but_respects_gt_validity(self):
        source = trial(-1, is_tip=False, force_valid=[1, 1, 0, 1, 1, 1, 1, 1])
        source.force[2] = 999.  # Numeric sensor values can nevertheless have a false validity flag.
        store = WindowStore([source], [0], scaler(), config(), "cpu", "force", prediction=True)
        self.assertEqual(len(store), 6)
        self.assertEqual(store.eligible.tolist(), [1, 2, 3, 4, 5])
        self.assertFalse(store.force_valid[0])
        model = build_estimator("mlp", "mlp", 2, 3, 2).eval()
        outputs = predict_branch(model.force_net, store, 2)
        self.assertEqual(outputs.shape, (6, 3))
        self.assertTrue(np.isfinite(outputs).all())

    def test_force_validation_is_pooled_physical_rmse(self):
        source = trial()
        store = WindowStore([source], [0], scaler(), config(), "cpu", "force")
        model = build_estimator("mlp", "mlp", 2, 3, 2).eval()
        with torch.no_grad():
            for parameter in model.force_net.parameters():
                parameter.zero_()
        actual = validate_branch(model.force_net, store, 2)
        expected = np.sqrt(np.mean((source.force[2:] - scaler()["y_mean"]) ** 2)) * 1000
        self.assertAlmostEqual(actual, expected, places=5)

    def test_training_one_branch_does_not_forward_update_or_seed_its_sibling(self):
        cfg = config()
        store = WindowStore([trial()], [0], scaler(), cfg, "cpu", "force")
        model = build_estimator("mlp", "transformer", 2, 3, 2)
        sibling_before = {key: value.clone() for key, value in model.location_net.state_dict().items()}
        active_before = {key: value.clone() for key, value in model.force_net.state_dict().items()}
        calls = []
        handle = model.location_net.register_forward_hook(lambda *_: calls.append(True))
        with contextlib.redirect_stdout(io.StringIO()):
            result = train_branch(model.force_net, store, store, cfg, 19, "synthetic/force")
        handle.remove()
        self.assertFalse(calls)
        self.assertTrue(all(p.grad is None for p in model.location_net.parameters()))
        for key, value in model.location_net.state_dict().items():
            torch.testing.assert_close(value, sibling_before[key], rtol=0, atol=0)
        self.assertTrue(any(not torch.equal(value, active_before[key])
                            for key, value in model.force_net.state_dict().items()))
        self.assertEqual(result["metric"], "rmse_xyz_mN")
        self.assertAlmostEqual(validate_branch(model.force_net, store, cfg["batch_size"]), result["best_metric"])
        self.assertEqual(result["best_metric"], min(row["validation_metric"] for row in result["history"]))

    def test_complete_bundle_round_trip_preserves_scalers_and_outputs(self):
        cfg = config()
        model = build_estimator("small_gru", "transformer", 2, 3, 3).eval()
        prepared = {"calibration": {"center_N": [0, 0, 0]}, "feature_columns": ["x1", "x2"],
                    "split": {"train": [0], "validation": [1], "test": [2]},
                    "audit": {"original_hashes": ["train", "validation", "test"]}}
        branch_scalers = {"force": scaler(), "location": scaler()}
        branch_scalers["location"]["x_mean"] = np.array([10., 20.])
        bundle = bundle_for(model, cfg, prepared, branch_scalers, {}, "class0", "small_gru", "transformer")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "hrm_bundle.pt"
            torch.save(bundle, path)
            restored, actual = restore_bundle(path)
        self.assertEqual(actual["kind"], "independent_hrm")
        self.assertEqual(actual["force_unit"], "N")
        self.assertEqual(actual["training_sign_multiplier"], 1)
        self.assertEqual(actual["future_hrm_control_multiplier"], -1)
        self.assertEqual(actual["deployment_gate"], "class0_argmax")
        self.assertNotEqual(actual["scalers"]["force"]["x_mean"], actual["scalers"]["location"]["x_mean"])
        x = torch.randn(2, 3, 2)
        with torch.no_grad():
            for key, value in model(x).items():
                torch.testing.assert_close(value, restored(x)[key], rtol=0, atol=0)

    def test_restoration_applies_saved_execution_policy_without_reseeding(self):
        prior = {"threads": torch.get_num_threads(),
                 "deterministic": torch.backends.cudnn.deterministic,
                 "benchmark": torch.backends.cudnn.benchmark,
                 "cudnn_tf32": torch.backends.cudnn.allow_tf32,
                 "matmul_tf32": torch.backends.cuda.matmul.allow_tf32}
        prior_torch_rng = torch.random.get_rng_state().clone()
        prior_python_rng = random.getstate()
        prior_numpy_rng = np.random.get_state()
        try:
            model = build_estimator("mlp", "cnn", 2, 3, 2).eval()
            prepared = {"calibration": {}, "feature_columns": ["x1", "x2"],
                        "split": {"train": [0], "validation": [1], "test": []}, "audit": {}}
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "bundle.pt"
                for threads, deterministic, benchmark in ((1, True, False), (2, False, True)):
                    with self.subTest(threads=threads, deterministic=deterministic, benchmark=benchmark):
                        cfg = config(threads=threads, cudnn_deterministic=deterministic,
                                     cudnn_benchmark=benchmark)
                        torch.save(bundle_for(model, cfg, prepared,
                                              {"force": scaler(), "location": scaler()},
                                              {}, "masked", "mlp", "cnn"), path)
                        torch.set_num_threads(3)
                        torch.backends.cudnn.deterministic = not deterministic
                        torch.backends.cudnn.benchmark = not benchmark
                        torch.backends.cudnn.allow_tf32 = True
                        torch.backends.cuda.matmul.allow_tf32 = True
                        torch_before = torch.random.get_rng_state().clone()
                        python_before = random.getstate()
                        numpy_before = np.random.get_state()
                        restored, _ = restore_bundle(path)
                        self.assertFalse(restored.training)
                        self.assertEqual(torch.get_num_threads(), threads)
                        self.assertEqual(torch.backends.cudnn.deterministic, deterministic)
                        self.assertEqual(torch.backends.cudnn.benchmark, benchmark)
                        self.assertFalse(torch.backends.cudnn.allow_tf32)
                        self.assertFalse(torch.backends.cuda.matmul.allow_tf32)
                        torch.testing.assert_close(torch.random.get_rng_state(), torch_before, rtol=0, atol=0)
                        self.assertEqual(random.getstate(), python_before)
                        numpy_after = np.random.get_state()
                        self.assertEqual(numpy_after[0], numpy_before[0])
                        np.testing.assert_array_equal(numpy_after[1], numpy_before[1])
                        self.assertEqual(numpy_after[2:], numpy_before[2:])
        finally:
            torch.set_num_threads(prior["threads"])
            torch.backends.cudnn.deterministic = prior["deterministic"]
            torch.backends.cudnn.benchmark = prior["benchmark"]
            torch.backends.cudnn.allow_tf32 = prior["cudnn_tf32"]
            torch.backends.cuda.matmul.allow_tf32 = prior["matmul_tf32"]
            torch.random.set_rng_state(prior_torch_rng)
            random.setstate(prior_python_rng)
            np.random.set_state(prior_numpy_rng)


if __name__ == "__main__":
    unittest.main()
