"""Regression checks for CSV boundaries, data identity and no-load fit leakage."""
from pathlib import Path
import copy
import csv
import tempfile
import unittest

import numpy as np
import pandas as pd

from hrm_force.data import sha256
from hrm_force.independent_data import (
    _recover_recorded_anchors, _reject_duplicates, calibrate_no_load, load_prediction_trials,
    load_states, load_trial, prepare_data,
)


class IndependentDataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "train").mkdir()
        (self.root / "test").mkdir()
        self.config = {
            "project_root": str(self.root), "feature_groups": ["relative_angle"],
            "force_source": "kalman", "source_force_unit": "mN",
            "window_samples": 3, "gap_factor": 1.5, "max_matching_skew_ms": 25.,
            "timestamp_rounding_tolerance_ms": .02, "seed": 42, "validation_fraction": .2,
            "train_directory": "train", "test_directory": "test", "tip_train_files": [],
            "calibration": {"path": "calibration.csv", "confirmed_no_load": True,
                            "basis": "Synthetic test known no load", "fit_fraction": .7,
                            "off_quantile": .95, "on_quantile": .995,
                            "zero_transfer_basis": "Synthetic same sensor"},
        }
        self.write_csv(self.root / "calibration.csv", rows=200, seed=10)
        self.calibration = calibrate_no_load(self.config)

    def write_csv(self, path, rows=30, segment_id=18, seed=1, start=1_790_000_000_000_000_003,
                  invalid_row=None, gap_row=None, force=True, stamp_shift=0):
        rng = np.random.default_rng(seed)
        columns = ["source_time_ns", "bag_receive_time_ns", "contact_segment_id", "angle_frame_id"]
        columns += [f"relative_angle_{i}" for i in range(1, 19)]
        if force:
            columns += [f"fts_kalman.aligned_f{axis}" for axis in "xyz"]
            columns += ["fts_kalman.matched", "fts_kalman.aligned_force_valid", "fts_kalman.aligned_frame_id",
                        "fts_kalman.source_time_ns", "fts_kalman.bag_receive_time_ns",
                        "fts_kalman.time_basis", "fts_kalman.time_difference_ms"]
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader()
            for i in range(rows):
                timestamp = start + i * 33_333_333 + (1_000_000_000 if gap_row is not None and i >= gap_row else 0)
                row = {"source_time_ns": timestamp, "bag_receive_time_ns": timestamp + 1_000_000,
                       "contact_segment_id": segment_id, "angle_frame_id": "hrm_base"}
                row.update({f"relative_angle_{j}": float(rng.normal()) for j in range(1, 19)})
                if force:
                    row.update({f"fts_kalman.aligned_f{axis}": float(rng.normal(10, 5)) for axis in "xyz"})
                    row.update({"fts_kalman.matched": "True", "fts_kalman.aligned_force_valid": "True",
                                "fts_kalman.aligned_frame_id": "hrm_base",
                                "fts_kalman.source_time_ns": timestamp + stamp_shift,
                                "fts_kalman.bag_receive_time_ns": timestamp + 1_000_000,
                                "fts_kalman.time_basis": "source", "fts_kalman.time_difference_ms": 0})
                    if i == invalid_row:
                        row["fts_kalman.aligned_fx"] = ""
                writer.writerow(row)

    def rewrite(self, path, transform):
        with path.open(newline="") as handle:
            reader = csv.DictReader(handle)
            columns, rows = reader.fieldnames, list(reader)
        for i, row in enumerate(rows):
            transform(i, row)
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=columns)
            writer.writeheader(); writer.writerows(rows)

    def test_invalid_force_breaks_windows_but_not_prediction_history(self):
        path = self.root / "train/summary_18.csv"
        self.write_csv(path, invalid_row=5, gap_row=15)
        before = sha256(path)
        trial = load_trial(path, self.config, self.calibration)
        self.assertEqual(trial.info["timestamp_origin_ns"], 1_790_000_000_000_000_003)
        self.assertEqual(int(trial.timestamps[1]), 33_333_333)
        self.assertEqual(trial.load_state[5], -2)
        self.assertTrue(np.isnan(trial.force[5, 0]))
        self.assertTrue(all(i not in trial.endpoints for i in [5, 6, 7, 15, 16]))
        self.assertIn(8, trial.endpoints)
        self.assertIn(5, trial.predict_endpoints)
        self.assertEqual(len(trial.x), 30)
        self.assertEqual(sha256(path), before)

    def test_missing_ground_truth_allows_prediction_without_inventing_zero(self):
        path = self.root / "sensor_stream.csv"
        self.write_csv(path, force=False)
        self.rewrite(path, lambda _, row: row.update(contact_segment_id=""))
        trial = load_prediction_trials([path], self.config, self.calibration)[0]
        self.assertEqual(len(trial.predict_endpoints), 28)
        self.assertEqual(len(trial.endpoints), 0)
        self.assertFalse(trial.force_valid.any())
        self.assertTrue(np.isnan(trial.force).all())
        self.assertTrue((trial.load_state == -2).all())
        self.assertEqual(trial.effective_id, 0)

    def test_holdout_does_not_fit_noise_thresholds(self):
        path = self.root / "calibration.csv"
        cut = self.calibration["split_row"]
        def disturb(index, row):
            if index >= cut:
                for axis in "xyz":
                    key = f"fts_kalman.aligned_f{axis}"
                    row[key] = float(row[key]) + 1_000
        self.rewrite(path, disturb)
        changed = calibrate_no_load(self.config)
        for key in ["center_N", "scale_N", "off_score", "on_score"]:
            self.assertEqual(changed[key], self.calibration[key])
        self.assertEqual(changed["holdout_coverage"]["loaded_false_alarm_fraction"], 1.)

    def test_mean_offset_and_range_expansion_preserve_raw_force_and_holdout_independence(self):
        cfg = copy.deepcopy(self.config)
        cfg['calibration'].update(center_method='mean', range_multiplier=1.1)
        calibrated = calibrate_no_load(cfg)
        raw = pd.read_csv(self.root / 'calibration.csv')[[f'fts_kalman.aligned_f{a}' for a in 'xyz']].to_numpy() * .001
        fit = raw[:calibrated['split_row']]
        np.testing.assert_allclose(calibrated['center_N'], fit.mean(0), atol=1e-15)
        np.testing.assert_allclose(calibrated['corrected_fit_mean_N'], 0., atol=1e-15)
        score = np.max(np.abs(fit-fit.mean(0))/fit.std(0,ddof=1),axis=1)
        np.testing.assert_allclose([calibrated['off_score'],calibrated['on_score']],np.quantile(score,[.95,.995])*1.1)
        valid = np.ones(len(raw), dtype=bool)
        shifted = {**calibrated, 'center_N': [0.,0.,0.]}
        np.testing.assert_array_equal(load_states(raw, valid, calibrated),
                                      load_states(raw-np.asarray(calibrated['center_N']), valid, shifted))
        path = self.root/'train/summary_18.csv'
        self.write_csv(path)
        before = load_trial(path,self.config,self.calibration)
        after = load_trial(path,cfg,calibrated)
        np.testing.assert_array_equal(before.force,after.force)
        cut = calibrated['split_row']
        self.rewrite(self.root/'calibration.csv',lambda i,row:row.update(
            {f'fts_kalman.aligned_f{a}':float(row[f'fts_kalman.aligned_f{a}'])+1000 for a in 'xyz'}) if i>=cut else None)
        changed = calibrate_no_load(cfg)
        for key in ('center_N','scale_N','off_score','on_score'):
            self.assertEqual(calibrated[key],changed[key])

    def test_invalid_calibration_center_and_multiplier_rejected(self):
        for key,value in [('center_method','mode'),('range_multiplier',0),('range_multiplier',-1),
                          ('range_multiplier',float('nan')),('range_multiplier',float('inf')),
                          ('range_multiplier',True),('range_multiplier','1.1')]:
            cfg=copy.deepcopy(self.config)
            cfg['calibration'][key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):
                calibrate_no_load(cfg)

    def test_whole_file_split_is_fixed_and_separate_from_test(self):
        for contact in [1, 18]:
            for repetition in [1, 2]:
                self.write_csv(self.root / f"train/summary_{contact}-{repetition}.csv",
                               segment_id=contact, seed=contact * 10 + repetition,
                               start=1_790_000_000_000_000_003 + (contact * 10 + repetition) * 10**12)
        self.write_csv(self.root / "test/summary_18.csv", seed=99,
                       start=1_791_000_000_000_000_003)
        before = {str(path): sha256(path) for path in self.root.glob("*/*.csv")}
        first = prepare_data(self.config, self.root / "output")
        second = prepare_data(self.config, None)
        self.assertEqual(first["split"], second["split"])
        self.assertEqual({key: len(value) for key, value in first["split"].items()},
                         {"train": 2, "validation": 2, "test": 1})
        for part in ["train", "validation"]:
            self.assertEqual({first["trials"][i].effective_id for i in first["split"][part]}, {1, 18})
        self.assertFalse(set(first["split"]["train"]) & set(first["split"]["test"]))
        self.assertEqual(before, {str(path): sha256(path) for path in self.root.glob("*/*.csv")})

    def test_reformatted_duplicate_with_changed_id_is_rejected(self):
        a, b = self.root / "a.csv", self.root / "b.csv"
        self.write_csv(a)
        b.write_bytes(a.read_bytes())
        self.rewrite(b, lambda _, row: row.update(contact_segment_id="1",
                                                 source_time_ns=str(int(row["source_time_ns"]) + 2)))
        trials = [load_trial(path, self.config, self.calibration) for path in (a, b)]
        with self.assertRaisesRegex(ValueError, "Duplicate physical trial"):
            _reject_duplicates(trials)

    def test_stale_anchor_is_detected_even_with_valid_matching_flag(self):
        path = self.root / "trial.csv"
        self.write_csv(path, stamp_shift=1_000_000_000)
        trial = load_trial(path, self.config, self.calibration)
        self.assertFalse(trial.force_valid.any())
        self.assertEqual(trial.info["force_timing_audit"]["fts_kalman"]["reported_skew_disagreement_rows"], 30)

    def test_approved_id_override_is_hash_specific_and_preserves_raw(self):
        path = self.root / "train/summary_18-2.csv"
        self.write_csv(path, segment_id=1)
        with self.assertRaisesRegex(ValueError, "Filename"):
            load_trial(path, self.config, self.calibration)
        config = copy.deepcopy(self.config)
        config["label_overrides_by_sha256"] = {sha256(path): {"original_id": 1, "effective_id": 18, "basis": "Test explicit approval"}}
        trial = load_trial(path, config, self.calibration)
        self.assertEqual(trial.segment_id_raw, 1)
        self.assertEqual(trial.effective_id, 18)

    def test_load_state_boundary_and_uncertainty(self):
        calibration = {"center_N": [0., 0., 0.], "scale_N": [1., 1., 1.], "off_score": 2., "on_score": 3.}
        force = np.array([[2., 0, 0], [2.5, 0, 0], [3., 0, 0], [np.nan, 0, 0]])
        np.testing.assert_array_equal(load_states(force, np.array([True, True, True, False]), calibration), [0, -1, 1, -2])

    def recovery_fixture(self):
        rows = []
        origin = 1_790_000_000_000_000_000
        for i in range(10):
            stale = origin + i * 30_000_000
            actual = stale + 60_000_000
            row = {"source_time_ns": str(stale), "bag_receive_time_ns": str(stale + 1_000_000),
                   "elapsed_s": str(i * .03), "signal_untouched": i * 2.}
            for prefix in ["motor", "loadcell", "fts", "fts_kalman", "estimated_tip", "fk_tip"]:
                skew = 0 if prefix in ["estimated_tip", "fk_tip"] else 2
                row.update({f"{prefix}.source_time_ns": str(actual + skew * 1_000_000),
                            f"{prefix}.time_basis": "source", f"{prefix}.time_difference_ms": str(skew)})
            for prefix in ["wire", "wire_velocity"]:
                row.update({f"{prefix}.bag_receive_time_ns": str(actual + 1_000_000 + 100_000),
                            f"{prefix}.time_basis": "receive", f"{prefix}.time_difference_ms": ".1"})
            rows.append(row)
        return pd.DataFrame(rows), {"removed_signal_rows": 2, "expected_rows": 10, "basis": "Synthetic known trim"}

    def test_anchor_recovery_requires_every_row_independent_identity(self):
        frame, policy = self.recovery_fixture()
        before = frame.copy(deep=True)
        recovered, evidence = _recover_recorded_anchors(frame, policy, "synthetic.csv", .02)
        self.assertEqual(int(recovered.source_time_ns.iloc[0]) - int(frame.source_time_ns.iloc[0]), 60_000_000)
        pd.testing.assert_frame_equal(frame, before)
        np.testing.assert_array_equal(recovered.signal_untouched, frame.signal_untouched)
        self.assertEqual(evidence["source_anchor_methods"], {"shifted_recorded_anchor": 8, "duplicate_zero_skew_anchor": 2})
        frame.loc[5, "motor.source_time_ns"] = str(int(frame.loc[5, "motor.source_time_ns"]) + 100_000)
        with self.assertRaisesRegex(ValueError, "evidence conflicts"):
            _recover_recorded_anchors(frame, policy, "synthetic.csv", .02)

    def test_anchor_recovery_refuses_unrecorded_tail(self):
        frame, policy = self.recovery_fixture()
        frame.loc[9, "estimated_tip.source_time_ns"] = ""
        frame.loc[9, "fk_tip.source_time_ns"] = ""
        with self.assertRaisesRegex(ValueError, "zero-skew tail"):
            _recover_recorded_anchors(frame, policy, "synthetic.csv", .02)


if __name__ == "__main__":
    unittest.main()
