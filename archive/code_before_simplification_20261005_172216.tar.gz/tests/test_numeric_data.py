"""Numeric compaction and manually supplied test folders; no optimizer runs."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch
import yaml

import test_independent_data as fixtures
from hrm_force.data import sha256
from hrm_force.independent_data import load_trial, prepare_data, trial_endpoints
from hrm_force.independent_engine import WindowStore, fit_scaler, train_experiment, bundle_for, restore_bundle
from hrm_force.independent_models import build_estimator
from hrm_force.independent_prediction import _assert_held_out, predict_trials
from hrm_force.excel_tables import force_table
from hrm_force.excel_export import _refs


class NumericDataTests(unittest.TestCase):
    setUp = fixtures.IndependentDataTests.setUp
    write_csv = fixtures.IndependentDataTests.write_csv
    rewrite = fixtures.IndependentDataTests.rewrite

    def numeric_config(self):
        return {**copy.deepcopy(self.config), 'preprocessing': 'numeric_compact',
                'validation_strategy': 'per_file_tail', 'tip_scope_by_id': True}

    def test_compact_ignores_flags_and_time_gaps_preserves_original_rows(self):
        path = self.root/'train/summary_18.csv'
        self.write_csv(path, rows=30, invalid_row=5, gap_row=15)
        self.rewrite(path, lambda i,r: r.update({'fts_kalman.aligned_force_valid':'',
            'fts_kalman.aligned_frame_id':'', 'fts_kalman.matched':'False',
            **({'relative_angle_2':'Inf'} if i==9 else {})}))
        before = sha256(path)
        cfg = self.numeric_config()
        t = load_trial(path,cfg,self.calibration)
        expected = np.array([i for i in range(30) if i not in (5,9)])
        np.testing.assert_array_equal(t.source_rows,expected)
        np.testing.assert_array_equal(t.endpoints,np.arange(2,28))
        self.assertEqual(t.info['dropped_rows'],2)
        self.assertEqual(before,sha256(path))
        scale=fit_scaler([t],[0],'tip')
        store=WindowStore([t],[0],scale,cfg,'cpu','force')
        got=store.batch(torch.tensor([3]),False).numpy()[0]
        np.testing.assert_allclose(got,(t.x[3:6]-scale['x_mean'])/scale['x_std'],rtol=1e-6)
        table=force_table([t],np.column_stack((np.zeros(len(t.endpoints),int),t.endpoints)),
                          t.force[t.endpoints],window_samples=3)
        self.assertEqual(table.source_row.tolist(),expected[2:].tolist())

    def test_only_selected_values_control_rows_and_missing_metadata_is_allowed(self):
        p=self.root/'train/summary_18.csv'
        self.write_csv(p)
        f=pd.read_csv(p)
        selected=[f'relative_angle_{i}' for i in range(1,19)]+[f'fts_kalman.aligned_f{a}' for a in 'xyz']+['contact_segment_id']
        f[selected].to_csv(p,index=False)
        t=load_trial(p,self.numeric_config(),self.calibration)
        self.assertEqual(len(t.x),30)
        self.assertFalse(t.info['timestamps_available'])
        refs=np.column_stack((np.zeros(len(t.endpoints),int),t.endpoints))
        table=force_table([t],refs,t.force[t.endpoints],window_samples=3)
        self.assertTrue(table.elapsed_s.isna().all())
        self.assertEqual(table.continuous_block.nunique(),1)

    def test_untrained_bundle_reload_and_prediction_preserve_compact_contract(self):
        self.write_csv(self.root/'train/summary_18.csv',rows=50,invalid_row=4)
        q=self.root/'test/summary_18_test.csv'
        self.write_csv(q,rows=20,seed=72,invalid_row=7,start=1_800_000_000_000_000_000)
        cfg=self.numeric_config()
        cfg.update(active_ids=[18],batch_size=4,threads=1,force_scope='tip')
        prepared=prepare_data(cfg,None)
        scale=fit_scaler(prepared['trials'],prepared['split']['train'],'tip')
        model=build_estimator('mlp','mlp',18,3,2,{'hidden_dims':[4]},{'hidden_dims':[4]})
        bundle=bundle_for(model,cfg,prepared,{'force':scale,'location':scale},{},'class0','mlp','mlp')
        p=self.root/'untrained_fixture.pt'
        torch.save(bundle,p)
        restored,saved=restore_bundle(p)
        t=load_trial(q,saved['config'],saved['calibration'],require_targets=False)
        _assert_held_out([t],saved)
        frame=predict_trials(restored,saved,[t],p,device='cpu')
        self.assertEqual(frame.source_row.tolist(),t.source_rows.tolist())
        self.assertEqual(int(frame.force_ready.sum()),17)
        self.assertTrue(frame.force_scope_verified.all())
        np.testing.assert_allclose(frame.true_fx_mN,t.force[:,0]*1000)

    def test_tail_partition_windows_and_scalers_never_use_validation_or_test(self):
        p=self.root/'train/summary_18.csv'
        self.write_csv(p,rows=50,invalid_row=5)
        self.write_csv(self.root/'test/summary_18_test.csv',rows=20,seed=72,start=1_800_000_000_000_000_000)
        cfg=self.numeric_config()
        prep=prepare_data(cfg,None)
        t=prep['trials'][0]
        cut=t.info['role_rows']['train'][1]
        self.assertEqual(cut,39)
        self.assertEqual(prep['split'],{'train':[0],'validation':[0],'test':[1]})
        tr=trial_endpoints(t,'train');va=trial_endpoints(t,'validation')
        self.assertLess(tr.max(),(va-2).min())
        with self.assertRaisesRegex(ValueError,'explicit'):
            WindowStore([t],[0],fit_scaler([t],[0],'tip'),cfg,'cpu','force')
        s=fit_scaler(prep['trials'],prep['split']['train'],'tip')
        np.testing.assert_allclose(s['x_mean'],t.x[:cut].mean(0))
        np.testing.assert_allclose(s['y_mean'],t.force[:cut].mean(0))
        store=WindowStore([t],[0],s,cfg,'cpu','force',role='validation')
        self.assertEqual(store.refs[0],(0,cut+2))
        refs=_refs([t],[0],'force','tip','validation')
        np.testing.assert_array_equal(refs[:,1],va)
        old=copy.deepcopy(s)
        t.x[cut:]+=99999;t.force[cut:]+=99999
        changed=fit_scaler([t],[0],'tip')
        for k in old: np.testing.assert_array_equal(changed[k],old[k])

    def test_duplicate_boundary_rejected_then_exact_hash_exclusion_preserves_test(self):
        p=self.root/'train/summary_18.csv';q=self.root/'test/summary_18_test.csv'
        self.write_csv(p,rows=60)
        f=pd.read_csv(p,dtype=str,keep_default_na=False)
        f.iloc[:40].to_csv(p,index=False);f.iloc[39:].to_csv(q,index=False)
        cfg=self.numeric_config()
        with self.assertRaisesRegex(ValueError,'share selected X/Y'):
            prepare_data(cfg,None)
        qhash=sha256(q)
        cfg['excluded_rows_by_sha256']={sha256(p):{'rows':[39],'reason':'known duplicated boundary'}}
        prep=prepare_data(cfg,None)
        self.assertEqual(len(prep['trials'][0].x),39)
        self.assertEqual(len(prep['trials'][1].x),21)
        self.assertEqual(qhash,sha256(q))

    def test_frozen_excel_reload_preserves_partition_and_original_row_mapping(self):
        p=self.root/'train/summary_18.csv';self.write_csv(p,rows=50,invalid_row=5)
        cfg=self.numeric_config();prep=prepare_data(cfg,None);t=prep['trials'][0]
        frozen=json.loads(json.dumps(t.info))
        reload=load_trial(p,cfg,self.calibration)
        reload.info['role_rows']=frozen['role_rows']
        refs=_refs([reload],[0],'force','tip','validation')
        table=force_table([reload],refs,reload.force[refs[:,1]],window_samples=3)
        self.assertEqual(table.source_row.tolist(),reload.source_rows[trial_endpoints(reload,'validation')].tolist())

    def test_check_data_never_builds_or_trains_a_network(self):
        self.write_csv(self.root/'train/summary_18.csv',rows=50)
        cfg=self.numeric_config()
        cfg.update(max_epochs=1,patience=1,batch_size=4,force_candidates=['mlp'],
                   location_candidates=['mlp'],no_load_modes=['class0'])
        path=self.root/'cfg.yaml';path.write_text(yaml.safe_dump(cfg))
        with (patch('hrm_force.independent_engine.build_estimator',side_effect=AssertionError('no models')),
              patch('hrm_force.independent_engine.train_branch',side_effect=AssertionError('no training'))):
            out,prepared,rows=train_experiment(path,output=self.root/'prepared',check_data=True)
        self.assertFalse(rows)
        self.assertFalse((out/'models').exists())


if __name__=='__main__': unittest.main()
