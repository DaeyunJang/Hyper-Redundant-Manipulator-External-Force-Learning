"""Replay/inference contracts, intact-bundle restoration, validation-only selection."""

import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
import torch

from hrm_force.independent_data import Trial
from hrm_force.independent_engine import restore_bundle
from hrm_force.independent_models import build_estimator
from hrm_force.independent_prediction import (
    _assert_held_out, evaluate_frame, predict_checkpoint, predict_trials,
    select_and_evaluate, select_comparison_rows,
)


def trial_fixture(path="trial.csv", digest="test-hash", segment=18, targets=True):
    size = 8
    valid = np.array([True, True, True, True, False, True, True, True])
    force_valid = np.array([True, True, True, False, True, True, True, True]) if targets else np.zeros(size, dtype=bool)
    force = np.full((size, 3), 0.001, dtype=np.float32) if targets else np.full((size, 3), np.nan, dtype=np.float32)
    states = np.array([0, 0, 1, -2, 0, 0, 1, 1], dtype=np.int8) if targets else np.full(size, -2, dtype=np.int8)
    info = {"path": str(path), "sha256": digest, "is_tip": targets and segment == 18,
            "has_location_target": targets, "has_force_targets": targets,
            "timestamp_origin_ns": 1_700_000_000_000_000_000}
    return Trial(str(path), digest, segment if targets else 0, segment if targets else 0,
                 np.ones((size, 4), dtype=np.float32), force, np.arange(size, dtype=np.int64) * 10_000_000,
                 valid, force_valid, states, np.array([2, 7]), np.array([2, 3, 7]),
                 targets and segment == 18, info)


def model_bundle(mode="class0", trials=None):
    model = build_estimator("mlp", "mlp", 4, 3, 3 + (mode == "class0"),
                            {"hidden_dims": [5]}, {"hidden_dims": [4]})
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.zero_()
        model.force_net.head.bias.copy_(torch.tensor([0.01, -0.02, 0.03]))
        model.location_net.head.bias.copy_(torch.log(torch.tensor([0.2, 0.1, 0.1, 0.6] if mode == "class0" else [0.1, 0.1, 0.8])))
    scaler = {"x_mean": [0.0] * 4, "x_std": [1.0] * 4, "y_mean": [0.0] * 3, "y_std": [1.0] * 3}
    trials = trials or [trial_fixture()]
    bundle = {
        "kind": "independent_hrm", "schema_version": 2, "mode": mode,
        "force_name": "mlp", "location_name": "mlp", "input_dim": 4,
        "num_classes": 3 + (mode == "class0"), "force_scope": "tip",
        "force_params": model.force_net.params, "location_params": model.location_net.params,
        "state_dict": model.state_dict(), "feature_columns": None,
        "config": {"window_samples": 3, "active_ids": [5, 11, 18], "force_scope": "tip",
                   "batch_size": 4, "feature_groups": ["wire_length"]},
        "scalers": {"force": copy.deepcopy(scaler), "location": copy.deepcopy(scaler)},
        "data_audit": {"trials": [trial.info for trial in trials]},
        "split": {"train": [], "validation": [], "test": list(range(len(trials)))},
        "calibration": {},
    }
    model.eval()
    return model, bundle


class IndependentPredictionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)

    def test_every_source_row_is_preserved_and_gt_does_not_control_predictions(self):
        trial = trial_fixture()
        model, bundle = model_bundle(trials=[trial])
        frame = predict_trials(model, bundle, [trial], "bundle.pt")
        self.assertEqual(frame["source_row"].tolist(), list(range(8)))
        self.assertEqual(frame.index[frame["force_ready"]].tolist(), [2, 3, 7])
        self.assertEqual(frame.index[frame["location_ready"]].tolist(), [2, 3, 7])
        self.assertEqual(frame.loc[4, "force_status"], "invalid_input")
        self.assertEqual(frame.loc[5, "location_status"], "warming_up")
        self.assertTrue(np.isnan(frame.loc[1, "pred_fx_N"]))
        self.assertTrue(np.isfinite(frame.loc[3, "pred_fx_N"]))
        self.assertEqual(frame.loc[3, "load_state_gt"], "invalid")
        self.assertFalse(frame.loc[3, "force_target_valid"])
        self.assertAlmostEqual(frame.loc[2, "pred_fy_mN"], -20.0, places=4)
        self.assertAlmostEqual(frame.loc[2, ["baseline_region_lower_probability", "baseline_region_middle_probability", "baseline_region_upper_probability"]].sum(), 0.8, places=6)
        metrics = evaluate_frame(frame, bundle)
        self.assertEqual(metrics["force_prediction_rows"], 3)
        self.assertEqual(metrics["force_support"], 2)

    def test_input_only_and_body_trials_emit_raw_tip_force_without_claiming_metrics(self):
        trials = [trial_fixture("body.csv", "body", segment=5), trial_fixture("input.csv", "no-gt", targets=False)]
        model, bundle = model_bundle(trials=trials)
        frame = predict_trials(model, bundle, trials, "bundle.pt")
        self.assertEqual(len(frame), 16)
        self.assertEqual(frame["force_ready"].sum(), 6)
        self.assertTrue((frame.loc[frame["force_ready"], "force_status"] == "scope_unverified").all())
        self.assertEqual(evaluate_frame(frame, bundle)["force_support"], 0)
        no_gt = frame.loc[frame["source_file"] == "input.csv"]
        self.assertTrue(no_gt["actual_id_raw"].isna().all())
        self.assertTrue(no_gt["true_fx_N"].isna().all())
        self.assertEqual(evaluate_frame(no_gt, bundle)["location_support"], 0)
        self.assertEqual(evaluate_frame(no_gt, bundle)["load_support"], 0)

    def test_masked_is_diagnostic_and_unsupported_probabilities_are_na(self):
        trial = trial_fixture()
        model, bundle = model_bundle("masked", [trial])
        frame = predict_trials(model, bundle, [trial], "bundle.pt")
        self.assertTrue(frame["p0"].isna().all())
        self.assertTrue(frame["p1"].isna().all())
        self.assertTrue(frame["final_id"].isna().all())
        self.assertTrue(frame["baseline_region_final"].isna().all())
        self.assertEqual(frame.loc[2, "location_status"], "unverified")
        self.assertEqual(frame.loc[2, "conditional_id"], 18)
        self.assertTrue(np.isnan(evaluate_frame(frame, bundle)["system_id_accuracy"]))

    def test_short_trial_remains_warming_up_with_empty_metric_support(self):
        trial = trial_fixture()
        trial.predict_endpoints = np.array([], dtype=int)
        model, bundle = model_bundle(trials=[trial])
        frame = predict_trials(model, bundle, [trial], "bundle.pt")
        self.assertFalse(frame["location_ready"].any())
        self.assertTrue(frame["p18"].isna().all())
        self.assertEqual(evaluate_frame(frame, bundle)["force_support"], 0)

    def test_same_bundle_save_restore_preserves_both_outputs(self):
        trial = trial_fixture()
        model, bundle = model_bundle(trials=[trial])
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "bundle.pt"
            torch.save(bundle, path)
            restored, saved = restore_bundle(path)
            x = torch.arange(24, dtype=torch.float32).reshape(2, 3, 4)
            with torch.inference_mode():
                before, after = model(x), restored(x)
            for key in before:
                torch.testing.assert_close(before[key], after[key], rtol=0, atol=0)
            expected = predict_trials(model, bundle, [trial], path)
            actual = predict_trials(restored, saved, [trial], path)
            pd.testing.assert_frame_equal(expected, actual)

    def test_validation_selection_ignores_all_test_columns_and_uses_existing_pair(self):
        comparison = pd.DataFrame([
            {"mode": "masked", "force_model": "mlp", "location_model": "gru", "force_rmse_xyz_mN": 10.0,
             "location_macro_recall": 0.7, "location_validation_ce": 0.2, "bundle": "a", "test_force_rmse_xyz_mN": 999},
            {"mode": "masked", "force_model": "mlp", "location_model": "lstm", "force_rmse_xyz_mN": 10.0000005,
             "location_macro_recall": 0.9, "location_validation_ce": 0.3, "bundle": "b", "test_force_rmse_xyz_mN": 2000},
            {"mode": "masked", "force_model": "gru", "location_model": "gru", "force_rmse_xyz_mN": 11.0,
             "location_macro_recall": 1.0, "location_validation_ce": 0.0, "bundle": "c", "test_force_rmse_xyz_mN": 0},
        ])
        rows = select_comparison_rows(comparison)
        self.assertEqual(rows[0][0], 1)
        self.assertEqual(rows[0][1]["bundle"], "b")
        comparison.loc[0, "location_macro_recall"] = 0.9
        self.assertEqual(select_comparison_rows(comparison)[0][1]["bundle"], "a")

    def test_numerical_force_ties_use_location_quality_but_larger_differences_do_not(self):
        common = {"mode": "masked", "force_model": "cnn", "location_validation_ce": 1.0}
        comparison = pd.DataFrame([
            {**common, "location_model": "mlp", "force_rmse_xyz_mN": 120.0,
             "location_macro_recall": .1, "bundle": "lowest_force"},
            {**common, "location_model": "gru", "force_rmse_xyz_mN": 120.00002,
             "location_macro_recall": .8, "bundle": "numerical_drift_better_location"},
            {**common, "location_model": "lstm", "force_rmse_xyz_mN": 120.0011,
             "location_macro_recall": .95, "bundle": "outside_numerical_tolerance"},
            {**common, "force_model": "mlp", "location_model": "resnet", "force_rmse_xyz_mN": 122.0,
             "location_macro_recall": 1.0, "bundle": "material_force_difference"},
        ])
        self.assertEqual(select_comparison_rows(comparison)[0][1]["bundle"],
                         "numerical_drift_better_location")
        # With explicitly exact comparisons the minimum remains authoritative.
        self.assertEqual(select_comparison_rows(comparison, force_tolerance_mN=0)[0][1]["bundle"],
                         "lowest_force")
        # Row ordering cannot turn the tolerance into a chain of pairwise ties.
        self.assertEqual(select_comparison_rows(comparison.iloc[::-1])[0][1]["bundle"],
                         "numerical_drift_better_location")

    def test_binary_selection_uses_validation_load_balance_not_trivial_id_accuracy(self):
        common = {'mode': 'class0', 'force_model': 'cnn', 'force_rmse_xyz_mN': 10.,
                  'location_macro_recall': 1., 'location_macro_class_count': 1}
        comparison = pd.DataFrame([
            {**common, 'location_model': 'resnet', 'location_validation_ce': .2,
             'load_balanced_accuracy': .6, 'bundle': 'lower_ce', 'test_load_balanced_accuracy': 1.},
            {**common, 'location_model': 'lstm', 'location_validation_ce': .4,
             'load_balanced_accuracy': .8, 'bundle': 'balanced', 'test_load_balanced_accuracy': 0.},
        ])
        self.assertEqual(select_comparison_rows(comparison)[0][1]['bundle'], 'lower_ce')
        self.assertEqual(select_comparison_rows(comparison, location_metric='load_balanced_accuracy')[0][1]['bundle'], 'balanced')
        comparison['test_load_balanced_accuracy'] = [0., 1.]
        self.assertEqual(select_comparison_rows(comparison, location_metric='load_balanced_accuracy')[0][1]['bundle'], 'balanced')
        with self.assertRaises(ValueError):
            select_comparison_rows(comparison, location_metric='test_load_balanced_accuracy')
        comparison['mode'] = 'masked'
        with self.assertRaises(ValueError):
            select_comparison_rows(comparison, location_metric='load_balanced_accuracy')

    def test_historical_development_hash_is_rejected(self):
        trial = trial_fixture()
        _, bundle = model_bundle(trials=[trial])
        bundle["split"]["train"] = [0]
        with self.assertRaisesRegex(ValueError, "Development"):
            _assert_held_out([trial], bundle)
        bundle["split"]["train"] = []
        bundle["config"]["protected_development_hashes"] = [trial.sha256]
        with self.assertRaisesRegex(ValueError, "Development"):
            _assert_held_out([trial], bundle)

    def test_reformatted_development_clock_and_length_are_rejected(self):
        original = trial_fixture()
        original.info['rows'] = len(original.x)
        _, bundle = model_bundle(trials=[original])
        bundle['split']['train'] = [0]
        reformatted = copy.deepcopy(original)
        reformatted.sha256 = 'new-hash-after-changing-numeric-format'
        reformatted.info['timestamp_origin_ns'] += 5000
        with self.assertRaisesRegex(ValueError, 'reformatting'):
            _assert_held_out([reformatted], bundle)

    def test_checkpoint_cli_path_creates_one_prediction_csv_and_json_null_metrics(self):
        trial = trial_fixture(targets=False)
        model, bundle = model_bundle(trials=[trial])
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            checkpoint = root / "bundle.pt"
            torch.save(bundle, checkpoint)
            inputs = root / "input"
            inputs.mkdir()
            (inputs / "trial.csv").write_text("synthetic loader fixture\n")
            with patch("hrm_force.independent_prediction.load_prediction_trials", return_value=[trial]):
                destination = predict_checkpoint(checkpoint, inputs, root / "output", "cpu")
            self.assertEqual(len(list(destination.glob("*.csv"))), 1)
            report = json.loads((destination / "metrics.json").read_text())
            self.assertIsNone(report["overall"]["force_rmse_xyz_mN"])
            self.assertEqual(len(pd.read_csv(destination / "predictions.csv")), 8)

    def test_selected_modes_share_output_csv_and_only_selected_comparison_rows_get_test_metrics(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            train = root / "train"
            train.mkdir()
            trial = trial_fixture(str(root / "test.csv"))
            rows = []
            for mode in ("masked", "class0"):
                _, bundle = model_bundle(mode, [trial])
                directory = train / mode
                directory.mkdir()
                checkpoint = directory / "hrm_bundle.pt"
                torch.save(bundle, checkpoint)
                probability = np.eye(3) if mode == "masked" else np.column_stack([np.zeros(3), np.eye(3)])
                np.savez(directory / "validation_predictions.npz", location_probabilities=probability,
                         actual_ids=[5, 11, 18], load_state=[1, 1, 1])
                row = {"mode": mode, "force_model": "mlp", "location_model": "mlp", "status": "complete",
                       "force_rmse_xyz_mN": 1.0, "location_macro_recall": 1.0,
                       "location_validation_ce": 0.1, "bundle": str(checkpoint)}
                rows.extend([row, {**row, "force_rmse_xyz_mN": 2.0}])
            pd.DataFrame(rows).to_csv(train / "comparison.csv", index=False)
            with patch("hrm_force.independent_prediction.load_prediction_trials", return_value=[trial]):
                output = select_and_evaluate(train, root / "predictions", "cpu")
            frame = pd.read_csv(output / "predictions.csv")
            self.assertEqual(set(frame["mode"]), {"class0", "masked"})
            self.assertEqual(len(frame), 16)
            self.assertIn("optimized_region_upper_probability", frame)
            comparison = pd.read_csv(train / "comparison.csv")
            self.assertEqual(comparison["selected_for_test"].sum(), 2)
            self.assertTrue(comparison.loc[~comparison["selected_for_test"], "test_force_rmse_xyz_mN"].isna().all())
            report = json.loads((output / "metrics.json").read_text())
            self.assertEqual(report["force_numerical_tie_tolerance_mN"], 1e-3)
            self.assertIn("1e-3 mN", report["selection_rule"])
            for mode in ("masked", "class0"):
                search = report["modes"][mode]["validation_region_search"]
                self.assertEqual(len(search["candidates"]), 136)
                self.assertEqual(search["selection_split"], "validation")


if __name__ == "__main__":
    unittest.main()
