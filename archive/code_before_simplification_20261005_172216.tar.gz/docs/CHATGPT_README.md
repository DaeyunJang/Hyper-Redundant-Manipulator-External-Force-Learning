# HRM 외력·접촉 위치 추정 — 현재 설계와 작업 기록

기준일: **2026-10-05, Asia/Seoul**. 요구사항·실제 구현·검증·후속 작업을 이 문서에서 관리한다.
사용자의 최신 요청이 우선이며 문서 안의 과거 기록이나 실행 예시는 새로운 실행 승인으로 해석하지 않는다.
이전 문서·설정·일지 등 41개 파일은 [보존 archive](../archive/legacy_materials_20260928.tar.gz)에 있다.
Archive에는 정리 전 이 문서와 WORK_LOG, 인계 문서, 과거 설정 및 분석 근거도 포함된다.

## 1. 현재 상태와 승인 범위

- 독립 모델, CSV 단독 처리, 두 무부하 방식, 모든 모델 조합 학습, bundle 추론,
  validation 선택, test 평가 및 그림 생성 기능을 구현하고 검증했다.
- 주 학습 [20260928_221428](../results/train/20260928_221428/)의 **242조합·484분기 학습을 완료**했다.
  Validation으로 선택한 두 bundle의 [test 평가](../results/predict/20260928_224418/)도 완료했다.
  Tip test XYZ RMSE는 123.85 mN이며 모든 축 90 mN 이하 목표는 달성하지 못했다.
  정확 ID의 독립 실험 일반화가 낮다. 최종 수치와 구간 탐색의 한계는 11절에 기록했다.
- 앞선 `20260928_220253` 학습은 TCN 실행 병목을 조사하기 위해 중단했다.
  그 부분 학습의 순위를 최종 결과로 사용하지 않으며 주 실행은 모든 조합을 다시 초기화했다.
- 사용자는 uv 환경 준비·설치·무부하 분석·전체 학습·validation 비교·test 평가를 승인했다.
  원본 CSV는 수정·삭제하지 않는다. ROS·매니퓰레이터 제어 연결은 이번 범위 밖이다.
- 최종 확인용 CSV는 학습 폴더의 `comparison.csv`와 예측 폴더의 `predictions.csv` 두 개가 중심이다.
  상세 감사·근거·학습 이력·경계 후보는 JSON/NPZ, 그림은 PNG로 날짜 폴더 안에 보존한다.
- 2026-09-29 요청에 따라 MATLAB용 모델별 시트 Excel 내보내기를 완료했다.
  [Train/validation](../results/train/20260929_130543_excel/)과
  [test](../results/predict/20260929_130543_excel/)에 힘·ID masked·ID class0를 각각 저장했다.
  총 9개 파일·99개 모델 시트를 검증했으며 열·행·대표 checkpoint 계약은 13절에 기록했다.
- 추가 [ID18 전용 실행](../results/train/20260929_181303_id18_only/)의121조합 학습·test도 완료했다.
  위치는 ID0/18 이진 검출이다. Validation 선택CNN/LSTM의 test XYZ RMSE123.85 mN,
  검출 balanced accuracy81.42%이며 자세한 범위·기존 결과와의 비교는17절에 있다.
- 최신 무부하 설정은 평균 offset 보정 후 경계 폭10% 확대다(19절).
  `configs/train.yaml` 및 ID18 전용 준비 설정에 반영했고 데이터 준비까지 검증했다.
  위 학습 모델들은 이전 교정을 저장한다. 새 기준을 사용한 static 제외 끝단 실험은24절이며,
  새 기준의 ID1–18 위치 학습은 아직 수행하지 않았다.
- 2026-09-29 의도 정정: 새 무부하 경계의 주 관심사는 ID1–18 위치 구분 성능이다.
  힘 회귀는 부하 상태와 무관하게 연속 실측값을 학습한다. 별도 비교 제안은 ID18 전용 힘 모델과
  ID1–18 전체 힘 모델이며, 위치 모델의 학습 범위는 두 경우 모두 ID1–18로 유지하는 방향이다(21절).
- 최신 우선순위 확인(22절): ID18 전용 연속 힘 추정 모델은 필수이며 정확도 개선이 최우선이다.
  별도 body contact 감지 모드에서 구간 인식 약90% 이상을 목표로 한다. 전체 ID 힘 회귀는
  현재 필수 작업이 아니며 앞선 비교 제안으로 남긴다. 운용 모드 전환/제어 연결은 아직 미구현이다.
- Static 제외 끝단11종 비교 완료: [20260929_195732_no_static_tip](../results/train/20260929_195732_no_static_tip/).
  Validation 선택 GRU의 동일 test XYZ RMSE147.88 mN, 축별160.50/97.55/174.15 mN이다.
  ID18 train은 summary_18 한 파일, validation은 summary_18-2 한 파일이다. 기존에는 두 파일 모두
  train이고 static이 validation이었으므로 static 학습 유무만 통제한 비교는 아니다.
  ID1–6은 static 제외 시 각1녹화뿐이라 당시 전체 ID 위치 학습은 미진행했다.
- 2026-10-05 최신 데이터/실행(35절): 사용자가 수동 분리한 train48개(dynamic30+static18), test19개를
  확인했다. Test는 폴더의 파일 그대로 고정하며 ID별로 추가 분할하지 않는다. 별도 답변이 없어
  validation은 각 train CSV의 유효 숫자 행 앞80% 학습/뒤20% 검증으로 기본 설정했다.
  두 역할의30행 창과 scaler fit 행이 겹치지 않는다. Static ID10도 현재 파일에는 유효 힘이 있다.
  **사용자 요청대로 새 학습은 실행하지 않았다.** 데이터 준비와 학습 없는 코드 검증만 완료했다.
- 최신 전처리 합의(34–35절)를 `preprocessing: numeric_compact`로 구현했다. 선택 X/Y의
  빈칸·비수치·NaN/Inf 행을 제외한 뒤 같은 파일/역할 안에서 원래 순서대로 연결한다.
  Valid flag/frame/matching-time/시간 간격 검사는 이 새 학습 데이터 경로에서 생략하고,
  원본 행/시간은 추적용으로 남긴다. 옵션이 없는 과거 설정/bundle은 기존 audited/whole_csv 정책을 유지한다.

## 2. 연구 목표와 입력·출력 계약

목표는 단일 외력이 작용하는 segment와 Fx/Fy/Fz를 추정하는 것이다.
현재 우선순위는 **ID18 전용 연속 3축 힘 정확도 → 별도 body contact 감지 모드의 구간 인식 약90% 이상**이다.
범용 body 힘 회귀는 현재 필수 목표가 아니다. 끝단 힘 제어 모드와 body contact 감지 모드를 구분하며,
body 접촉이 판정된 상황에서 ID18 전용 모델 출력을 검증된 body 힘이나 끝단 힘으로 해석하지 않는다.
동시 복수접촉 분리, 분포하중 추정, 안전 제어 성능을 현재 결과로 주장하지 않는다.

| 구분 | 현재 계약 |
|---|---|
| 입력 그룹 | `wire_length` 4개, `loadcell_tension` 4개, `relative_angle` 18개; 기본 총 26개 |
| 각도 | Base→tip 순서, 홀수 tilt/짝수 pan, rad와 부호·0 유지; 총 18개이지 36개가 아님 |
| 힘 정답 | 기본 `fts_kalman.aligned_fx/fy/fz`, `hrm_base`; CSV mN→학습 N |
| 원본 위치 | `contact_segment_id`는 케이블 연결 위치; 무부하에서도 원본 ID 유지 |
| 신경망 출력 | 힘 3개 회귀값과 위치 logits; 물리 힘은 저장된 target scaler로 역변환 |
| 부하 정답 | 확인된 무부하 기준을 실측 F/T 정답에 적용한 파생 라벨 |
| 향후 제어 부호 | 학습·예측은 저장 부호 유지; HRM 제어에서 역정규화 XYZ에 -1을 한 번 적용 |

입력 열은 명시적 순서로 구성하고 선택 그룹에 맞춰 모델 입력 차원을 자동 결정한다.
Timestamp는 새 numeric_compact 경로에서는 결과 대응용이며 시간창의 제외 조건이 아니다.
과거 audited 경로는 시간 경계 검사를 유지한다. F/T 정답, ID, 파일명, trial ID, GT 부하 상태는 입력에 넣지 않는다.
힘과 위치는 같은 종류의 입력을 쓰지만 지도 파일·유효 시점·정규화는 분기별로 다를 수 있다.
원본 CSV의 열을 지우거나 제한 ID 모델이라는 이유로 앞쪽 각도 채널을 자동 삭제하지 않는다.

## 3. 독립 모델과 모든 조합 학습

`HRMEstimator` 안에 공유 파라미터·공유 encoder가 없는 `force_net`과 `location_net`을 둔다.
각 조합에서 두 네트워크와 optimizer를 새로 만들고 힘·위치를 따로 학습한다.
두 분기의 best epoch가 달라도 각 validation best를 **현재 조합의 bundle 한 개**에 저장한다.
조합 간 가중치 재사용, warm start, 분기 동결, 부분 학습, resume는 새 기본 경로에 없다.
같은 실행의 best 복원과 완료 bundle의 추론용 로드는 제공한다.

후보 11개는 `mlp`, `cnn`, `convmixer`, `resnet`, `lstm`, `gru`, `tcn`,
`transformer`, `kalmannet`, `small_gru`, `residual_tcn`이다.
`kalmannet`은 이 저장소의 GRU+MLP 구현이며 물리 Kalman filter가 아니다.
두 무부하 방식 × 힘 11개 × 위치 11개 = **242개 조합, 484회 분기 학습**을 수행한다.
힘/위치별 구조 크기는 `force_params`/`location_params`에서 후보별로 지정한다.

기본 seed는 42, 위치 분기 seed는 43이다. 분할·분기 초기화·학습 순서를 기록한다.
같은 분기의 설정·데이터·seed가 같으면 다른 파트너와 조합해도 출력이 반복될 수 있다.
이 반복은 새로운 독립 seed 실험이 아니며, 파트너 네트워크의 상호 보완 학습을 의미하지 않는다.
여러 seed 반복 및 입력/시간/모드 요인별 비교는 별도 후속 실험이다.

힘은 확인된 tip trial의 유효한 유부하·무부하 실측값을 모두 사용한다.
Body trial을 tip 정답 0으로 바꾸거나 위치 유효 마스크를 힘 손실에 재사용하지 않는다.
기본 `force_loss: mse`, `target_scaling: true`이며 scaler는 분기별 train 행으로만 fit한다.
부하 기준의 center는 라벨 생성에만 사용하고 회귀 정답에서 추가로 빼지 않는다.
`force_scope: all_single_contact` 실험은 tip 결과와 구분하며 재학습한다.

## 4. 실제 데이터와 고정 분할

입력은 `datasets/train/*.csv`, 최종 평가 입력은 `datasets/test/*.csv`다.
2026-10-05 기본 설정은 사용자가 분리한 test를 고정하고 각 train CSV 내부에서 앞80%/뒤20%를
학습/validation으로 나눈다. 같은 녹화에서 잘라낸 파일을 새 독립 실험으로 간주하지 않는다.
행·겹치는 창을 무작위로 나누지 않으며 다른 파일/역할 사이에 시간창을 연결하지 않는다.
모든 조합이 같은 목록·hash·분할을 사용하며 test는 scaler·학습·모델/경계 선택에 쓰지 않는다.
현재 수치와 재현 명령은35절에 있다. **아래는2026-09-28 실행 당시 데이터/whole_csv 정책의 기록**이다.

주 실행의 [data audit](../results/train/20260928_221428/data_audit.json) 및
[split manifest](../results/train/20260928_221428/split_manifest.json)에서 확인한 수치다.

| 역할 | CSV 수 | 원본 행 수 | 입력·힘 정답이 유효한 과거 30행 창 수 |
|---|---:|---:|---:|
| Train | 29 | 587,096 | 577,337 |
| Validation | 18 | 300,553 | 294,531 |
| Test | 2 | 8,371 | 7,933 |
| 합계 | 49 | 896,020 | 879,801 |

처음 검사 대상은 50 CSV/944,380행이었다. Static ID10 한 파일의 48,360행 모두에
Kalman aligned 힘/frame 정답이 없어 해당 파일을 감독 학습·validation에서 명시적으로 제외했다.
원본은 보존하고 raw로 자동 전환하지 않았다. 최종 49파일에는 입력 무효 1,268행,
힘 정답 무효 1,236행이 있으며 두 수는 중복 가능한 원인별 집계다.
GT 없이 입력만으로 만들 수 있는 추론 창은 총 879,805개다.

당시 tip train은 `summary_18-2.csv`, `summary_18.csv`의 유효 창 총 16,361개다.
Tip validation은 `summary_static_pan_-30to+30_tilt_-30to+30_interval-15deg_seg-id-18.csv`의 71,869개 창이다.
파일 길이뿐 아니라 자세·운동 조건도 달라 같은 분포의 반복 실험으로 간주하지 않는다.
Test는 `summary_test_18-2.csv` 2,601행과 `summary_test_18.csv` 5,770행이며 둘 다 ID18이다.
이 test로 body 전체 위치 정확도나 세 구간 경계의 보편적 최적성을 검증할 수 없다.

### 확인된 중복·시간·라벨 처리

- Train `summary_18-2.csv`의 원본 ID1은 과거 사용자가 확인한 ID18 실험이다.
  정확한 SHA-256 `269578…c3af`에만 학습용 ID18 매핑을 적용하며 원본은 유지한다.
- 이전 test `summary_18-3.csv`(`96a85d…fe203`)는 위 trial의 ID 정정/재출력본이다.
  사용자가 `datasets` 바로 아래로 옮겼고 현재 train/test 탐색에서 제외된다.
  두 hash의 개발 역할과 기존 보호 test hash를 보존해 재유입을 차단한다.
- Trim 이력이 있는 ID15·16·17 및 test ID18 네 파일은 저장 anchor 이동과 여러 독립 topic의
  시각/skew를 전 행에서 대조해 메모리에서만 복원했다. 허용 오차는 20 μs이며
  과학적 표기 저장 정밀도 수준의 복원이다. 원래 정확한 ns 값을 완전히 복구했다고 주장하지 않는다.
- 예외·제외 근거는 [dataset_contracts.json](../hrm_force/dataset_contracts.json)의 정확한 hash로 제한한다.
  파일명만 보고 다른 실험에 보정·제외를 확대하지 않는다.
- 결측·비수치·무효 flag·matching skew 초과를 0이나 무부하로 채우지 않는다.
  학습 창은 입력·힘 정답의 연속 유효 구간 안에서 생성하고 invalid 행을 가로질러 연결하지 않는다.
- 기본 matching skew는 25 ms, 큰 gap은 양의 간격 중앙값의 1.5배 초과다.
  추론은 입력 유효성만으로 창을 만들고 GT 누락 때문에 가능한 원시 예측을 버리지 않는다.
- Set-zero 이벤트 검출, trial별 영점·필터 안정화 시간의 자동 보정은 현재 제공하지 않는다.

## 5. 무부하 원기록 분석과 현재 라벨

이 절의 수치는 2026-09-28 학습 및 기존 ID18 전용 모델이 사용한 median/1.0 기준이다.
2026-09-29 새로 적용한 mean/1.1 기준과 보정 좌표 범위는19절에 있다.

사용자가 지정한 기준은 `datasets/aidin_FT_sensor_validation_2/csv/summary.csv`다.
[무부하 분석 JSON](../results/train/20260928_221428/diagnostics/no_load.json)과
[실제 학습 calibration](../results/train/20260928_221428/calibration.json)에 근거·hash·수치를 저장했다.
Raw와 Kalman을 모두 분석했지만 현재 학습 부하 정답은 Kalman 기준이다.

| 기록 | 녹화 시작 KST | 행/길이 | Kalman XYZ 표준편차 mN | Raw XYZ 표준편차 mN |
|---|---|---|---|---|
| validation2, 기준 | 2026-09-26 22:22:33 | 2,797 / 93.30초 | 48.75 / 46.02 / 70.07 | 99.89 / 94.86 / 142.94 |
| validation1, 전이 점검 | 2026-09-26 22:24:25 | 2,808 / 93.63초 | 45.36 / 43.57 / 72.91 | 103.01 / 92.60 / 143.81 |

두 기록의 선택 F/T 유효성·시간 matching 검사에는 무효행이 없었다.
좌표 변환 snapshot `[-y, -x, -z]`와 LPF/MAF off 설정은 같지만 저장 force offset은 다르다.
Sensor-frame offset XYZ는 validation2의 `[1342, 623, -3010]`, validation1의 `[1314, 668, -2886]` mN이다.
동일 tare/Kalman 상태는 보장되지 않으며 Kalman 내부 Q/R은 캡처 자료에 없다.
Kalman 표준편차는 raw의 약 0.44–0.51배였지만 작은 실제 부하 민감도나 지연 개선을 입증한 결과는 아니다.

기존 학습 기준은 validation2 앞 70%인 1,957행으로 fit하고 뒤 840행으로 시간 holdout 점검했다.
축별 fit median을 `b`, 표준편차를 `s`라 할 때 `score = max_a |F_GT[a] - b[a]| / s[a]`이다.
Fit score의 95% 분위수 2.482539 이하는 무부하, 99.5% 분위수 3.245299 이상은 유부하,
그 사이는 uncertain이다. 이전 상태를 유지하는 시간 히스테리시스와는 다르다.

| 축 | 부하 라벨 center b, mN | 무부하 상자 반폭, mN | 유부하 판정 상자 반폭, mN |
|---|---:|---:|---:|
| Fx | -64.59 | 122.37 | 159.97 |
| Fy | 18.62 | 115.53 | 151.03 |
| Fz | -83.53 | 175.53 | 229.46 |

따라서 세 축이 모두 Fx **[-186.97, 57.78]**, Fy **[-96.91, 134.15]**,
Fz **[-259.05, 92.00] mN** 안이면 현재 무부하 라벨이다.
유부하 경계는 더 넓은 상자이며 그 사이를 uncertain으로 두어 위치 손실에서 제외한다.

뒤 840행의 무부하/uncertain/유부하 오경보 비율은 **97.02% / 2.74% / 0.238%**다.
기준을 다시 fit하지 않고 validation1 전체에 적용하면 **79.88% / 15.49% / 4.63%**다.
두 기록의 Kalman median 차이는 약 `[42.48, -35.36, 108.43]` mN으로 세션 영점 전이 한계가 보인다.
Raw에서 별도로 구한 기준의 validation1 오경보는 0.855%지만 raw가 더 우수한 검출기라는 결론은 아니다.
기존 0 중심 ±45.4/43.6/72.9 mN 상자는 Kalman validation2에서 92.10%를 유부하로 오경보했다.
과거 1σ 상자나 tip RMSE 약 90 mN을 새 무부하 기준으로 재사용하지 않는다.

이 비율은 알려진 무부하 기록의 경험적 포함률이며 상관된 행의 독립 신뢰구간이 아니다.
Validation1은 약 2분 뒤 같은 날짜 기록으로 다른 날짜·환경의 독립 교정 검증을 대신하지 않는다.
실제 미세 부하 민감도, 모든 trial로의 영점 전이, 센서의 절대 물리 교정은 아직 검증되지 않았다.
단위는 기존 프로젝트의 mN 계약을 유지하며 이번 통계 분석이 단위를 새로 교정한 것은 아니다.

## 6. masked와 class0, 시간창의 의미

| 상태 | masked 위치 지도 | class0 위치 지도 |
|---|---|---|
| 활성 ID의 확실한 유부하 | 실제 ID에 대응하는 내부 class | 실제 ID에 대응하는 내부 class |
| 확실한 무부하 | 위치 손실 제외 | 일반 class0으로 학습 |
| uncertain·무효 정답 | 위치 손실 제외 | 위치 손실 제외 |
| 비활성 ID의 유부하 | 위치 손실 제외 | 위치 손실 제외; 무부하로 바꾸지 않음 |

Masked 출력은 활성 ID 수 M개, class0는 M+1개다. Class0의 0을 ignore index로 사용하지 않는다.
현재 코드는 유효한 위치 endpoint만 optimizer에 전달해 전부 무효인 배치의 NaN 평균을 피한다.
무부하 센서 행은 과거 이력에 남는다. 해당 시점의 위치 손실 제외와 입력 행 삭제는 서로 다르다.
LSTM 등에서는 이후 유부하 손실이 과거 무부하 입력 처리 경로에도 기울기를 전달할 수 있다.

시간창은 과거 W=30행으로 현재 하나를 예측하는 stateless sequence-to-one이다.
파일·유효 구간 경계를 넘지 않고 창마다 recurrent state를 초기화한다.
MLP는 마지막 행만 사용하되 공통 평가를 위해 같은 30행 준비 조건을 사용한다.
미래 입력·중앙 필터·미래 보간을 추가하지 않는다. 준비 전 출력은 N/A이지 오차 0이 아니다.

Masked는 무부하를 검출하도록 학습하지 않는다. 배포 gate가 없으므로 위치는 `unverified`,
최종 ID/무부하 검출/시스템 지표는 N/A다. GT gate는 오프라인 진단에만 사용한다.
Class0 후보 판정은 0을 포함한 전체 class argmax이며 p0를 따로 저장한다.
이 규칙의 test 평가는 가능하지만 배포 gate의 교정·실시간 안전성을 입증한 것은 아니다.
Tip 힘 모델의 작은 출력으로 모든 body 접촉을 무부하라고 판정하지 않는다.

## 7. 구간 확률과 공정한 평가

기본 구간은 하단 1–10, 중부 11–15, 상단 16–18이다. 제한 ID에서는 활성 ID와의 교집합을 사용한다.
Softmax 뒤 원래 segment 확률을 더해 구간을 고른다. Logits를 더하거나 segment 수로 나누지 않는다.
Class0의 세 구간 확률합은 1-p0다. 히트맵은 원래 확률과 고정 0–1 색 범위를 유지한다.
전역 ID argmax와 선택 구간 내부 대표 ID는 별도로 기록한다.
높은 구간 확률은 평가 정답률이 아니며 히트맵 폭은 실제 접촉 길이가 아니다.

Validation에서 연속 3구간 경계 **136개 모두**를 계산한다. 기본 최소 구간 크기는 3이다.
선택에는 세 구간 모두 GT support가 있는 후보만 쓰고 모든 후보의 제약·support를 저장한다.
`region_balanced_id_macro_recall`은 region 안의 실제 ID별 region recall을 평균한 뒤
세 region을 동일 가중 평균한다. 한 region에 GT support가 없으면 전체 점수는 N/A다.
동률은 region macro recall → 전체 ID macro region recall → 기본 경계와 거리 → 작은 경계 순이다.
항상 하단만 예측하면 10/5/3, 12/3/3 모두 새 점수는 1/3이다. 원래 확률합은 바꾸지 않는다.
경계는 validation에서만 고르고 고정한 뒤 test에 적용한다. 탐색 validation 점수는 독립 평가가 아니다.

- 힘: 축별 RMSE/MAE와 `sqrt(sum(XYZ 오차²)/(3N))`인 pooled XYZ RMSE를 mN로 보고한다.
  축별 RMSE 평균, 벡터오차 norm RMSE, 힘 크기만의 RMSE와 구분한다.
- 위치: 동일 GT-loaded 활성 ID 시점에서 exact ID, 실제 ID 차이 ±1, ID별/macro recall을 보고한다.
  Class0에서 p0를 무시한 위치 진단과 검출 실패를 포함한 시스템 지표를 분리한다.
- 검출: 유부하 precision/recall/FPR/FNR, 무부하 precision/recall, balanced accuracy를 따로 기록한다.
  Unsupported loaded ID를 무부하로 바꾸지 않고 범위 밖 표본으로 집계한다.
- 향후 ID1–4 포함/제외 비교는 공통 ID5–18의 같은 시점에서 한다. 이번 실행은 ID1–18 전체를 유지했다.
  비활성 칸 N/A는 범위 밖 자동 검출이 아니다.
- Mode 간 CE 절대값, 기존 전체 시점 정확도와 새 유부하 정확도, 서로 다른 평가 시점을 직접 비교하지 않는다.

각 mode의 최종 bundle 선택은 validation pooled 힘 RMSE 최소를 우선한다.
최소값과 차이가 1e-3 mN(1 μN) 이내이면 수치적 동률로 보고 위치 macro recall 최대,
위치 CE 최소, 모델명 순으로 정한다. 동일 seed CUDA 재학습의 약 1e-5 mN 변동이
위치 후보 선택을 좌우하지 않게 하는 규칙이며 성능 허용폭이나 통계적 동등성 기준은 아니다.
이 규칙은 test 평가 전에 정했고 test 결과로 조정하지 않았다.
이미 학습한 해당 pair bundle을 그대로 사용하며 다른 조합의 가중치를 새로 섞지 않는다.
Test 수치는 선택된 행의 `test_*` 열에만 추가하고 최적 구간 test 지표는 별도 열로 구분한다.

## 8. 데이터 조건 진단과 해석 제한

[개발 자료 진단](../results/train/20260928_221428/diagnostics/dataset.json)은 중단 실행의 자료 점검에서 시작했다.
주 실행과 trial hash 순서·고정 split이 동일함을 확인했고 현재 주 실행의 diagnostics로 모았다.
이는 모델 성능이 아닌 데이터 기술 통계다. Train 유효 창의 유부하/무부하/uncertain 비율은
54.32%/31.45%/14.23%, validation은 60.77%/26.20%/13.03%로 같지 않다.
Train scaler 기준 입력 중 하나라도 |z|>3인 행은 train 6.91%, validation 24.97%였다.
이는 여러 상관된 채널의 기술 통계이며 교정된 이상 확률이 아니다.

Static ID3 validation의 `relative_angle_1`은 인접 부호 전환 비율 100%,
중앙 절대 변화량 약 1.777 rad로 다른 파일과 큰 차이가 관찰됐다. 원본을 임의 수정하지 않았다.
초기 ID의 약한 반응 관찰은 보존하되 자세·힘 방향을 맞춘 인과 비교를 하지 않았으므로
유부하/무부하 평균 차이만으로 base의 관측 불가능성이나 제외 경계를 확정하지 않는다.
ID별 힘 크기·방향·자세와 static/nonstatic 구성이 다르며 파일명만으로 운동 protocol을 단정하지 않는다.
이 진단에서 test는 정체성·유효성 metadata만 확인했고 test 분포로 학습 조건을 조정하지 않았다.

같은 CNN 위치 구조의 best epoch 1을 복원해 ID별 유부하 500행씩을 동일 규칙으로 뽑은
[추가 일반화 진단](../results/train/20260928_221428/diagnostics/location_generalization_sample.json)에서는
정확 ID macro recall이 masked train 65.67% → validation 3.41%,
class0 train 67.32% → validation 3.56%였다. 기본 세 구간의 구간균형 ID macro recall도
각각 84.86% → 45.02%, 85.92% → 43.78%로 낮아졌다.
이는 녹화 간 일반화 격차와 일치하지만 특정 센서·자세 차이가 원인이라는 증명은 아니다.
최종 선택 모델 평가가 아닌 동일 CNN 구조 진단이며 test는 사용하지 않았다.

같은 tip validation 71,869시점의 [상수 힘 기준선](../results/train/20260928_221428/diagnostics/force_validation_baselines.json)은
train 정답 평균 출력 시 XYZ RMSE/MAE 307.57/220.64 mN, 항상 0 N 출력 시 307.45/214.20 mN였다.
이는 모델 성능을 판단하는 참고선이며 힘을 0으로 강제하는 운영 정책이 아니다.

## 9. 설정과 실행

사용자가 수정하는 기본 파일은 [configs/train.yaml](../configs/train.yaml) 하나다.
데이터 예외·보호 hash는 내부 계약에 보존하고 실행 시 resolved 설정과 bundle에 넣는다.
아래는 기존 YAML의 해당 키를 바꾸는 예이며 입력/모델 변경은 새 학습으로 남긴다.

```yaml
feature_groups: [wire_length, loadcell_tension, relative_angle]
force_source: kalman
force_columns: [fts_kalman.aligned_fx, fts_kalman.aligned_fy, fts_kalman.aligned_fz]
no_load_modes: [masked, class0]
force_candidates: [lstm, gru]
location_candidates: [lstm, tcn]
force_params:
  lstm: {hidden_sizes: [60, 30], projection_dim: 32}
location_params:
  lstm: {hidden_sizes: [48, 24], projection_dim: 24}
```

형상 제외는 `feature_groups: [wire_length, loadcell_tension]`로 설정한다.
Base 제외는 `active_ids: [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]`로 설정한다.
Raw 전환은 `force_source: raw`와 `fts.aligned_fx/fy/fz`를 함께 선택하고 raw 기준을 새로 확인한다.
현재 기본은 60 epoch 상한, patience 10, batch 1,024, learning rate 0.001,
AdamW weight decay 0.0001, clipping norm 1.0, threads 4다. Test로 최적화한 값이 아니다.

```bash
bash scripts/hrm_python.sh train.py --config configs/train.yaml --check-data
bash scripts/hrm_python.sh train.py --config configs/train.yaml
bash scripts/hrm_python.sh predict.py --train-dir results/train/20260928_221428
bash scripts/hrm_python.sh predict.py --checkpoint <조합폴더>/hrm_bundle.pt --input-dir datasets/test
bash scripts/hrm_python.sh scripts/plot_independent_results.py --train-dir <학습폴더> --predict-dir <예측폴더>
```

`--check-data`는 검사·분할 저장까지, 일반 train은 전체 설정 조합 학습까지 수행한다.
Predict는 bundle의 구조·class 매핑·입력 순서·단위·scaler·calibration을 복원하고 새 YAML로 덮어쓰지 않는다.
**`HRMEstimator.forward()`의 force는 target scaling 사용 시 학습 정규화 단위다.**
직접 연결 시 분기별 저장 X scaler와 힘 Y 역변환이 필요하다. `predict.py`는 이를 적용한 N/mN를 저장한다.
자동 제어용 -1 곱은 하지 않는다. 낮은 수준의 forward 출력을 곧바로 물리 힘으로 사용하지 않는다.
정답 없는 CSV도 입력이 유효하면 예측한다. 모든 원본 행을 보존하고 준비 중/invalid 출력은 NaN이다.
Tip 적용이 확인되지 않은 파일에도 raw XYZ를 출력하되 `scope_unverified`로 표시하고 힘 지표에서 제외한다.
그림은 파일별 힘 3축 및 mode별 확률/p0/구간합을 표시하고 invalid·시간 gap을 연결하지 않는다.
기존 JSON 기반 legacy CLI는 과거 checkpoint 호환용이며 새 YAML 실험과 혼합하지 않는다.

## 10. 환경, 실행 이력, 검증

Uv 환경 `env_hrm_force_estimation`은 Python 3.10.20, PyTorch 2.7.1+cu126/CUDA 12.6,
NumPy 1.26.4, pandas 2.3.1, matplotlib 3.5.1, PyYAML 6.0.2다.
`uv pip check`와 실제 CUDA 행렬 연산을 통과했고 장치는 NVIDIA GeForce RTX 4090이다.
Kernel module 580.173.02와 시스템 NVIDIA library 580.178.04가 달라 초기 CUDA 접근이 실패했다.
580.173.02 library를 `.runtime/nvidia-580.173.02`에 추출하고 **해당 프로세스 검색 경로만** 맞췄다.
시스템 driver 설치·kernel module 교체·재부팅은 하지 않았다. train/predict와 wrapper가 이를 지원한다.

22:02:53 실행에서 TCN 첫 epoch 약 172.7초 병목을 확인하고 부분 실행을 중단했다.
[분리 프로세스 벤치마크](../results/train/20260928_221428/diagnostics/convolution_benchmark.json)의
입력 `[1024, 30, 26]` TCN forward/backward 중앙값은 deterministic cuDNN 379.8 ms,
autotune cuDNN 0.964 ms였다. 이는 batch 학습 연산 시간이며 실시간 batch1 전체 지연이 아니다.
CPU float64 기준 출력·기울기 오차와 유한성을 확인했고 벤치마크 optimizer update는 0회였다.
주 실행은 `cudnn_deterministic: false`, `cudnn_benchmark: true`로 바꿔 22:14:28에 전 조합을 새로 시작했다.
같은 seed라도 비트 단위 재현성과 장치·버전 간 동일 학습 결과는 보장하지 않는다.

- 요청/수행 순서: 문서 이해 → 현황 점검 → 사용자 무부하 원본·무인 실행 승인 → 환경 준비 →
  전체 CSV/calibration 점검 → 독립 모델 구현 → 합성 검증 → 실제 학습 → 병목 검증 후 새 전체 실행.
- 해당 학습 실행 당시 전체 회귀검증: **140개 테스트, 2.675초, 통과**. 로그는 `diagnostics/tests.log`에 보존한다.
  이 검증은 코드 계약 검사이며 모델 정확도나 전체 학습 완료를 뜻하지 않는다.
- Bundle 저장 전후 두 분기 출력 일치, 입력만 있는 추론, 무부하/불확실/범위 밖 구분,
  GT 없는 force scope, validation만의 선택, 136경계, 확률 동률·균형 점수를 검증했다.
- 독립 재검산에서 첫 checkpoint validation 힘 RMSE는 원본 재계산 174.239578684 mN,
  저장 지표 174.239578640 mN으로 수치오차 내 일치했다. 이는 최종 선택 모델의 성능 보고가 아니다.
- 그림은 합성 두 mode·invalid·시간 gap으로 5개 PNG를 렌더링하고 원본 CSV hash 불변을 확인했다.
- 원본 무부하 두 기록과 개발 자료의 분석 전후 hash를 확인했다. 상세 수치·환경은 실행 JSON에 보존한다.
- 예비 실행 폴더는 삭제하지 않고 `.runtime/development_checks/train_<이전실행>`으로 이동했다.
  무부하·개발 자료·연산 벤치마크 근거는 주 실행의 `diagnostics/`에 JSON/PNG로 모았다.

## 11. 최종 결과 — 2026-09-28 22시 44분 학습·test 완료

사용자의 무인 실행 요청에 따라 환경 설치, 무부하 재분석, 고정 파일 분할, 242개 새 조합 학습,
validation 선택, test 두 파일 평가와 결과 정리를 완료했다. 주 학습은 약 30분 소요됐다.
242개 bundle 및 각 분기의 이력·분할을 확인했고, 총 484회 분기 학습이 저장되어 있다.
실행 시작과 비교한 원본 CSV/무부하 기준 51개의 hash가 일치한다.
140개 회귀검증, CSV의 확률합·원본행 보존·힘 오차 재계산 검사도 통과했다.

### 먼저 볼 파일

| 파일 | 내용 |
|---|---|
| [comparison.csv](../results/train/20260928_221428/comparison.csv) | 242조합의 validation 지표; `selected_for_test=True` 두 행에만 test 지표 추가 |
| [predictions.csv](../results/predict/20260928_224418/predictions.csv) | 두 mode × 원본 8,371행 = 16,742행; 연속 XYZ, p0/p1–p18, 기본/탐색 구간 확률 |
| [metrics.json](../results/predict/20260928_224418/metrics.json) | 모델 선택 근거, 파일별 지표, 혼동행렬, 모든 경계 후보와 support |
| [학습 그림](../results/train/20260928_221428/figures/) / [test 그림](../results/predict/20260928_224418/figures/) | 모델 비교 2개 PNG와 파일별 힘·mode별 히트맵 6개 PNG |
| [최종 검사](../results/train/20260928_221428/diagnostics/final_verification.json) | 조합/분기 수, 분할·bundle·CSV 확률합·물리 단위 재계산 검증 |

`results/` 아래 CSV는 위 두 개다. 예비·중단 실행은 `.runtime/development_checks`에 보존했다.
비교표에서 접두사 없는 성능 열은 validation, `test_`는 기본 구간의 test,
`test_optimized_`는 validation에서 경계를 정한 구간의 test 지표다.
RMSE/MAE는 mN, 정확도·recall·확률 열은 0–1이다. N/A는 성능 0이 아니다.
추론 준비 행은 각 mode 7,933개이고, 위치 조건부 test 평가의 GT 유부하는 3,536개다.
준비 전 행은 그대로 남고 예측은 NaN이다. 무부하에서도 준비된 힘 예측은 연속 실수값이다.

### 힘 모델 비교와 최종 test

아래 validation 값은 동일 힘 모델의 파트너·mode 반복 실행 중앙값이다.
새 seed 반복이나 신뢰구간 추정은 아니다. 같은 tip validation 71,869시점을 평가했다.

| 힘 모델 | Validation XYZ RMSE mN | XYZ MAE mN |
|---|---:|---:|
| CNN | 171.93 | 123.42 |
| MLP | 174.24 | 126.40 |
| small_gru | 174.69 | 126.79 |
| ResNet | 176.74 | 129.18 |
| Transformer | 181.12 | 131.72 |
| KalmanNet/GRU+MLP | 183.51 | 134.96 |
| TCN | 183.63 | 135.65 |
| GRU | 187.48 | 135.60 |
| LSTM | 189.89 | 135.50 |
| residual_tcn | 191.88 | 144.11 |
| ConvMixer | 218.86 | 169.24 |

두 mode 모두 힘 CNN이 선택됐다. 위치는 masked CNN, class0 LSTM이다.
힘 학습은 위치 방식과 독립이므로 두 선택 bundle의 힘 오차는 표시 정밀도에서 같다.

| 평가 | XYZ RMSE mN | XYZ MAE mN | Fx/Fy/Fz RMSE mN |
|---|---:|---:|---|
| Validation | 171.93 | 123.42 | 228.14 / 145.81 / 123.98 |
| Test 전체 | 123.85 | 81.28 | 158.56 / 80.26 / 120.15 |
| Test `summary_test_18-2.csv` | 90.49 | 69.08 | 파일별 축 지표는 metrics.json |
| Test `summary_test_18.csv` | 137.01 | 87.14 | 파일별 축 지표는 metrics.json |

Test 유부하 시점만의 XYZ RMSE는 **168.14 mN**, 무부하 시점은 **67.46 mN**이다.
전체 123.85 mN만으로 유부하 힘 정확도를 설명하지 않는다. 두 파일 간 성능 차이도 크다.
항상 0을 출력하는 validation 기준선 307.45 mN보다 학습 모델은 개선됐지만,
**모든 축 RMSE 50–90 mN 목표는 달성하지 못했다.**
과거 같은 녹화 앞/뒤 분할의 결과와 이번 파일 단위 validation은 평가 조건이 달라 직접 순위를 매기지 않는다.

### 위치·무부하와 구간 경계

정확 ID는 충분히 일반화하지 못했다. 아래 test ID/구간 recall은 GT 유부하 조건의 위치 진단으로,
class0의 무부하 검출 실패를 포함한 시스템 값과 구별한다.

| 방식/위치 모델 | Validation 정확 ID macro recall | Test ID18 recall | 기본 16–18 구간 test recall | 탐색 상단 구간 test recall |
|---|---:|---:|---:|---:|
| masked / CNN | 3.42% | 9.22% | 50.48% | 58.57% |
| class0 / LSTM | 6.64% | 10.27% | 31.31% | 66.09% |

Class0 test 유부하 recall은 **82.47%**, 무부하 recall은 **90.98%**, 검출 balanced accuracy는 **86.72%**다.
검출 실패까지 포함하면 유부하 ID18 정확도는 **7.92%**, 탐색 상단 구간 정확도는 **60.58%**다.
Masked에는 자체 무부하 검출기가 없어서 이 시스템 지표를 제공하지 않는다.
이 검출 평가는 무부하 범위로 파생한 라벨에 대한 것이며 실제 접촉의 별도 계측 검증이 아니다.

| 선택 위치 모델 | Validation 탐색 경계 | 기본 → 탐색 구간균형 ID macro recall | 탐색 구간의 행 가중 정확도 |
|---|---|---:|---:|
| masked CNN | 1–8 / 9–14 / 15–18 | 44.90% → 64.05% | 75.04% |
| class0 LSTM | 1–8 / 9–12 / 13–18 | 50.13% → 66.88% | 79.74% |

두 결과는 하단 경계 8에서 일치하지만 중간/상단 경계는 다르다. Class0 운용 후보로는
**1–8 / 9–12 / 13–18**을 검토할 수 있지만, 상단의 범위가 넓어져 얻은 이점과
validation 경계 탐색의 낙관성을 함께 고려해야 한다. 해부학적·기계적 최적 경계로 확정하지 않는다.
79.74%는 경계를 고르는 데 쓴 validation의 행 가중 정확도이고,
66.09%는 ID18-only test의 상단 구간 recall이다. 전체 3구간 독립 정확도 80%로 표현하지 않는다.
또한 선택 모델의 구조가 CNN과 LSTM으로 달라 이 차이를 class0 처리만의 효과라고 단정하지 않는다.

### 추론 시간과 다음 우선순위

[batch1 연산 측정](../results/predict/20260928_224418/inference_timing.json)에서
CNN/CNN의 CPU/GPU 중앙값은 0.095/0.161 ms, CNN/LSTM은 0.276/0.239 ms였다.
각 20회 준비 후 100회 측정했으며 분기별 정규화·두 네트워크·힘 역변환·softmax를 포함한다.
합성 입력이 장치에 이미 준비된 경우다. 센서/필터, 30행 준비, 파일 읽기, 장치 전송,
ROS 스케줄링은 제외하므로 전체 제어 지연이나 실시간 마감 보장이 아니다.

현재 결과에서는 모델 종류 추가보다 아래 확인이 우선이다.

1. Static ID3 각도의 매 행 부호 반전 원인을 원 수집/형상 계산 단계에서 확인한다.
2. 각 녹화의 무부하 구간·tare 상태를 함께 보존해 세션 간 영점 전이와 작은 실제 부하 검출을 검증한다.
3. ID마다 공통 자세·힘 방향·크기를 갖춘 독립 녹화를 추가해 조건과 ID가 뒤섞이는 문제를 줄인다.
4. 전체 body test와 여러 seed로 구간 경계를 재검증하고, base 제외 실험은 공통 ID의 동일 validation에서 비교한다.

이번 작업에서 body 전체 힘 모델 학습, base 제외 비교, 물리 접촉 gate 교정,
동시 다중접촉 분리와 ROS 연결은 수행하지 않았다. Tip 연속 힘·전체 ID 위치 모델의 현재 결과와 구별한다.

## 12. 2026-09-29 — 실측 XYZ와 모델별 예측값의 저장 위치 확인

- 요청: RMSE 요약 외에 정답 `fx/fy/fz`와 `fx_pred_모델명/fy_pred_모델명/fz_pred_모델명`
  형태의 시점별 자료가 있는지 확인.
- 수행·검증: 기존 test `predictions.csv`의 실제 헤더와 모델 조합을 확인했다.
  `true_fx_mN/true_fy_mN/true_fz_mN` 및 `pred_fx_mN/pred_fy_mN/pred_fz_mN`가 있으며
  N 단위 열도 별도로 있다. 파일·원본 행·시간으로 대응시킬 수 있다.
  현재 test CSV는 validation에서 선택한 두 조합만 담고, 두 조합의 **힘 모델은 모두 CNN**이다.
  `location_model=lstm`을 LSTM 힘 예측으로 해석하지 않는다.
- Validation은 242조합 각각의 `validation_predictions.npz`에 시점별 힘 예측과
  원본 trial/행 참조를 저장했다. `comparison.csv`는 이 예측을 집계한 성능 비교표다.
  확인한 CNN/CNN 파일의 `force_N`은 역정규화된 예측 71,869×3, `force_refs`는
  trial 인덱스/원본 행 71,869×2다. GT XYZ는 NPZ 안에 없으며 참조 원본 CSV의
  `fts_kalman.aligned_fx/fy/fz`와 연결해야 한다.
- 미실행/다음: 11개 힘 모델의 test 예측을 모델별 열로 합친 가로형 CSV는 아직 없다.
  필요 시 저장된 bundle로 추론·열 재구성할 수 있으며 재학습은 필요하지 않다.
  이번 확인에서는 새 학습·추론·결과 파일 생성이나 기존 모델 선택 변경을 하지 않았다.

## 13. 2026-09-29 — MATLAB 분석용 모델별 Excel 내보내기

### 요청과 구성

사용자는 모델을 직접 필터링하지 않고 Excel 시트별로 실측/예측을 읽도록 요청했다.
RMSE·MAE는 MATLAB에서 직접 계산할 예정이므로 이번 Excel은 정답·예측 행을 중심으로 구성한다.
기존 242조합의 저장된 best 분기를 사용하며 **새 학습과 기존 모델 선택 변경은 하지 않는다.**
Train replay는 학습에 사용된 CSV, validation은 고정된 개발 검증 CSV, test는 보호된 두 CSV다.
학습 데이터에 대한 replay를 일반화 성능으로 해석하지 않는다.

아래 위치에 **9개 Excel·99개 모델 시트 저장과 실제 파일 정합성 검증을 완료**했다.

```text
results/train/20260929_130543_excel/
  train/
    force_estimation_all_models.xlsx
    id_estimation_masked.xlsx
    id_estimation_class0.xlsx
  validation/
    force_estimation_all_models.xlsx
    id_estimation_masked.xlsx
    id_estimation_class0.xlsx
  export_manifest.json
  verification.json
  verification_tests.log
results/predict/20260929_130543_excel/
  force_estimation_all_models.xlsx
  id_estimation_masked.xlsx
  id_estimation_class0.xlsx
  export_manifest.json
  verification.json
```

각 Excel에는 `MLP`, `CNN`, `ConvMixer`, `ResNet`, `LSTM`, `GRU`, `TCN`,
`Transformer`, `KalmanNet`, `Small_GRU`, `Residual_TCN`의 11개 데이터 시트가 있다.
`_INFO`는 단위·행 의미·사용한 bundle 정보, `_FILES`는 숫자 file_id와 원본 파일·hash의 대응표다.
데이터 시트 안에서 서로 다른 모델이나 train/validation/test가 섞이지 않는다.

### 열과 행 계약

- 힘의 주요 열: `gt_fx_mN`, `gt_fy_mN`, `gt_fz_mN`, `pred_fx_mN`, `pred_fy_mN`, `pred_fz_mN`.
  역정규화한 N을 mN으로 변환했으며 무부하 강제0·제어용 부호반전을 적용하지 않는다.
- ID의 주요 열: `ground_truth_id`, `pred_id`, `contact_id_effective`.
  Ground truth는 확실한 유부하의 effective ID, 확실한 무부하의0이다.
  Masked의 pred_id는 조건부 segment argmax라 무부하 검출기가 아니다.
  Class0의 pred_id는0을 포함한 전체 class argmax다. 어느 방식도 예측을 GT로 덮어쓰지 않는다.
- 공통 추적 열: `file_id`, `source_row`(원본 CSV의0부터 시작하는 데이터 행),
  `elapsed_s`(파일 내 초), `continuous_block`, `load_state`.
  19자리 절대 ns 시각을 Excel 숫자로 저장하지 않아 정밀도 손실을 피한다.
- 힘은 원래 학습과 같은 입력·F/T 유효성 및 연속30행 조건을 만족하는 tip 시점만 사용한다.
  Force의 부하 판정 uncertain 행은 XYZ 정답이 유효하므로 유지한다.
- ID는 같은 유효 시점에서 load_state가 loaded/unloaded로 확정된 행만 사용한다.
  Uncertain 행은 모든 위치 모델·두 방식에서 동일하게 제외하여 정답 열을 빈칸 없이 저장한다.
- 행 제거는 **생성하는 Excel에만 적용**한다. 원본 CSV는 수정하지 않는다.
  파일 변경·행 누락·시간 공백마다 continuous_block이 바뀌므로 이를 가로질러 신호를 이어 붙이지 않는다.
  같은 역할/종류에서는 모든 모델의 file_id/source_row 목록이 동일하다.
- Masked의 조건부 ID 정확도는 load_state=loaded에서 해석한다. 무부하 행의 조건부 위치 출력이
  ID0 검출 결과가 아니므로 class0 전체 시스템 정확도와 그대로 비교하지 않는다.

| 역할 | 각 힘 모델 행 수 | 각 ID 모델 행 수(두 방식 공통) |
|---|---:|---:|
| Train | 16,361 | 495,204 |
| Validation | 71,869 | 256,152 |
| Test | 7,933 | 6,761 |

### 대표 checkpoint와 재현

힘은 `masked__force_<모델>__location_mlp`, 위치는 `<방식>__force_mlp__location_<모델>`을 사용한다.
이는 독립 네트워크의 상대 분기를 고정하는 규칙이며 test 결과로 좋은 checkpoint를 고른 것이 아니다.
동일 구조의 반복 학습은 CUDA 수치 차이가 있을 수 있어 각 시트에 정확한 bundle/hash를 기록한다.
Validation은 저장된 NPZ의 예측과 원본 행 참조를 재사용하고, train/test는 저장 모델을 replay한다.
힘은 현재 tip 전용이며 body 전체 CSV를 힘 정답 비교에 섞지 않는다.

```bash
bash scripts/hrm_python.sh scripts/export_model_workbooks.py --train-dir results/train/20260928_221428
```

```matlab
T = readtable('force_estimation_all_models.xlsx', 'Sheet', 'CNN');
fx_gt = T.gt_fx_mN;
fx_pred = T.pred_fx_mN;
```

### 수행·검증·후속 작업

- `XlsxWriter==3.2.9`를 설치하고 requirements에 추가했다. 패키지 호환 검사 통과.
- 큰 시트는 행 단위 constant-memory 방식으로 기록한다. Excel 행 한도, 중복 시트,
  기존 파일 덮어쓰기, 숫자/빈칸·수식문자열 처리와 원본 시간창 유효성 검사를 구현했다.
- 표 생성·Excel 저장 관련15개 테스트 및 전체 **155개 테스트(2.734초)**가 통과했다.
- 실제 test의 MLP로 3종 Excel 시범 실행과 전체 11종·3역할 내보내기를 마쳤다.
  13:12:38 KST 완료, 내보내기 415.50초, Excel 총 736,787,210바이트다.
  원본 CSV 49개의 hash를 전후 대조해 변경 없음을 확인했다.
  Train/predict의 export_manifest.json은 동일하며 실행 완료·정확한 bundle·행 cohort·산출물 hash를 보존한다.
- 실제 MLP 시범 파일의 전체 정답 대조와 별도 CPU 예측 복원도 통과했다.
  Excel GT와 원본 mN→학습 float32 N→mN 값의 최대 차이는 4.55e-13 mN,
  원본 CSV mN 자체와의 차이는 최대 5.94e-5 mN이었다.
  독립 CPU 복원의 대표 4개 행 예측과 Excel 차이는 최대 2.24e-5 mN이었다.
- 최종 9개 Excel의 ZIP CRC·XML 문법·헤더·행/셀 수·SHA256를 전수 검사했다.
  모델 시트 99개, 데이터 17,736,367행, 헤더 포함 145,065,206셀을 확인했으며
  오류 셀·수식·NaN/Inf 값은 없었다. 모든 모델의 시트 수·행 수가 manifest와 일치했다.
- Validation 힘 11모델의 790,559행/2,371,677개 예측 값을 저장 NPZ와 전수 대조했다.
  원본 행 참조가 모두 일치하며 예측·GT의 최대 직렬화 차이는 4.55e-13 mN이었다.
  Validation ID 22개 시트의 대표 1,430행은 18개 녹화·유부하/무부하를 포함해
  예측·GT·원본 행·부하 상태를 대조했고 모두 일치했다.
- Test 33개 시트의 236,005행을 실제 XLSX에서 전수 검사했다.
  모든 모델의 공통 행·GT·상태·원본 매핑이 일치하고 빈칸·중복 key가 없었다.
  ID의 무부하 GT0는 각 시트 3,225행이며 masked 예측에는0이 없어 GT gate 미적용을 확인했다.
- 독립 CPU 복원의 test 표본 ID 88개는 모두 일치했다. Force 표본은 Transformer에서
  최대 0.01124 mN 차이를 관측해, 주 프로세스에서 기존 CUDA·batch_size=1024 조건으로
  Transformer test 7,933행을 다시 추론했다. 행 대응은 전부 일치했고 XLSX와 예측 차이는
  최대 5.68e-14 mN이었다. 장치·batch가 다른 표본 비교와 같은 조건의 재현 검사를 구분한다.
- [통합 검증 결과](../results/train/20260929_130543_excel/verification.json)와
  [실제 테스트 로그](../results/train/20260929_130543_excel/verification_tests.log)를 실행 폴더에 보존했다.
  같은 verification.json을 test 폴더에도 저장했다. `git diff --check`도 통과했다.
- 이번 Excel 요청의 미완료 작업은 없다. 사용자는 위 MATLAB 예시로 원하는 모델 시트의
  축별 정답/예측을 직접 읽고 RMSE·MAE를 계산할 수 있다.

## 14. 2026-09-29 — 축별 RMSE 재집계와 Excel 시트 위치 확인

### 요청과 수행

- 사용자 요청: Excel에서 Fx/Fy/Fz가 보이지 않는다는 확인 요청에 이어,
  실제 예측을 보니 Fx가 특히 부정확해 보이므로 전체 XYZ 대신 축별 RMSE를 계산해 달라고 요청했다.
- 실제 Excel을 읽어 `_INFO`, `_FILES` 다음에 11개 모델 시트가 있고,
  `CNN` 등 모델 시트의 A–C열이 실측 XYZ, D–F열이 예측 XYZ임을 확인했다.
  처음 열리는 기본 시트는 `_INFO`다. 실제 사용자 화면은 보지 않았으므로 이것이
  사용자가 값을 보지 못한 원인이라고 확정하지 않는다. 이번에는 Excel 자체를 변경하지 않았다.
- `scripts/summarize_force_axes.py`를 추가해 3개 force Excel의 실제 숫자 셀에서
  11모델 × train/validation/test의 축별 RMSE·MAE를 float64로 재계산했다.
  기존 모델·원본·Excel·comparison.csv를 변경하지 않았으며 재학습/새 추론은 수행하지 않았다.
- 주 결과는 역할·모델·표본 수·축별 RMSE 3열·축별 MAE 3열만 담은 CSV다.
  [Train/validation 22행](../results/train/20260929_171211_axis_rmse/force_axis_metrics.csv),
  [test 11행](../results/predict/20260929_171211_axis_rmse/force_axis_metrics.csv)에 저장했다.
  부하 상태/원본 CSV별 지표·편향·실측 표준편차는 같은 폴더의 `analysis.json`,
  독립 계산과 출력 검증은 `verification.json`에 보존했다.

### 계산 조건과 결과

축마다 `sqrt(mean((pred_axis - gt_axis).^2))`를 계산한다. 단위는 **mN**이며,
기존 ID18 tip 힘 모델의 내보낸 유효 행을 그대로 사용한다. 무부하를0으로 만들거나,
편향을 빼거나, 부호를 뒤집지 않는다. 전체 지표는 loaded/unloaded/uncertain을 모두 포함하고
여러 CSV의 유효 행에 동일 가중치를 주므로 녹화별 RMSE의 단순 평균과 다르다.
Train 결과는 학습에 사용한 데이터의 재생 결과이며 독립 일반화 성능이 아니다.

| Test 모델 | 표본 수 | Fx RMSE (mN) | Fy RMSE (mN) | Fz RMSE (mN) |
|---|---:|---:|---:|---:|
| MLP | 7,933 | 157.20 | 96.96 | 138.06 |
| CNN | 7,933 | 158.56 | 80.26 | 120.15 |
| ConvMixer | 7,933 | 155.42 | 107.26 | 174.82 |
| ResNet | 7,933 | 159.30 | 91.57 | 115.09 |
| LSTM | 7,933 | 165.89 | 90.24 | 136.08 |
| GRU | 7,933 | 156.29 | 99.15 | 141.51 |
| TCN | 7,933 | 160.74 | 85.43 | 120.46 |
| Transformer | 7,933 | 159.93 | 108.73 | 142.35 |
| KalmanNet | 7,933 | 156.01 | 87.00 | 135.31 |
| Small_GRU | 7,933 | 154.46 | 90.68 | 131.83 |
| Residual_TCN | 7,933 | 156.66 | 119.98 | 150.18 |

11모델 중 10모델에서 Fx RMSE가 가장 크다. ConvMixer만 Fz가 더 크다.
기존 validation 선택 힘 모델 CNN의 축별 결과는 다음과 같다.

| CNN 역할/구간 | 표본 수 | Fx RMSE (mN) | Fy RMSE (mN) | Fz RMSE (mN) |
|---|---:|---:|---:|---:|
| Train 전체 | 16,361 | 97.54 | 69.98 | 90.79 |
| Validation 전체 | 71,869 | 228.14 | 145.81 | 123.98 |
| Test 전체 | 7,933 | 158.56 | 80.26 | 120.15 |
| Test 유부하 | 3,536 | 225.79 | 93.80 | 158.21 |
| Test 무부하 | 3,225 | 63.51 | 66.17 | 72.40 |
| Test 판정보류 | 1,172 | 72.58 | 70.77 | 88.15 |

CNN test 유부하 Fx 실측 표준편차는206.93 mN, 예측 표준편차는43.89 mN으로
예측의 변화폭이 현저히 작다. 같은 구간의 Fy/Fz 실측 표준편차는229.64/297.22 mN이라
Fx 실측 변동이 가장 커서 절대 RMSE도 가장 큰 상황은 아니다.
유부하 Fx 편향(pred−GT)은+84.72 mN이고 편향을 제외한 오차 표준편차도209.29 mN이라
일정 offset만으로 전체 오차를 설명할 수 없다. 센서 감도·학습 분포·모델 구조 중
원인을 특정하거나 현재 test에 맞춰 수정하지 않았다. 기존 validation 모델 선택을 유지한다.

### 검증·실패 이력·후속 작업

- 첫 집계 시도는 load_state 문자열 열의 헤더까지 행으로 세어 유효성 검사에서 중단됐다.
  결과 파일 생성 전이었으며, 헤더를 분리한 뒤 다시 실행해 33개 모델 시트를 모두 집계했다.
- 세 원본 Excel hash가 기존 export_manifest 및 집계 전후에 일치했다.
  같은 역할의 11모델은 원본 행·GT·부하 상태가 모두 동일했다.
- Validation 11모델의 축별 RMSE·MAE를 기존 comparison.csv의 같은 대표 bundle과 대조했다.
  최대 차이는5.68e-14 mN이었다. 축별 제곱 RMSE의 평균과 pooled XYZ RMSE 제곱의 관계도 확인했다.
- 별도 test 계산과 11모델의 축별 RMSE·MAE가 일치했고 최대 차이는0 mN이었다.
  CNN의 부하 상태별 축 RMSE도 일치했다. 저장 CSV 22/11행의 숫자·중복·누락 검사와
  `git diff --check`가 통과했다. 이번 집계에는 학습 코드를 바꾸지 않아 전체 학습 테스트를 반복하지 않았다.
- 이번 요청의 미완료 작업은 없다. Fx 원인 규명을 위한 입력 반응·훈련 범위 분석이나
  모델 수정 실험은 이번 축별 지표 재집계와 구분되는 후속 작업이다.

재현 명령:

```bash
env_hrm_force_estimation/bin/python scripts/summarize_force_axes.py \
  --export-manifest results/train/20260929_130543_excel/export_manifest.json
```

## 15. 2026-09-29 — 직전 축별 RMSE 표의 평가 대상 확인

- 요청: 방금 제시한 결과가 testset으로 비교한 것인지 확인.
- 수행·검증: `results/predict/20260929_171211_axis_rmse/force_axis_metrics.csv`와
  `analysis.json`을 다시 읽었다. 표의 11모델 모두 dataset_role=test, 표본 수7,933이었다.
  대상은 `datasets/test/summary_test_18-2.csv`, `summary_test_18.csv` 두 독립 녹화이며
  둘 다 effective ID18 tip이다. Train/validation 축별 결과는 별도 CSV다.
  기존 validation 기준 모델 선택이 유지되었음을 확인했다.
- 미완료/다음: 없음. 새 학습·추론·평가 파일 변경은 수행하지 않았다.

## 16. 2026-09-29 — Segment ID 추정 성능 재요약

- 요청: segment_id 추정 능력을 다시 요약.
- 수행·검증: 주 학습 `comparison.csv`의 selected_for_test 두 행과 기존 test
  `metrics.json`의 overall/optimized_overall을 대조했다. 위치 모델은 masked CNN과
  class0 LSTM이며 모두 validation 선택 결과다. 정확 ID·구간·유무부하 지표가 일치했다.
  `independent_evaluation.py`를 읽어 conditional ID는 ID0을 제외한 argmax,
  class0 실제 ID는 ID0을 포함한 argmax임을 확인했다.

정확한 ID1–18 구별 성능은 낮다. Validation 유부하178,978행에서 ID별 재현율을
같은 가중치로 평균한 macro recall은 masked CNN3.42%, class0 LSTM6.64%다.
이 수치를 단순 행 가중 정확도나 무부하를 포함한 시스템 정확도와 혼동하지 않는다.

독립 test는 ID18 두 녹화이며 아래 비교는 **GT 유부하3,536행** 기준이다.
Class0는 ID0 오판을 오답에 포함한다. Masked는 조건부 위치 출력만 있으며 자체 무부하 검출은 없다.

| Test 유부하 위치 지표 | Masked CNN | Class0 LSTM |
|---|---:|---:|
| 정확히 ID18 출력 | 9.22% | 7.92% |
| 기본 끝단 구간16–18 인식 | 50.48% | 28.73% |
| Validation 탐색 상단 구간 인식 | 58.57% | 60.58% |

구간 인식은 해당 구간의 ID 확률 합으로 선택한다. Class0에서 전체 class argmax가0이면
구간 출력도 무부하로 처리하므로 유부하 구간 평가에서는 오답이다.
탐색 경계는 masked1–8/9–14/15–18, class0 1–8/9–12/13–18이다.
탐색 상단 폭이 서로 달라58.57%와60.58%만으로 구조나 무부하 처리 방식의 우열을 단정하지 않는다.
기존에 보고한 class0 ID18 10.27%, 기본 상단31.31%, 탐색 상단66.09%는
무부하 판정을 적용하지 않은 조건부 위치 진단이며 위 실제 출력 기준과 다르다.

Class0 LSTM의 test 부하 검출은 유부하 재현율82.47%(2,916/3,536),
무부하 재현율90.98%(2,934/3,225), 두 재현율 평균86.72%다.
판정보류1,172행은 위치·검출 평가에서 제외된다. 이는 무부하 범위로 파생한 라벨의 검출 성능이며
정확 ID 분류 성능이나 독립 계측 접촉 검증이 아니다.

탐색 경계의 validation 구간 행 가중 정확도75.04%/79.74%는 경계 선택에 사용한
동일 validation의 위치 진단이다. 구간·ID를 균형 있게 평균한 점수는64.05%/66.88%다.
독립 test에 ID18만 있으므로 이 실험만으로 전체18개 ID나 아래/중간/끝단3구간의
독립 성능을 검증했다고 주장할 수 없다. 현재는 정확 ID보다 넓은 구간 구분이 나은 수준이며,
정확 ID를 안정적으로 알아내는 수준에는 도달하지 못했다.

- 미완료/다음: 이번 요약 요청은 완료했다. 새 학습·추론·모델/구간 선택 변경 및 결과 파일 변경은 없다.
  전체 ID의 독립 test 검증은 기존 후속 과제로 남는다.

## 17. 2026-09-29 — ID18만 사용한 별도 학습·test 비교 (완료)

- 요청: segment_id18만 학습·test하고 ID1–17은 학습에서 제외한 결과 확인.
  기존 힘 분기는 이미 ID18 전용이었고 위치 분기는 ID1–18 전체였음을 설명했다.
  앞선 유무부하 검출 수치는 class0 LSTM의 결과이며 masked CNN 자체에는 검출기가 없음을 설명했다.
- 범위 질문을 제시한 뒤 별도 답변이 없는 동안 데이터 준비를 검증했다.
  이후 ID18 전용 힘 추정 + class0 무부하/ID18 이진 분류 비교로 해석하고 진행한다고 알렸다.
  ID18 단일 class의 masked 위치 출력은 상수18이므로 유의미한 위치 정확도 비교에서 제외한다.
- 데이터 준비: active_ids만 바꾸면 다른 ID의 무부하 행과 위치 scaler가 남는 현 구현을 확인했다.
  기존 audit의 정확한 hash로 ID1–17 녹화 전체를 제외해, 분할/정규화/시간창 학습 전에
  ID18 CSV5개만 남겼다. 원본은 수정·이동하지 않았다.
  Train2개·validation1개·test2개의 경로/hash가 이전 ID18 분할과 정확히 일치했다.
  유효 시점은 각각16,361/71,869/7,933개다. 기본 입력26개와 무부하 교정·학습 설정은 유지한다.
- 새 실행: `results/train/20260929_181303_id18_only`.
  실험 설정은 `.runtime/20260929_181303_id18_only/config_requested.yaml`이며
  학습 실행 폴더의 resolved 설정에도 저장한다. Class0만 사용해 힘11×위치11=121조합을
  새로 학습한다. 기존242조합 결과를 덮어쓰지 않는다.
- 진행 상태: **121조합·242분기 학습 및 test 평가 완료**. 원본 ID18 분할과 무부하 교정은
  이전 실험과 동일하다. 단일ID 조건부 정확도100%를 접촉 위치 식별 성능으로 주장하지 않는다.
  이번 실험에서 의미 있는 위치 지표는 ID0/18 검출이다.

### 모델 선택과 test 결과

단일ID에서는 conditional ID macro recall이 항상1이므로 모델 선택 지표로 쓸 수 없다.
Test 평가 전에 validation 힘 RMSE 최저(기존 수치 동률 허용1e-3 mN),
validation 부하 balanced accuracy 최고, CE 최저 순으로 선택한다고 정했다.
`predict.py --location-selection-metric load_balanced_accuracy`를 추가했고 class0 전용으로 제한했다.
기존 전체ID 기본 선택 방식은 그대로 유지한다. 선택된 bundle은 힘CNN/위치LSTM이다.
기존 bundle을 가져오거나 가중치를 조합하지 않고 새121조합 중 해당 bundle 그대로 사용했다.

| 선택 모델 지표 | Validation | Test |
|---|---:|---:|
| CNN Fx RMSE (mN) | 228.14 | 158.56 |
| CNN Fy RMSE (mN) | 145.81 | 80.26 |
| CNN Fz RMSE (mN) | 123.98 | 120.15 |
| CNN XYZ RMSE (mN) | 171.93 | 123.85 |
| LSTM 유무부하 balanced accuracy | 77.07% | 81.42% |

Test 유부하3,536행 중 ID18로 검출한 행은2,815개(79.61%), 놓친 행은721개다.
무부하3,225행 중 ID0으로 검출한 행은2,684개(83.22%), 오검출은541개다.
전체 확정 라벨6,761행의 ID0/18 정확도는81.33%다. 판정보류1,172행은 검출 평가에서 제외했다.
이는 접촉 위치가18로 제한된 상황에서의 유무부하 검출이고, ID1–18 중 위치를 식별한 정확도가 아니다.

| LSTM test 부하 검출 | 기존 전체ID 학습 | 새 ID18 전용 학습 |
|---|---:|---:|
| 유부하 재현율 | 82.47% | 79.61% |
| 무부하 재현율 | 90.98% | 83.22% |
| 두 재현율 평균 | 86.72% | 81.42% |

이번 비교에서 ID18 전용의 balanced accuracy는5.30%p 낮았다.
접촉 class 수·학습 녹화·위치 scaler가 함께 바뀐 비교이므로 차이의 원인을 한 요인으로 단정하지 않는다.
힘 분기는 이미 ID18만 학습하던 구조였고, 새 force scaler가 이전 것과 정확히 일치했다.
새 location scaler도 ID18 train2개만 사용해 force scaler와 정확히 일치했다.
힘 성능은 기존 결과와 표시 정밀도에서 같다.

고정 파트너 대표 bundle의 test 검출 결과는 다음과 같다. LSTM 선택은 위 validation 규칙으로 고정했으며,
이 표에서 test 점수가 높다는 이유로 모델을 바꾸지 않았다.

| ID0/18 모델 | 유부하 재현율 | 무부하 재현율 | Balanced accuracy |
|---|---:|---:|---:|
| MLP | 88.97% | 70.05% | 79.51% |
| CNN | 90.87% | 67.63% | 79.25% |
| ConvMixer | 79.52% | 88.43% | 83.98% |
| ResNet | 93.58% | 50.08% | 71.83% |
| LSTM | 79.61% | 83.22% | 81.42% |
| GRU | 63.09% | 41.89% | 52.49% |
| TCN | 92.85% | 47.60% | 70.22% |
| Transformer | 85.21% | 26.26% | 55.74% |
| KalmanNet | 80.12% | 83.47% | 81.80% |
| Small_GRU | 58.54% | 42.67% | 50.60% |
| Residual_TCN | 90.50% | 60.96% | 75.73% |

### 산출물·검증·남은 작업

- [학습 실행](../results/train/20260929_181303_id18_only/)에121조합 비교표·bundle·이력·설정·원본 목록을 보존했다.
- [Test 실행](../results/predict/20260929_181303_id18_only/)에 선택 bundle의 predictions.csv/metrics.json을 저장했다.
- 각 실행의 `summary/force_metrics.csv`, `summary/contact_detection_metrics.csv`에
  모델별 지표를 정리했다. Train 폴더는 train/validation 각각11행, predict 폴더는 test11행이다.
  검출 비율 열은0–1, 힘 지표 열은mN이다. `validation_selected_architecture`는 선택된 구조 표시이며,
  대표 Excel은 힘 class0/force_MODEL/location_mlp, 검출 class0/force_mlp/location_MODEL을 사용한다.
- `excel/`에는 모델별 정답/예측 시트를 저장했다. Train/validation 각각 힘1개+ID class0 1개,
  test 힘1개+ID class0 1개로 총6개 workbook·66개 모델 시트다.
  새 workbook은 처음 열면 MLP 데이터 시트가 보이도록 활성화했다. 기존 Excel은 변경하지 않았다.
- 단일 class0 모드를 지원하도록 exporter를 일반화했고, 실제66개 시트의 유한값·헤더·행 대응·GT·hash를
  다시 읽어 확인했다. ID 출력은0/18만 있으며 train13,332/validation64,212/test6,761개의 확정 라벨 행이다.
  각 모델의 validation force·검출 지표를 같은 bundle의 comparison.csv와 대조해 최대 차이1.14e-13이었다.
- Test 선택 결과를 predictions.csv에서 재집계했다. ID 혼동행렬이 정확히 일치했다.
  처음 힘 RMSE 검산 허용오차1e-9 mN은 CSV 숫자 직렬화/재읽기 차이1.27e-7 mN으로 실패했다.
  차이를 기록하고 허용오차1e-6 mN으로 확인했다. 학습·Excel 값이나 정답을 수정하지 않았다.
- Binary 선택이 형식적 ID100%나 test 지표로 고르지 않는 회귀검증을 추가했고
  전체 **156개 테스트(2.786초)**가 통과했다. 기존 전체ID 선택 테스트도 통과했다.
  5개 원본 CSV hash·기존 ID18 분할·동일 무부하 교정을 최종 확인했다.
  `verification.json`, 실제 실행/테스트 로그, 코드 snapshot을 새 실행 폴더에 저장했다.
- 이번 요청의 미완료 작업은 없다. ID18 전용 모델의 ID1–17 접촉 구별·거절 능력은 학습/검증하지 않았고,
  기존 전체ID 모델을 대체하도록 배포하거나 제어 코드에 연결하지 않았다.

재현 예시(새 output 경로를 지정한다):

```bash
bash scripts/hrm_python.sh train.py \
  --config results/train/20260929_181303_id18_only/config_requested.yaml --output results/train/새날짜_id18_only
bash scripts/hrm_python.sh predict.py --train-dir results/train/새날짜_id18_only \
  --location-selection-metric load_balanced_accuracy --output results/predict/새날짜_id18_only
```

## 18. 2026-09-29 — 유무부하 힘 범위 설명 및 10%·20% 확대 민감도

- 요청: 검출률 계산에 쓰인 힘 범위의 설정 방법과 범위를 조금 넓히는 방안 문의.
- 수행: 현재 ID18 실험의 calibration.json과 `calibrate_no_load`/`load_states` 구현을 대조했다.
  원본 무부하 기록2 및 ID18 train/validation만 읽고, 중심은 고정한 채 off/on 두 경계의 반폭을
  각각1.0/1.1/1.2배로 바꾼 복사 배열의 라벨 변화를 계산했다. Test는 이번 분석에서 읽지 않았다.
  모델 추론·재학습·기존 라벨/설정/결과 수정은 하지 않았다.

현재 기준은 `aidin_FT_sensor_validation_2/csv/summary.csv`의 Kalman aligned hrm_base XYZ다.
앞70%(1,957행)에서 축별 median 중심과 표준편차를 구하고,
`max(|F_axis-center_axis|/std_axis)`의95%/99.5% 경험적 분위수로 off/on을 정했다.
이는 각 축95% 신뢰구간이나 무접촉 물리 보증이 아니다. 뒤840행은 같은 녹화의 시간 holdout이다.

| 축 | 현재 무부하 범위 (mN) | 현재 유부하 경계 상자 (mN) |
|---|---:|---:|
| Fx | -186.97 ~ 57.78 | -224.57 ~ 95.38 |
| Fy | -96.91 ~ 134.15 | -132.41 ~ 169.65 |
| Fz | -259.05 ~ 92.00 | -312.98 ~ 145.93 |

세 축이 모두 무부하 범위 안이면 ID0 정답이다. 한 축이라도 더 넓은 on 경계에 도달하거나
벗어나면 유부하 정답이며, 나머지는 판정보류로 위치 loss/검출 평가에서 제외한다.
중심은[-64.59,+18.62,-83.53]mN이다. 0 중심 범위가 아니며 이 중심을 힘 회귀 정답에서 빼지 않는다.
이는 **실측 F/T로 정답 라벨을 만드는 규칙**이다. 현재 ID18 class0 모델의 실제 예측은
신경망의 p0/p18 중 큰 확률(동률은0)을 선택하므로, F/T 범위 숫자만 바꾸어도 저장 모델의
출력이 바로 바뀌는 것은 아니다. 현재 검출률은 그 예측과 기존 범위의 정답을 비교한 값이다.

### 폭을 넓혔을 때의 실제 라벨 변화

| 반폭 배율 | 무부하 holdout840행 중 무부하 라벨 | 유부하 오라벨 | ID18 train 기존 유부하→판정보류 |
|---|---:|---:|---:|
| 현재1.0 | 815행(97.02%) | 2행(0.238%) | 0행 |
| 1.1(+10%) | 832행(99.05%) | 1행(0.119%) | 1,024행 |
| 1.2(+20%) | 835행(99.40%) | 0행(0.000%) | 1,770행 |

표는 힘 범위 규칙의 라벨 포함률이며 **LSTM의 무부하 재현율83.22%를 재계산한 표가 아니다.**
원래 train 유부하 라벨은6,892행이므로10% 확대 시14.86%,20% 확대 시25.68%가 판정보류로 빠진다.
Validation에서는 기존55,963개 유부하 라벨 중 각각3,410/6,617행이 판정보류로 이동했다.
이번10%/20% 확대에서 기존 확정 유부하가 곧바로 무부하로 이동한 행은0개이며,
기존 판정보류에서 무부하로 이동한 train 행은각1,039/2,081개다.
실제 작은 접촉이 그 판정보류 영역에 있을 수 있으므로 무부하 포함률 상승만으로
실제 접촉 검출 성능 향상을 단정할 수 없다. 840행에서0회라는 값도 미래 오경보0 보장은 아니다.

10% 확대는 비교 후보로 검토할 수 있으나 아직 새 기준을 선택하지 않았다.
적용을 비교할 때는 정답 생성 기준과 모델을 함께 고정해 학습/validation에서 확인해야 하며,
test 정답만 넓혀 점수가 올라간 것을 모델 개선으로 해석하지 않는다.
연속 힘 회귀의 실측 정답·예측값은 범위 확대의 직접 변경 대상이 아니므로 전체 힘 RMSE도 그대로다.

- 산출물: [range_sensitivity.csv](../results/train/20260929_182936_no_load_range_analysis/range_sensitivity.csv),
  같은 폴더 analysis.json에 정확한1.0/1.1/1.2배 경계·방법·원본 hash·전체 라벨 수를 기록했다.
- 검증: 현재 배율1.0의 무부하 fit/holdout 포함률이 기존 calibration과 일치했고,
  ID18 train/validation 시점의 기존 라벨이 loader 결과와 전부 일치했다.
  확대 시 무부하 라벨 수 비감소·유부하 라벨 수 비증가를 확인했고, 읽은 원본4개 hash가 유지됐다.
- 미완료/다음: 범위 설명과 민감도 분석은 완료. 확대 기준의 모델 재학습이나 최종 기준 변경은 수행하지 않았다.

## 19. 2026-09-29 — 평균 offset 보정 및 무부하 경계10% 확대 적용

### 요청과 적용 범위

- 요청: 무부하 기록의 평균이0이 아니므로 offset으로0을 맞춘 뒤 범위/확률을 비교하고,
  무부하 범위를10% 늘리기로 함. 이전 문맥의 범위 확대 요청으로 해석했고 녹화 길이/행 수는 늘리지 않았다.
- 수행: 무부하 기록2의 기존 fit 앞70%(1,957개 유효 행) 산술평균을 offset으로 정했다.
  `F_corrected = F_recorded - mean_fit`으로 판정용 좌표를 만들고, corrected 힘의
  max-axis 정규화 score에95%/99.5% 분위수를 적용한 뒤 두 경계 반폭을1.1배 했다.
  원본 CSV·기존 model bundle·과거 calibration·힘 회귀 정답은 변경하지 않았다.
- 설정: `configs/train.yaml`의 `calibration.center_method: mean`, `range_multiplier: 1.1`에 반영했다.
  이번 ID18 실험 범위를 유지한 재현용 설정과 데이터 준비 결과는
  [20260929_185223_mean_zero_range110](../results/train/20260929_185223_mean_zero_range110/)에 저장했다.
  다른 ID의 녹화 제외·기존 ID18 train/validation/test 파일과 hash가 유지됐다.

### 평균0 좌표의 범위와 포함률

빼는 평균은 Fx **-67.36210**, Fy **+19.59298**, Fz **-85.57272 mN**이다.
따라서 corrected Fx=기록 Fx+67.36210, Fy=기록 Fy−19.59298, Fz=기록 Fz+85.57272 mN이다.
Offset은 fit 구간만 사용했다. Fit 구간 corrected 평균은 수치 오차 수준0이고,
후반840행의 corrected 평균은[+5.45476,-2.47038,-18.43771]mN이다.
전체2,797행의 corrected 평균도[+1.63818,-0.74191,-5.53724]mN으로,
확인 구간까지 별도로 다시 영점 조정해0으로 만든 것은 아니다.

아래 모든 경계는 **평균 offset을 한 번 뺀 corrected 힘**에 적용하는 대칭 범위다.

| 축 | 평균 중심 기본 무부하 범위 (mN) | 적용:10% 확대 무부하 범위 (mN) | 적용:10% 확대 유부하 경계 (mN) |
|---|---:|---:|---:|
| Fx | ±122.11 | ±134.33 | ±176.51 |
| Fy | ±115.29 | ±126.81 | ±166.64 |
| Fz | ±175.15 | ±192.67 | ±253.17 |

세 축 모두 무부하 범위 안이면 ID0, 한 축이라도 on 경계에 도달하거나 넘으면 유부하,
나머지는 판정보류다. 저장 calibration의 `center_N`/`offset_to_subtract_N`은 기록 좌표의 offset이고,
`corrected_off/on_lower/upper_N`은0 중심 경계다. `load_states`는 기록 좌표의 힘을 받아
내부에서 center를 한 번 빼므로 이미 보정한 힘에 같은 offset을 중복 적용하지 않는다.

| 기준 | 무부하 holdout840행 중 무부하 | 판정보류 | 유부하 오라벨 |
|---|---:|---:|---:|
| 기존 median 중심 | 815 (97.02%) | 23 (2.74%) | 2 (0.238%) |
| 평균 중심, 확대 전 | 816 (97.14%) | 22 (2.62%) | 2 (0.238%) |
| 평균 중심,10% 확대 적용 | 832 (99.05%) | 7 (0.83%) | 1 (0.119%) |

단순 좌표 평행이동만으로는 데이터 분포 폭이나 기존 판정이 변하지 않는다.
실제 force와 기존 bounds/center를 같은 평균만큼 함께 옮겼을 때 모든 기존 라벨이 유지됨을 검증했다.
위 첫 행과 둘째 행의 차이는 기존 median 중심을 mean 중심으로 바꾸고 분위수를 다시 계산한 영향이며,
둘째 행과 셋째 행의 차이는 반폭10% 확대한 영향이다.
99.05%는 **알려진 무부하 기록의 포함률**이며 모델 검출률·posterior 확률·미래 무접촉 보증이 아니다.

ID18 train16,361개 유효 시점의 새 라벨은 무부하7,295/보류3,146/유부하5,920이다.
Validation71,869개는 무부하10,230/보류8,751/유부하52,888이다.
기존 median 기준 유부하 중 train972개·validation3,075개가 판정보류로 이동했다.
따라서 확대된 기준이 작은 접촉에 미치는 영향과 새 모델의 검출 성능은 구분해 평가해야 한다.

### 검증·산출물·완료 상태

- [bounds_comparison.csv](../results/train/20260929_185223_mean_zero_range110/bounds_comparison.csv)에
  기존/평균 중심/평균 중심+10%의 offset과 기록/보정 좌표 경계를 저장했다.
  [coverage_comparison.csv](../results/train/20260929_185223_mean_zero_range110/coverage_comparison.csv)에
  무부하 fit/holdout 및 ID18 train/validation 포함률을 저장했다.
- 같은 폴더 `applied_mean_zero_plus10_calibration.json`과 `prepared_data/`에
  적용 교정·원본 목록·고정 분할·해결된 설정을 저장했다. 기본 설정에서 구한 교정이
  ID18 준비 설정의 교정과 정확히 일치했다. Test는 분할/원본 검증 단계에서만 읽었고,
  offset·경계 결정이나 포함률 비교에 사용하지 않았다.
- 평균0·경계1.1배·동일 좌표계 라벨 동치·후반 데이터가 offset/경계 fit에 영향을 주지 않음·
  힘 회귀 정답 보존·잘못된 옵션 거절을 검사하는 테스트2개를 추가했다.
  전체 **158개 테스트(2.814초)**가 통과했다. 옵션 없는 옛 설정은 median/1.0으로 유지했다.
- 초기 부가 JSON 저장은 NumPy 배열을 기본 JSON encoder가 처리하지 못해 중단됐다.
  이미 성공한 계산/준비 결과를 사용하고 저장소의 배열 지원 JSON 저장 함수로 마무리했다.
  입력·기준 값·모델을 오류 해결 과정에서 변경하지 않았다.
- 최종 원본6개(무부하1+ID18 실험5) hash와 기존 파일 분할을 확인했다.
  Train/validation 힘 회귀 정답과 유효 시간창이 이전과 동일했고, 설정/기록/CSV 간 값이 일치했다.
  `analysis.json`과 실제 테스트 로그를 보존했다.
- 이번 요청의 평균 보정·범위 비교·10% 확대 설정 적용은 완료했다.
  모델 재학습/새 모델 검출률은 아직 미실행이며, 기존81.42% 검출률은 이전 라벨 기준 결과로 유지한다.

## 20. 2026-09-29 — 새 무부하 경계와 ID1–18 힘 학습의 영향 질문

- 요청: 평균 offset 보정·10% 확대 경계로 ID1–18 힘 추정을 학습하면 결과가 달라지는지 설명.
- 확인: 현재 `configs/train.yaml`은 `force_scope: tip`이다. 기존 전체 ID 비교에서도
  위치 모델만 ID1–18을 학습했고 힘 모델은 ID18만 학습했다.
  `independent_engine.py`의 시간창 선택·정답·eligible 조건·회귀 loss를 확인했다.
  힘 모델은 유효한 실측 XYZ를 무부하/판정보류까지 사용하며 부하 라벨로 회귀를 마스킹하거나
  정답을0으로 바꾸지 않는다. 따라서 경계만 바꾸면 힘 학습 데이터/정답은 그대로이며,
  위치 학습 라벨과 유부하·무부하별 평가 집계는 달라질 수 있다.
- ID1–18 녹화를 힘 학습에 실제 포함하려면 `force_scope: all_single_contact`가 필요하다.
  `active_ids`만 변경하는 것은 힘 학습 범위 확대가 아니다. 전체 ID를 포함하면 학습 자료와
  train 정규화가 바뀌므로 힘 결과도 달라질 수 있으나, 끝단/Fx 개선을 보장하지 않는다.
  입력 변화가 작은 초기 ID의 구분 한계가 있으며, 이때 목표는 각 단일 접촉 위치에 가한 힘이지
  body 접촉 중 별도 끝단 힘을 측정한 정답이 아니다.
- 다음 비교 제안: 새 무부하 기준과 기존 녹화 역할을 고정하고 ID18 전용/전체 ID 힘 모델을
  공통 ID18 validation·test의 축별 RMSE/MAE로 비교한다. 전체 ID 모델의 body 성능은
  ID별/구간별 validation으로 따로 평가한다. 현재 test는 ID18뿐이므로 독립 body 성능은 확인할 수 없다.
- 수행 범위: 코드와 설정 확인 및 설명 기록만 완료. 이번 질문으로 설정을 변경하거나
  재학습하지 않았으며 새 성능 수치는 없다. 실행 코드 변경이 없어 테스트는 재실행하지 않았다.

## 21. 2026-09-29 — ID 성능 질문 의도 정정과 두 힘 모델 비교 범위 확인

- 사용자 정정: 힘은 유부하/무부하와 무관하게 연속 회귀하며, 새 경계로 좋아지는지 확인하려던
  대상은 ID 구분 성능이었다. ID18 전용/ID1–18 전체 힘 모델을 별도 학습하자는 제안인지 확인했다.
- 설명: 경계 확대는 입력 변화가 작은 무부하 근처 표본에 실험 ID를 강제하는 부담을 줄일 수 있어
  ID 성능 개선 가능성이 있으나 실측 개선은 아직 모른다. 작은 실제 접촉이 판정보류 또는
  무부하로 분류되는 효과도 있어, 정확 ID·세 구간 성능과 무부하/유부하 검출을 따로 평가해야 한다.
  기존/신규 위치 모델은 공통 평가 행과 동일한 평가 라벨 기준으로 비교하고, 경계 변경으로
  평가에서 빠지거나 라벨이 바뀐 행 수를 함께 보고한다. 쉬운 표본만 남은 효과를 모델 개선으로 단정하지 않는다.
- 힘 모델 비교 제안은 ID18 자료만 학습한 모델과 ID1–18 자료를 학습한 모델을 각각 두는 것이다.
  두 경우 모두 위치 모델의 범위는 ID1–18이다. ID18 전용 힘 모델이라는 말은 위치까지 ID18만
  학습한다는 뜻이 아니다. 독립 분기이므로 힘 모델 범위 확대가 위치 모델 성능을 직접 높이지 않는다.
  기존 17절의 ID0/18 이진 위치 실험과 이번 전체 위치 비교를 구별한다.
- 수행/검증: 현재 요약과20절을 확인하고 사용자 의도와 비교 범위를 기록했다.
  이번 확인 질문에 대해 재학습·설정 변경·새 수치 산출은 하지 않았다. 문서만 변경했다.

## 22. 2026-09-29 — 끝단 힘 최우선·body 구간 감지 모드와 과거80 mN 확인

- 요청: 끝단 ID18 힘 추정 정확도가 최우선이며 전용 모델이 반드시 필요함을 재확인.
  끝단 힘 제어와 선택적으로 활성화하는 body contact 감지 모드를 구분하고,
  body 구간 인식은 약90% 이상을 목표로 한다. 과거 약80 mN과 현재100 mN대 차이에 의문을 제기했다.
- 확인 근거: `archive/legacy_materials_20260928.tar.gz` 안의 `CODEX_HANDOFF.md` 및
  `docs/WORK_LOG.md`를 읽었으며 원본을 복원/수정하지 않았다. 과거 front 추가학습 기록에는
  test 최저 ResNet XYZ RMSE83.43 mN(Fx108.97/Fy60.81/Fz72.86), validation 선택 LSTM
  XYZ92.65 mN(Fx119.63/Fy69.70/Fz81.14)이 있다. 사용자가 기억한80 mN이 어느 값인지 확정하지 않는다.
  당시 새 test는2,572행이며 같은 녹화 앞/뒤 validation과 부모 가중치/scaler 기반 추가학습이었다.
  현재는 파일 단위 validation·새 초기화 학습이며 선택 CNN test7,933행의 XYZ RMSE123.85 mN,
  Fx158.56/Fy80.26/Fz120.15 mN, XYZ MAE81.28 mN이다. 현재 CSV와 기록의 수치를 대조했다.
- 해석: test 최저모델과 validation 선택모델, 평가 녹화/표본, 학습·분할 조건이 다르므로
  83.43→123.85 mN을 같은 조건에서의 성능 악화로 단정하거나 원인을 특정하지 않는다.
  당시에도 ResNet의 Fx는108.97 mN으로 모든 축90 mN 이하를 달성한 것은 아니다.
  현재 MAE81.28와 RMSE123.85도 구별한다. 과거 결과 원본/체크포인트는 현재 results 목록에서
  확인되지 않아 이번에는 보존 문서 확인이며 과거 예측 재계산은 수행하지 않았다.
- 방향: 필수 모델은 ID18 전용 힘 모델과 별도 위치/무부하 모델이다. 전체 ID 힘 모델은
  현재 우선 작업에서 제외하고 이전 비교 제안으로 보존한다. Body 모드의 출력은 접촉 여부·구간·
  ID 확률이며, 모드 전환/제어 연결/접촉 시 제어 동작은 아직 구현하거나 확정하지 않았다.
  구간90%는 목표이지 달성 수치가 아니다. 구간별 재현율과 무부하 오경보·접촉 미검출을 함께
  확인해야 하며 현재 ID18-only test로 body 전체 독립 성능을 입증할 수 없다.
- 수행/검증/다음: 과거 기록과 현재 CSV를 읽고 현재 요약·작업 규칙을 갱신했다.
  학습/설정/제어 코드는 변경하지 않았고 새 학습·테스트는 실행하지 않았다.
  끝단 개선의 후속 비교는 동일 평가 데이터와 지표로 진행하며 과거 모델 원본 가용성을 먼저 확인한다.

## 23. 2026-09-29 — 과거 추가학습의 의미 확인

- 요청: 앞서 언급한 과거 추가학습이 무엇인지 확인.
- 확인: 보존 archive의 HANDOFF(2026-09-27 완료 항목), WORK_LOG, 당시
  `configs/tip_front_finetune_20260927.json`을 대조했다. 기록상9월26일 학습한 기존 tip11종의
  가중치를 출발점으로9월27일 신규 ID18 front_1/2/3을 각180epoch 학습한 fine-tuning이다.
  부모 정규화 통계는 고정하고 optimizer는 새로 시작했으며 front_testset_1은 학습에서 제외했다.
  같은 새 test에서 ResNet91.39→83.43 mN, validation 선택 LSTM98.72→92.65 mN이었다.
- 구분: 현재9월28일 전체 조합과9월29일 ID18 전용 실험은 각각 새 초기화 학습이며,
  위 과거 checkpoint를 이어서 학습한 결과가 아니다. 과거 실행 사실의 근거는 보존 문서와
  설정이며 이 세션에서 과거 checkpoint/예측을 직접 재검증한 것은 아니다.
- 수행/검증/미완료: 기록과 설정의 일치 확인 및 용어 설명만 수행했다. 코드·학습 설정 변경이나
  새 학습은 없고 테스트는 재실행하지 않았다. 과거/현재 오차 차이의 원인은 아직 분리 검증하지 않았다.

## 24. 2026-09-29 — static 제외 요청, 끝단 힘11종 학습·동일 test 평가

### 요청과 데이터 범위

- 사용자 요청: summary_1부터 summary_18-2까지의 CSV로 static을 제외하고 학습·test.
  목록 확인 결과 동적 CSV30개(ID1–6 각1개, ID7–18 각2개), static18개가 있다.
  원본은 이동/수정하지 않았으며 이번 설정의 정확한 hash 제외 목록으로 static을 차단한다.
- ID1–6은 각1녹화여서 기존 whole-CSV per-ID 분할은 오류로 중단된다. 무단 시간분할 대신
  사용자에게 (1)ID1–6 학습 전용/ID7–18 validation, (2)이번에는 끝단만,
  (3)ID1–6에 한해 시간분할 중 선택을 질문했다. 답변 전에는 전체 ID 위치 학습을 시작하지 않았다.
- 독립적으로 진행 가능한 최우선 ID18 힘11종은 학습·평가를 완료했다.
  train `summary_18.csv` 9,485개 창, validation `summary_18-2.csv` 6,876개 창,
  test 기존 두 파일7,933개 창이다. ID18의 seed42 녹화 단위 분할이며 test 역할/hash는 이전과 동일하다.
  summary_18-2의 raw ID1→effective18은 기존의 정확한 hash 한정 확인 계약을 유지한다.

### 학습과 모델 선택

- 실험 설정: [config_requested.yaml](../results/train/20260929_195732_no_static_tip/config_requested.yaml).
  26입력·30행 창·Kalman 실측 힘·단위·부호·회귀 loss·정규화·60epoch 상한/patience10 등 기존 설정을 유지했다.
  평균 offset 및1.1배 경계는 위치 라벨에만 적용하며 회귀 정답/영점은 바꾸지 않는다.
- 힘11종을 새 가중치로 각각 학습했다. 기존 bundle 저장/내보내기 경로를 사용하기 위해
  고정 MLP ID0/18 보조 분기를 함께 학습한11조합이다. 이 보조 분기는 전체 ID 위치 실험이 아니며
  사용자 목표인 body 구간 성능으로 보고하지 않는다. 힘/위치는 독립 파라미터다.
- Validation XYZ RMSE 최저 GRU(epoch13,147.77231 mN)를 test 전에 선택했다.
  힘 선택 후 보조 위치 동률 기준은 load_balanced_accuracy이며 test로 대표 모델을 바꾸지 않았다.
  기존242 전체 조합을 완료했다고 주장하지 않는다. 전체 ID 위치/조합 범위는 질문 답변 후 진행한다.

### Test 결과 (mN)

| 모델 | XYZ RMSE | Fx RMSE | Fy RMSE | Fz RMSE | XYZ MAE |
|---|---:|---:|---:|---:|---:|
| MLP | 170.48 | 157.94 | 116.73 | 220.49 | 112.16 |
| CNN | 155.37 | 168.51 | 104.81 | 181.76 | 104.86 |
| ConvMixer | 183.51 | 158.66 | 121.97 | 246.95 | 115.33 |
| ResNet | 171.51 | 160.14 | 112.48 | 223.49 | 109.81 |
| LSTM | 201.09 | 157.17 | 133.84 | 280.52 | 127.39 |
| **GRU (validation 선택)** | **147.88** | **160.50** | **97.55** | **174.15** | **96.98** |
| TCN | 161.52 | 156.16 | 125.33 | 195.38 | 105.96 |
| Transformer | 159.25 | 157.24 | 102.39 | 202.18 | 102.70 |
| KalmanNet | 178.28 | 157.22 | 122.94 | 235.62 | 112.47 |
| Small_GRU | 148.29 | 159.17 | 96.90 | 176.77 | 97.73 |
| Residual_TCN | 187.98 | 157.46 | 127.92 | 254.66 | 121.99 |

기존 선택 CNN test123.85 mN보다 이번 선택 GRU147.88 mN이 높다. 같은 CNN도155.37 mN이다.
다만 기존 끝단 학습은 이미 dynamic 두 파일만 사용했고 static은 validation에만 있었다.
이번에는 summary_18-2가 train에서 validation으로 이동하여 train창16,361→9,485로 줄었다.
학습 데이터 양과 validation/epoch 선택이 함께 달라졌으므로 static 포함이 성능을 좋게/나쁘게
만든다는 인과 결론을 내리지 않는다. 새 무부하 경계도 힘 학습의 표본/정답을 마스킹하지 않는다.

### 산출물·검증·남은 작업

- [학습/validation 힘 지표](../results/train/20260929_195732_no_static_tip/force_metrics.csv),
  [test 힘 지표](../results/predict/20260929_195732_no_static_tip/force_metrics.csv)에 축별 RMSE/MAE와 XYZ를 저장했다.
- 모델별 시트의 실측/예측 Excel은 학습 폴더 `excel/train/`, `excel/validation/`,
  [test Excel](../results/predict/20260929_195732_no_static_tip/excel/force_estimation_all_models.xlsx)에 있다.
  고정 보조 MLP의 ID Excel도 생성됐지만 이것은 body 위치 비교 결과가 아니다.
- 힘33시트(train/validation/test×11종)의 동일 역할 내 원본 행·정답·부하 라벨 일치,
  중복 행 없음, 유한값, 저장 Excel에서 재계산한 validation지표와 comparison 일치,
  선택 모델 test 지표와 metrics.json 일치를 검사했다. 최대 validation 차이는5.68e-14 mN이다.
  원본 hash 불변과 기존 test 목록/hash 일치, 모든 입력의 static 제외도 확인했다.
- 설정·분할·교정·환경·코드 snapshot·학습/예측/내보내기 로그·verification.json을 실행 폴더에 보존했다.
  실행 코드는 수정하지 않았고 기존 전체 단위 테스트는 재실행하지 않았다. 이번 산출물 검증을 수행했다.
- 미완료: 전체 ID 위치 학습은 ID1–6의 분할 방식 답변 대기. 끝단11종 결과는 완료이며
  이번 실험을 summary_1–18 전체 위치 학습 완료로 표현하지 않는다.

## 25. 2026-09-29 — static 포함 설정 결과 해석 확인

- 요청: static도 포함한 쪽의 결과가 더 좋았는지 확인.
- 답변: 동일 test의 validation 선택 모델 기준으로 기존123.85 mN(CNN)이
  static 제외147.88 mN(GRU)보다 낮다. 따라서 기존 실험 설정의 결과가 더 좋았다는 해석은 맞다.
  그러나 기존 끝단 힘 모델에서 static은 validation 전용이었다. 기존에는 dynamic ID18 두 CSV가
  학습에 들어갔고, 제외 실험에서는 하나를 validation으로 옮겼다. Static을 학습에 추가해서
  개선됐다는 뜻이나 static 자체의 인과 효과를 입증한 결과는 아니다.
- 수행/검증:24절의 학습 역할·동일 test 수치와 대조하여 설명을 기록했다.
  새 학습·설정 변경·코드 변경은 없으며 추가 검증 실행은 하지 않았다.

## 26. 2026-10-02 — 기존 데이터 분할과 hrm_bundle.pt 의미 확인

- 요청: static 포함 개발 데이터로 학습하고 별도 test18/18-2를 평가하는지,
  모델 조합 폴더의 hrm_bundle.pt가 네트워크 파일인지와 bundle 명칭의 의미 확인.
- 검증: 주 실행20260928_221428의 split_manifest.json을 확인했다. 전체 train29개,
  validation18개, test2개이며 static은 train12개/validation5개에 분포한다.
  끝단 힘 분기는 train summary_18.csv와 summary_18-2.csv, validation static ID18이다.
  test는 datasets/test/summary_test_18.csv 및 summary_test_18-2.csv로 학습/정규화에 넣지 않았다.
  사용자의 현재 설명은 기존 실험 구성 확인으로 해석했으며 새 학습 지시로 확대하지 않았다.
- 실제 models/class0__force_cnn__location_lstm/hrm_bundle.pt를 weights_only=True로 읽었다.
  state_dict의 두 접두사는 force_net/location_net이며 각각 CNN 힘·LSTM 위치 가중치다.
  config, 각 분기 scalers, feature_columns, calibration, 입력26/시간창30, 모델 구조 파라미터,
  데이터 감사·분할·학습/validation 지표가 함께 들어 있다.
- Bundle은 두 독립 네트워크와 추론 재현에 필요한 정보를 묶은 checkpoint라는 뜻이다.
  하나의 공유 네트워크로 학습됐다는 의미가 아니며 모든 모델11종이 한 파일에 든 것도 아니다.
  restore_bundle은 이 메타데이터로 모델을 만들고 가중치를 복원한다. pt 단독 실행 파일은 아니므로
  추론에는 해당 모델 정의/로더 코드도 필요하다. optimizer 상태 복원용 resume 파일은 아니다.
- 수행: 현재 요약/최신 기록·분할·저장/복원 코드·실제 체크포인트를 읽고 설명을 기록했다.
  새 학습·추론·설정/코드 변경은 하지 않았다. 기존 전체 ID 결과는 이전 무부하 기준이며
  새 평균/1.1 기준의 전체 ID 위치 학습은 아직 미실행 상태를 유지한다.

## 27. 2026-10-05 — train 결과 폴더별 학습 범위와 분석 전용 자료 구분

- 요청: 학습 결과부터 분석하기 위해 no_static_tip, mean_zero_range110,
  no_load_range_analysis, id18_only의 의미와 사용 데이터를 확인.
- 실제 각 폴더의 split_manifest(준비 전용은 prepared_data 하위), analysis.json,
  comparison.csv 및 models/*/hrm_bundle.pt 개수를 읽어 확인했다.

| 폴더 접미사 | 실제 네트워크 학습 | 학습/validation 또는 분석 내용 |
|---|---|---|
| no_static_tip | 힘11종, 고정 보조 위치MLP의11조합 | train summary_18.csv, validation summary_18-2.csv. Static 전부 제외. ID1–17은 학습하지 않음. 보조 위치는 ID0/18뿐. |
| mean_zero_range110 | 없음, bundle0개 | 무부하 기록의 fit 평균을 판정용으로 빼서0 중심으로 만들고 경계 반폭1.1배 적용. 범위/포함률 비교와 ID18 데이터 준비만 수행. 준비 목록의 static ID18은 validation이지만 학습을 실행한 것은 아님. |
| no_load_range_analysis | 없음, bundle0개 | 기존 median 중심 무부하 경계의 폭 확대에 따른 무부하/보류/유부하 행 수 비교. 모델 정확도나 학습 결과가 아님. |
| id18_only | 힘11×위치11의 class0 121조합 | train summary_18.csv와 summary_18-2.csv, validation static ID18. 위치는 ID0/18 이진 검출이며 ID1–17 제외. 당시 이전 무부하 기준으로 학습. |

- 따라서 no_static_tip을 ID1–18 전체 학습으로 이해하거나 id18_only를 summary_18 한 파일만
  학습한 것으로 이해하면 안 된다. Static 제외 전체 위치 학습은 여전히 미실행이다.
- 학습 결과 분석 대상으로는 원래 전체 위치 실험20260928_221428(242조합),
  id18_only(121조합), no_static_tip(11조합)을 구분한다. 원래 실험도 힘은 tip 전용이고 위치가 전체ID다.
  mean_zero_range110/no_load_range_analysis는 이름과 상위 train 경로에도 불구하고 분석/준비 자료다.
- comparison.csv의 일반 force_rmse_xyz_mN·축별 force_rmse_*·location 지표는 validation 기준이며,
  train 폴더 아래 있다는 이유로 학습 표본의 오차로 해석하지 않는다. test_ 접두사 지표는 test다.
  실제 학습 표본의 힘 오차/정답·예측은 별도 force_metrics/summary와 Excel의 train 역할을 확인한다.
- 수행/검증: 문서와 실제 파일 목록·분할·조합 수를 대조했고 현재 날짜와 기록을 갱신했다.
  새 학습/추론/폴더 이동/설정·코드 변경은 하지 않았으며 단위 테스트 재실행은 필요하지 않았다.

## 28. 2026-10-05 — dynamic 전체와 static 전체를 학습했는지 명확화

- 요청: summary ID1–18 및 summary_static_* 모두를 학습한 실행이 없는지 확인.
- 답변 범위: 해당 데이터군을 함께 사용해 train/validation으로 나눈 실행은20260928_221428이다.
  모든 CSV를 validation 없이 가중치 업데이트에 사용한 실행은 없다. 앞선 '전체/static 포함 학습'
  표현은 데이터군과 실제 가중치 학습 대상을 구별하지 못할 수 있어 구체적인 역할/수를 설명한다.
- 실제 split_manifest/data_audit 재확인: 위치 모델 train29CSV(dynamic17+static12),
  validation18CSV(dynamic13+static5). 양쪽 모두 effective ID1–18을 포함한다.
  Static ID10 한 CSV는48,360행 모두 유효 Kalman aligned force/frame이 없어 학습/검증 제외다.
  Test는 별도 ID18 두 CSV다. 끝단 힘 모델은 train dynamic ID18 두 CSV,
  validation static ID18 한 CSV이며 ID1–17 힘을 학습한 모델은 아니다.
- 따라서 '모든 CSV를 실제 학습에 투입' 또는 'static ID18을 힘 가중치 학습에 투입'한 결과는 없다.
  모델 선택에 사용할 validation을 남겨둔 기존 실험이 있다는 점과 구분한다.
- 수행/검증: 현재 요약/최신 기록 및 원본 저장 분할·제외 근거를 읽어 대조 후 기록했다.
  질문에 대한 설명만 수행했으며 새 학습/추론/설정 변경은 하지 않았다.

## 29. 2026-10-05 — static ID10 누락 열/구간 실측 확인과 validation 분할 설명

- 요청: static ID10에서 실제로 빠진 F/T 부분을 확인하고, CSV 전체를 분리하는 validation과
  각 CSV 후반 비율을 분리하는 방식 중 어떤 것이 보통 적절한지 설명. 사용자는 수정/재학습을 요청하지 않았다.
- 대상 원본: `datasets/train/summary_static_pan_-30to+30_tilt_-30to+30_interval-15deg_seg-id-10.csv`.
  전체48,360행, SHA256 `c1c6ec1e7bbee8dfd7a731dd6e6d1c24cf69aca4ba964a37eb25f8c9fa06fb1d`.
  Pandas 문자열 읽기로 빈칸과 유한 숫자를 분리 집계하고 읽기 전후 hash 불변을 확인했다.

| 열 | CSV/Excel 열 위치 | 확인 결과 |
|---|---|---|
| fts_kalman.aligned_fx/fy/fz | 46–48번째, AT–AV | 앞11,551행은 세 축 모두 유한 숫자, 이후36,809행은 세 축 모두 빈칸 |
| fts_kalman.aligned_force_valid | 49번째, AW | 전체48,360행 빈칸 |
| fts_kalman.aligned_frame_id | 50번째, AX | 전체48,360행 빈칸 |
| fts_kalman.fx/fy/fz | 40–42번째 | 전체48,360행 유한 숫자. 학습 기본 정답인 aligned XYZ와 다른 열 |
| fts.fx/fy/fz | 29–31번째 | 전체48,360행 유한 숫자. 센서 좌표의 raw 열 |
| fts.aligned_force_valid / fts.aligned_frame_id | 38–39번째 | raw aligned도 전체48,360행 빈칸 |
| fts_kalman.matched / fts.matched | 202번째 /196번째 | 각각 True48,252행, False108행 |

- Kalman aligned 숫자가 있는 구간: 원본 데이터0-based행0–11,550, 헤더 포함CSV줄2–11,552,
  기록 elapsed_s0.600157715–385.701540527.
  비어 있는 구간: 원본행11,551–48,359, CSV줄11,553–48,361,
  elapsed_s385.734882324–1612.991803955.
- 정정: 'F/T가 전혀 없다'는 표현은 부정확하다. 센서 F/T 숫자는 존재하지만 현재 필요한
  Kalman aligned XYZ가 후반에 빠지고, 전체에서 aligned 유효성/좌표계가 확인되지 않는다.
  현재 loader는 유한 XYZ, matched=True, aligned_force_valid=True, aligned_frame_id=hrm_base,
  시간 매칭 조건 등을 함께 요구하므로 정답 유효행0이다. 센서 고장/내보내기 누락 원인은 미확인이다.
  숫자 존재만으로 matched/좌표 변환 유효성을 보증하지 않으며 원본 자동복구/raw대체는 하지 않았다.
- Validation은 반드시 서로 다른 파일이어야 한다는 일반 규칙이 아니다. 새 독립 녹화에서의
  일반화가 목적이면 물리 실험/세션을 그룹으로 통째 분리하는 방식이 적합하고, 같은 녹화의 미래
  구간 성능이 목적이면 앞부분 학습/후반 validation도 가능하다. 파일명보다 같은 물리 실험의 공유 여부가 핵심이다.
  HRM의 반복 힘 주기/센서 영점/자세 등 세션 특성이 겹치는 평가와 새 실험 평가는 구별해야 한다.
- 시계열 창을 만든 뒤 랜덤으로 나누면 인접30행 창의29행이 겹칠 수 있으므로 새 실험 성능을
  낙관적으로 평가할 수 있다. 시간분할은 먼저 구간을 나누고 역할 간 창 중복을 피하며 필요한
  시간 간격을 둬야 한다. 창 중복 제거만으로 세션 상관이 모두 없어지는 것은 아니다.
- 현재 녹화 단위 분할은 목적에 맞는 합리적 선택이지만 유일한 정답/최적 구성은 아니다.
  특히 tip의 train dynamic/validation static 구성은 녹화뿐 아니라 동작 조건 변화도 함께 평가하고,
  녹화 수가 적어 어느 파일을 보류하느냐에 민감하다. 유효 녹화를 번갈아 검증하는 그룹 교차검증은
  대안이며 아직 실행하지 않았다. 모든 개발 자료를 최종 가중치에 사용하려면 모델/epoch 등 설정을
  validation으로 먼저 정한 뒤 train+validation으로 새 최종 모델을 학습하고 별도 test로 평가할 수 있다.
  이 단계도 현재 미실행이며 test로 설정을 고르는 것은 아니다.
- 근거: scikit-learn 공식 [grouped/time-series cross-validation](https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators-for-grouped-data),
  [TimeSeriesSplit와 gap](https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html).
  프로젝트에 대한 적용/권고는 위 일반 원칙과 현재 데이터 구조를 바탕으로 한 판단이다.
- 수행/검증: 원본 열별 수치·빈칸/flag와 구간 경계를 직접 집계하고 loader 조건 및 공식 문서를 확인했다.
  결과와 설명만 기록했다. 원본/설정/코드는 변경하지 않았으며 새 학습·추론·단위 테스트는 수행하지 않았다.

## 30. 2026-10-05 — ID 학습 누락 오해와 무부하 휴식 경계의 수동 분할 제안

- 요청: 파일 통째 validation/test 분리로 해당 ID가 학습되지 않는지 질문하고, 직접 수집한
  실험에서 외력이 없는 휴식 구간을 경계로 수동 분할해 test를 만드는 방안 검토.
- 기존20260928_221428 split_manifest를 다시 확인했다. train/validation 모두 ID1–18을 포함한다.
  ID1–6과10은 train1녹화, 나머지 ID는 train2녹화이며 validation은 각ID1녹화다.
  예: ID1은 static train/dynamic validation, ID10은 summary_10 train/summary_10-2 validation,
  ID18은 dynamic2개 train/static validation이다. Test는 별도ID18 두 녹화다.
  동일ID의 다른 녹화를 분리한 것이며 특정ID 전체를 test로 빼서 미학습한 구성이 아니다.
  ID당 정말1녹화만 있다면 그 녹화 전체를 보류할 때 학습 표본이 사라지는 우려는 맞다.
  Static을 제외할 때 ID1–6의 분할 질문이 생긴 이유가 이것이다.
- Validation은 다른 녹화이더라도 epoch/모델 선택에 사용했으므로 최종 test와 역할이 다르다.
  새 녹화 검증이라는 점과 최종 성능 평가용 독립 test라는 점을 혼동하지 않는다.
- 무부하 휴식의 중간을 경계로 완전한 접촉/해제 반복 블록을 나누는 것은 같은 실험 내 평가를
  위한 합리적 후보다. CSV를 나눠도 동일 물리 세션의 자세/영점/조건을 공유하므로 새 독립 실험이 되지는 않는다.
  무부하 구간만 test로 떼어내면 오경보/무부하 힘 오차만 평가할 수 있고 접촉ID/유부하 힘 성능은 평가할 수 없다.
- 수동 분할 시 원본은 보존하고 파생본의 부모파일/hash, 원본행/시작끝시간, ID와 session/block 연결을 남긴다.
  분리한 평가 구간은 train/validation 및 scaler fit에서 제외하고 경계의30행 입력 창 중복과 시간 인접성을 고려한다.
  평가 구간 제거 후 남은 앞뒤를 시간상 연속처럼 이어붙이지 않는다. 무부하만 남기거나 쉬운 구간만 선별하지 않고
  평가 목적에 맞는 자세/힘 방향/유부하·무부하를 포함한 블록을 미리 고정한다.
- 이미 해당 구간을 본 기존 모델/정규화로 평가하면 새 test 성능이 아니다. 해당 구간을 제외한 새 학습이
  필요하며, 과거 자료를 다시 분할한 결과는 같은 실험 내부의 재분할 평가로 기록하고 새로운 수집 test와 구별한다.
  현재 loader는 완전한 독립CSV 분할을 전제로 하므로 잘라낸 파일을 기존 test폴더에 추가하는 것만으로
  올바른 분할이 적용됐다고 보장하지 않는다. 적용 전 부모 구간/역할 보호를 포함한 명시적인 설계가 필요하다.
- 근거: [scikit-learn grouped CV](https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators-for-grouped-data).
  같은 그룹 내부 평가와 새로운 그룹 일반화의 구별을 프로젝트 데이터에 적용한 설명이다.
- 수행/검증: 분할 기록/보호 코드와 공식 자료를 읽고 의견만 기록했다. 사용자 수동 작업을 대신
  실행하지 않았으며 원본·설정·코드·학습 결과를 변경하지 않았다. 분할 방식 변경은 아직 미적용이다.

## 31. 2026-10-05 — 긴 녹화의 앞 train/뒤 test 분할 의도 확정

- 사용자 명확화: 녹화 파일 수가 제한적이므로 긴 학습 데이터에서 무부하 휴식을 경계로
  앞 전체를 train, 뒤 전체를 test로 쓰려는 것이다. 독립 실험 성능과 구별한다는 점은 이미 이해하고 합의했다.
  무부하 구간만 추출하거나 새 독립 녹화처럼 해석하려는 요청이 아니다.
- 반영: 앞선31절 이전의 분할 방식 질문은 이 구체적인 시간 블록 분할 방향으로 정리했다.
  선택한 녹화를 학습에도 활용하고 후반의 유부하/무부하가 포함된 전체 블록을 보류 평가에 사용한다.
  독립 녹화 test 결과는 별도 평가로 보존한다. 앞으로 이 차이를 이미 합의한 사항으로 취급하고
  같은 주의사항을 되풀이하며 의도 확인을 요구하지 않는다.
- 아직 정하지 않은 실행 세부사항: 대상 CSV와 절단 시간, 모델 선택용 validation 확보 방법.
  사용자가 경계를 수동으로 지정할 계획이며 이번 메시지를 자동 절단/재학습 요청으로 확대하지 않았다.
  실제 실행 시 원본/행·시간 대응과 세션 연결을 보존하고, 학습/scaler에 후반 test가 들어가지 않게 한다.
- 수행/검증: 현재 요약·최신 기록과 AGENTS를 읽고 합의 방향을 두 문서에 반영했다.
  데이터·설정·학습 코드 변경이나 새 학습은 없다. 문서 변경만 수행했다.

## 32. 2026-10-05 — valid 검사 복잡도와 동일 열 구성의 행 분할 호환성

- 요청: 사용자는 학습 시 입력/출력 열을 지정하는 간단한 사용 방식을 원하며,
  valid 열 검사가 내부 코드를 지나치게 복잡하게 만드는지 질문했다. 수동 분할은 특정 행을
  경계로 동일한 열 구성을 유지해 저장할 계획이다.
- 코드 확인: independent_data의 feature_spec/force 계약은 X/Y 외에 선택 소스의 matched,
  aligned_force_valid, frame_id, timestamp 및 시간차 열을 읽는다. _validity는 유한 숫자·flag·
  시간차·좌표계 조건을 행별 boolean mask로 합친다. valid_endpoints는 무효 행/시간 경계에서
  연속 길이를 초기화하고30행 연속 유효한 창만 허용한다. Flag들은 기본 모델 입력/출력이 아니다.
  검사는 데이터 준비 단계이며 각 학습 배치에서 별도 검증 네트워크를 실행하는 구조가 아니다.
- 평가: 핵심 valid 검사는 단순하고 모델 학습과 분리되어 있다. 다만 전체 loader에는 timestamp
  정합성 감사와 특정 원본hash에 한정된 과거 ID/시간 복구 예외도 있어 전체가 단순 X/Y CSV 로더인 것은 아니다.
  사용자 조작은 간단하게 유지하면서 내부적으로 유효성을 검사하는 방식은 양립 가능하다.
- 현재 설정의 범위도 구별한다. X는 길이/장력/각도 feature_groups 선택이며 임의 개별 열 리스트
  인터페이스는 없다. 힘Y는 선택한 raw/Kalman 소스의 aligned Fx/Fy/Fz 순서를 검증한다.
  자유로운 모든 input/output 열 매핑 기능을 이미 구현했다고 설명하지 않는다.
- 동일 헤더·열·원래 값·timestamp/flag를 보존하며 전체 행 단위로 자르면 일반적인 행 유효성
  규칙은 그대로 적용된다. 경계마다30행 창은 새로 구성한다. 단, 파일hash가 달라지므로
  summary_18-2의 기존 ID 보정 및 알려진 trim 시간복구 예외를 새 파생파일에 자동 승계하지 않는다.
  부모 원본과 절단 범위를 기록해 대응을 확인해야 하며, 앞train/뒤test의 새로운 분할 정책 지원도
  아직 미구현이다. 따라서 열 구성이 같다는 것만으로 현재 명령에 바로 넣어 모든 처리가 보장되는 것은 아니다.
- 수행/검증: 현재 기록과 실제 로더/설정/feature_spec/valid_endpoints/hash 계약을 읽고 설명을 기록했다.
  존재하지 않는 features.py 검색은 data.py의 실제 정의로 확인했다. 코드/설정/데이터는 변경하지 않았고
  새 학습·추론·테스트 실행은 없다. 사용성 요구를 기록했으며 실행 지시로 확대하지 않았다.

## 33. 2026-10-05 — set-zero 빈칸 제외, timestamp 사용, 숫자 유효성만의 간소화 희망

- 요청: set-zero 때 생기는 빈칸이 학습에서 제외되는지, 수동 삭제가 필요한지,
  timestamp도 확인하는지 질문. 별도 valid flag 확인은 필요하지 않다는 사용자 선호와,
  간단한 X/Y 학습에서 Fx/Fy/Fz 빈칸이 오류를 일으키는지 확인했다.
- 현재 구현 확인: _number는 빈칸/비수치를 NaN으로 변환하고 _validity의 isfinite mask에서 제외한다.
  선택한 입력/힘 정답이 무효인 행과 그 행을 포함하거나 가로지르는30행 창을 제외한다.
  결측 이후30행이 다시 연속 유효해야 학습 창이 생기므로 원본을 수동 삭제할 필요가 없다.
  정상 숫자로 저장된 set-zero 전후까지 이벤트를 알아서 검출/제외하는 기능은 아니다.
- Timestamp는 실제로 읽는다. 모델 feature는 아니며 순서/간격/소스 시간 정합성을 검사한다.
  valid_endpoints는 시간 비증가나 median 간격×1.5 초과에서 창을 끊는다.
  행을 수동 삭제하더라도 원래 timestamp를 보존하면 충분히 큰 시간 공백은 경계로 남는다.
- 단순 loader가 빈칸을 그대로 숫자로 변환하면 변환 예외가 날 수 있고, NaN 상태로 loss에
  넣으면 반드시 예외가 나지 않더라도 loss/gradient가 NaN으로 전파되어 학습이 실패할 수 있다.
  선택한 X/Y의 유한 숫자 여부만 자동 검사해 제외하는 처리는 간단히 구현 가능한 별도 절차다.
  'valid flag를 보지 않음'과 '빈칸/NaN을 학습에 투입'은 다른 정책이다. 빈칸을0으로 바꾸지 않는다.
- 사용자 의도: 입력/정답 숫자만 유효하면 사용하고 빈칸은 자동으로 제외하는 간소화 방향.
  이번은 동작 확인 질문으로 응답했으며 flag 검사를 끄거나 timestamp 검사를 제거하는 코드를
  즉시 적용하지 않았다. Timestamp를 모델 입력으로 넣지 않는다는 사실과 시계열 경계 검사는 구별한다.
- 수행/검증: 현재 요약/직전 기록 및 실제 숫자 변환·mask·timestamp·창 구성 코드를 대조했다.
  문서/작업 규칙의 구현 상태와 선호를 갱신했으며 원본·실행 설정·코드·모델은 변경하지 않았다.
  새 학습·추론·단위 테스트는 수행하지 않았다.

## 34. 2026-10-05 — 빈칸 행 제외 후 연결 확정, 사용자 데이터 준비

- 사용자 확인: 선택한 입력/출력의 빈칸 행을 제외하고 다시 숫자가 있는 행을 이어붙이면 된다.
  사용자가 직접 test용 데이터셋을 잘라 준비한 뒤 돌아오겠다고 했다.
- 합의: 각 파일/분할 역할 안에서 선택 X/Y의 빈칸·비수치·NaN/Inf 행을 제외하고 남은 행을
  원래 순서로 연결한다. 선택하지 않은 열의 빈칸은 제외 근거로 삼지 않는 간소화 방향이다.
  Valid flag 확인 생략과 결측 전후 연결을 사용자가 명시적으로 확인한 것이다.
  연결된 행으로 시간창을 만들 때 결측 제거로 생긴 원래 시간 공백을 다시 창 단절 사유로 삼는
  과거 방침을 자동 적용하지 않는다. 원본 시간/행 대응은 추적용으로 보존하고 train/test와
  서로 다른 파일을 가로질러 연결하지 않는다. 빈칸을0 또는 무부하로 대체하는 방식은 아니다.
- 구현 상태: 현재 코드는 여전히 이전 정책이다. 사용자 데이터 준비 발언에 맞춰 합의만 기록했으며
  원본 자동 절단, 코드/설정 변경, 새 학습은 실행하지 않았다. 실제 대상/절단 위치·새 자료가 준비되면
  새 전처리/분할을 반영할 작업이 남아 있다. 같은 전처리 방향에 대한 확인을 반복 요청하지 않는다.
- 수행/검증: 현재 요약·직전 기록과 AGENTS를 확인하고 최신 합의로 갱신했다. 문서 변경만 수행했다.

## 35. 2026-10-05 — 사용자 분할 데이터 적용 및 직접 실행 명령 (학습 미실행)

- 요청: 사용자가 ID별 train/test 파일을 다시 저장했으며, 직접 학습할 명령과 폴더 역할을 질문했다.
  **학습은 실행하지 말라는 지시를 우선했다.** 모델 성능 수치를 새로 만들지 않았다.
  앞서 합의한 숫자 행 연결/수동 test 분할을 지원하도록 로더와 기본 설정을 반영하고 데이터 준비만 실행했다.
- 실제 구성: `datasets/train/*.csv`48개(dynamic30+static18), `datasets/test/*.csv`19개.
  Test는 ID1–17 각1개와 ID18 두 파일이며 그대로 고정한다. Train에서 특정 ID나 파일을 test로 더 빼지 않는다.
  Static ID10의 현재 파일은 선택 X/Y가 유효한48,252행을 포함하며 학습/validation에 참여한다.
  ID18 힘은 dynamic2개+static18 파일의 train 부분을 사용하고 위치는 전체ID1–18을 사용한다.
- Validation 질문은 선택 사항으로 전달했으며 작업 중 답변이 없었다. 각 train CSV의 숫자 행을
  앞80% 학습/뒤20% validation으로 나누는 기본값을 알리고 적용했다.
  `validation_strategy: per_file_tail`, `validation_fraction: 0.2`에서 조정할 수 있다.
  따라서 모든48파일의 일부가 학습에 들어가되 각 파일 전체를 optimizer에 투입하는 것은 아니다.
  Validation은 epoch/모델/구간 경계 선택용이고 test는 최종 평가용이다.
- `preprocessing: numeric_compact`: 선택 X/Y의 빈칸·비수치·NaN/Inf 행을 제외하고 같은 파일 안에서
  남은 행을 순서대로 연결한다. 선택하지 않은 열의 빈칸, valid/matched/frame flag, matching skew,
  timestamp 간격으로 추가 제외하지 않는다. Timestamp는 모델 입력이 아니며 추적용일 뿐이다.
  일부 새 CSV의 timestamp가 과학적 표기로 반올림되어 있으므로 행 순서를 유지하고 정밀 시간을 복원했다고 주장하지 않는다.
  시간 메타데이터가 없으면 추론/Excel의 시간은 빈칸으로 남긴다. 기존 무부하 교정 기록의 감사 경로는 유지한다.
- 창 길이는30행이다. 유효 숫자 행으로 만든 각 역할 안에서만 창을 생성하므로 validation 첫29행은
  해당 역할의 이력 확보용이다. 파일/역할 경계를 가로지르는 창은 없다. Scaler도 학습 구간에서만 fit한다.
  Bundle에 설정·hash·역할별 구간을 저장하며 예측 CSV/Excel의 `source_row`는 삭제 전 원본 행 번호다.
  과거 옵션 없는 설정/bundle은 audited 전처리와 whole_csv 분할을 유지한다.
- 중복 점검: 최초 ID1 train의 원본행3365와 test의0행이 선택 X/Y 전체에서 같았다.
  한시적으로 정확hash 행 제외를 설정했으나, 확인 도중 train `summary_1.csv`가 사용자 측에서
  3,365행으로 다시 저장된 것을 감지했다(hash `820aa89a…46408`). 최신 파일에는 중복 행이 없어
  임시 제외 설정을 제거하고 다시 준비했다. Agent는 원본 CSV를 쓰거나 삭제하지 않았다.
  선택 X/Y가 완전히 같은 train/test 행을 거부하는 검사를 추가했다. 이것만으로 부모 세션 관계까지 증명하는 것은 아니다.
- 최종 데이터 준비 결과(숫자 행 연결 후30행 창 수):

  | 역할 | 참여 CSV 수 | 전체ID 지도 가능 창 수 |
  |---|---:|---:|
  | Train | 48 | 730,320 |
  | Validation | 48 | 181,560 |
  | Test | 19 | 27,785 |

  같은48개 train파일의 서로 겹치지 않는 앞/뒤 구간이다. 위치 loss에서는 무부하 방식에 따라
  uncertain 또는 unloaded 끝점이 추가로 제외된다. 이 수를 실제 위치 loss 표본 수와 혼동하지 않는다.
  기존 독립 ID18 test 두 파일과 사용자 수동 분할 ID1–17 test는 평가 해석을 구별한다.
  `test_evaluation_scope`에 혼합 구성을 기록했고 예측 결과는 파일별로도 보고한다.
- 수행 파일: `configs/train.yaml`, `numeric_data.py`, 독립 data/engine/prediction 경로 및 Excel 내보내기를
  갱신했다. 준비 결과와 감사는 `.runtime/20261005_manual_split/prepared_latest/`에 있으며
  학습 결과로 혼동하지 않도록 새 `results/train` 실행을 만들지 않았다.
- 검증: 실제67CSV 준비 성공, 최종 준비 이후67개 원본hash 불변 확인, 저장 test 목록의 추론 보호 검사 통과.
  데이터/engine/추론/Excel/새 전처리 관련55개 단위 검증 통과. 새7개 검증에는 compact 행 대응,
  flags/time 무관 처리, 단일 파일 validation, scaler 누수 방지, 경계 중복 검출,
  미학습 임시 bundle 저장·복원·합성 입력 추론, `--check-data`의 모델/학습 미호출 검사가 있다.
  실제 optimizer를 실행하는 기존 단위 테스트1개는 이번 지시에 맞춰 제외했다. 새 데이터 학습이나
  기존 모델의 실제 데이터 추론/Excel 생성은 실행하지 않았다. Train/predict CLI `--help`도 확인했다.
- 사용자가 프로젝트 루트에서 직접 실행할 명령:

  ```bash
  HRM_RUN_ID="$(date +%Y%m%d_%H%M%S)"
  bash scripts/hrm_python.sh train.py --config configs/train.yaml --output "results/train/$HRM_RUN_ID"
  ```

  위 학습이 정상 완료된 뒤 같은 터미널에서 test 평가:

  ```bash
  bash scripts/hrm_python.sh predict.py --train-dir "results/train/$HRM_RUN_ID" --output "results/predict/$HRM_RUN_ID"
  ```

  학습은 기본11×11×2=242조합이다. 예측 명령은 validation으로 무부하 방식별 조합1개를 선택하여
  학습 당시 고정한 test19파일을 평가한다. 모든 구조의 MATLAB용 시트가 필요하면 학습 완료 후:

  ```bash
  bash scripts/hrm_python.sh scripts/export_model_workbooks.py --train-dir "results/train/$HRM_RUN_ID" --train-output "results/train/$HRM_RUN_ID/excel" --predict-output "results/predict/$HRM_RUN_ID/excel"
  ```

  새 터미널에서는 `$HRM_RUN_ID`를 실제 학습 폴더의 날짜_시간으로 다시 지정한다.
  기존 날짜 폴더는 덮어쓰지 않는다. 다음 단계는 사용자 직접 학습이며 성능 개선 여부는 아직 미측정이다.

## 36. 2026-10-05 — 학습/예측 파일 구성 설명과 기능별 최소화 희망

- 요청: scripts와 hrm_force 전체가 학습/예측에 필요한지, train.py·model_zoo.py·predict.py와
  Aidin 무부하 분석 파일 중심으로 단순화할 수 있는지 현재 구조 설명을 요청했다.
  사용자는 사용하는 파일 수 자체를 최소화하는 구성을 선호한다.
- 확인한 현재 구성: scripts에는 실행 보조10개(8Python+2shell), hrm_force에는18Python 파일이 있다.
  현재 YAML 경로의 주요 흐름은 train.py → independent_engine.py → independent_data.py/numeric_data.py,
  independent_models.py/models.py, independent_evaluation.py다. predict.py → independent_prediction.py가
  같은 로더·모델·정규화·평가 함수를 재사용한다. feature_catalog.json과 dataset_contracts.json도 읽는다.
  hrm_force는 실제 구현이므로 현재 상태에서 폴더를 지우면 학습/예측이 작동하지 않는다.
- 루트 model_zoo.py는3줄의 기존 MODEL_NAMES/build_model/count_parameters 재노출 파일이다.
  현재 독립 힘/위치 네트워크의 실제 구현과 생성은 models.py 및 independent_models.py에 있다.
  학습할 구조 선택은 configs/train.yaml의 force_candidates/location_candidates에서 한다.
- scripts 전체가 학습 필수는 아니다. hrm_python.sh는 환경 Python 및 이 PC GPU 보조 라이브러리
  선택용 런처다. train.py/predict.py 자체에도 runtime.ensure_driver_runtime 진입 처리가 있다.
  setup_environment.sh는 환경 설치용, analyze_no_load.py는 무부하 통계/교정 진단,
  analyze_dataset.py는 데이터 분포 진단, export_model_workbooks.py는 Excel 내보내기,
  summarize_force_axes.py는 축별 지표 정리, plot_independent_results.py는 그림,
  benchmark_convolution.py/benchmark_inference.py는 속도 점검, fine_tune_all.py는 과거 추가학습용이다.
  기본 train/predict가 이 분석/벤치마크 스크립트들을 자동 실행하는 것은 아니다.
- 파일이 늘어난 이유: 기능별 모듈 분리와 함께 기존 JSON/folder/warm-start 호환 코드가 남아 있다.
  기존 engine.py/evaluation.py/folder_*는 새 핵심 학습 기능과 구별해야 한다. 단, train.py/predict.py의
  최상단 legacy import 및 현재도 공유하는 data.py/models.py 때문에 이름만 보고 바로 삭제하면 안 된다.
- 단순화 제안(아직 미적용): train.py(학습), predict.py(예측/결과 저장·Excel), model_zoo.py(실제 모델 정의),
  data_utils.py(CSV·빈칸 제외·분할·정규화·창 및 공통 저장/복원), metrics.py(힘/ID 지표),
  analyze_no_load.py(센서 무부하 교정/분석) 중심의6Python 구조와 configs/train.yaml.
  옛 호환/개발 진단은 기존 보존 정책에 따라 archive로 정리하고 실제 기능을 새 위치로 통합할 수 있다.
  정확한 파일 수는 결과 내보내기 기능을 합치는 범위에 따라 달라지며3~4파일이 기술적 필수 제한은 아니다.
  모델 종류를 고르는 것은 설정으로 유지하고 네트워크 구현을 수정할 때 model_zoo.py를 사용하는 방향이다.
- 추가 정적 발견/미완료: analyze_dataset.py의 pooled_role 및 역할별 집계는 아직 파일 전체 x/endpoints를
  사용하여 per_file_tail의 role_rows를 반영하지 않는다. 새 기본 설정에 그대로 사용하면 같은 파일 전체가
  train/validation 통계에 각각 들어갈 수 있다. 메인 학습 WindowStore/scaler의 역할 분리는35절에서
  검증한 경로이며 이 진단 스크립트를 호출하지 않는다. 해당 선택 도구는 정리 시 수정하거나 보관해야 한다.
- 수행/검증: 현재 문서·진입점·import·스크립트 호출을 읽기 전용으로 확인하고 이 기록을 추가했다.
  학습/예측 실행, 파일 삭제/이동, 런타임 코드 재구성은 수행하지 않았다. 이번은 현재 구조 설명이며
  제안한 최소 파일 구조를 이미 구현했다고 설명하지 않는다.

## 37. 2026-10-05 — 원래 저장소와 비교한 코드 읽는 순서 및 필수 기능 설명

- 요청: 사용자는 [LSTM-force-estimation](https://github.com/DaeyunJang/LSTM-force-estimation)의 작은
  핵심 파일 구성을 참고해 현재 hrm_force가 왜 많은지, 각 코드가 어떻게 쓰이는지 설명을 요청했다.
  파일이 많아 읽고 수정하기 어렵다는 것이 핵심 문제다. 앞선 '현재 폴더를 바로 지우면 안 됨'은
  '모든 파일이 기능상 반드시 필요함'이라는 뜻이 아니다. 현재 import 의존성과 필요한 기능을 구별한다.
- 참조 저장소 읽기 전용 확인: humble의 commit `c3238661f26199180b0b89f4b3f74f346d8c2221`.
  현재 핵심 경로는 README의 오래된 scripts/LSTM_train.py 예시가 아닌 scripts_model이다.
  [train_models.py](https://github.com/DaeyunJang/LSTM-force-estimation/blob/c3238661f26199180b0b89f4b3f74f346d8c2221/scripts_model/train_models.py)는
  CSV/JSON 병합, 입력/정답 열, 결측 제거, 창 생성, scaler, Keras 학습 및 저장을 담고 있다.
  [predict_models.py](https://github.com/DaeyunJang/LSTM-force-estimation/blob/c3238661f26199180b0b89f4b3f74f346d8c2221/scripts_model/predict_models.py)는
  저장 모델/정규화 복원과 test 처리·역정규화·CSV 저장을 담당한다.
  [model_zoo.py](https://github.com/DaeyunJang/LSTM-force-estimation/blob/c3238661f26199180b0b89f4b3f74f346d8c2221/scripts_model/model_zoo.py)는9종 모델,
  [meta_utils.py](https://github.com/DaeyunJang/LSTM-force-estimation/blob/c3238661f26199180b0b89f4b3f74f346d8c2221/scripts_model/meta_utils.py)는 실행 기록이다.
  크기/입력 변형과 보조 도구를 제외하면 핵심4파일이라는 사용자 설명과 맞는다. 참조의2축 회귀보다
  현재3축 회귀·독립ID 분류·무부하 처리 요구가 늘었지만18개 모듈 분리는 기술적 필수 조건이 아니다.
  Keras fit과 현재 직접 작성한 PyTorch 학습 루프의 차이도 코드 길이 차이의 한 이유다.

**현재 train.py를 실행하면 실제로 일어나는 일**

1. train.py가 YAML 경로를 보고 `independent_engine.main()` → `train_experiment()`를 호출한다.
   메인 학습 흐름을 읽으려면 `independent_engine.py:276`부터 보면 된다. 루트 train.py의
   `legacy_main()`은 현재 YAML 방식에서 실행되는 학습 함수가 아니다.
2. `independent_data.load_config()`가 YAML을 읽고 입력 그룹을 실제 열 이름으로 펼친다.
   `prepare_data()`가 폴더 목록과 파일hash를 고정하고 교정을 준비한다.
   `numeric_data.load_numeric_trial()`은 선택한 X/Y를 숫자로 변환하여 빈칸·NaN/Inf 행을 제외한다.
   남은 행을 연결하고 삭제 전 source_row 대응을 보존한다. 학습 대상CSV의 valid/frame/시간차 검사는 생략한다.
3. 각 train파일의 남은 행을 앞80% 학습/뒤20% validation으로 나눈다. Test파일은 고정된다.
   `fit_scaler()`는 학습 부분의 평균·표준편차만 구하고 힘/위치 분기별로 보관한다.
   힘 전용 학습은 ID18, 위치 학습은 ID1–18이므로 두 분기의 정규화 대상도 다를 수 있다.
4. `WindowStore`는 한 표본의 과거30행 입력과 마지막 행 정답을 연결한다. 기본 X 모양은
   `(batch,30,26)`이며 Y_force는 `(batch,3)`, Y_location은 표본마다 정수라벨1개다.
   MLP는 마지막 행만 쓰는 별도 처리다. 파일/학습·검증 경계는 입력 창이 넘지 않는다.
5. `models.py`의 기본 layer/encoder를 `independent_models.py`가 조합한다.
   `build_estimator()`가 별도 파라미터를 가진 force_net과 location_net을 만든다.
   힘 출력3개, 전체ID masked 위치 출력18개, class0 위치 출력19개다. 학습 중에는 위치 logits이며
   예측 시 softmax로 확률값으로 바꾼다. ID/실측 힘은 네트워크 입력이 아니다.
6. `train_branch()`가 AdamW, forward, loss, backward, step, validation, early stopping을 실행한다.
   힘 기본 loss는 표준화된 실측3축에 대한 MSE, 위치는 cross-entropy다. 무부하 방식은 위치 정답/loss에
   적용하고 힘 회귀를 무부하에서0으로 바꾸지 않는다. 확정 무부하를 class0는0으로 학습하고
   masked는 위치 loss에서 제외한다. 불확실 부하 위치라벨은 두 방식 모두 loss에서 제외한다.
7. 힘×위치×무부하 방식의 각 조합에서 새 모델/optimizer로 위 과정을 반복한다.
   `independent_evaluation.py`가 역정규화 후 축별/전체 RMSE·MAE, ID/구간/부하 지표를 계산한다.
   `bundle_for()`가 가중치·정규화·설정·교정·분할을 hrm_bundle.pt에 담고 비교표를 기록한다.

**현재 predict.py를 실행하면 실제로 일어나는 일**

- `--train-dir` 경로는 `independent_prediction.select_and_evaluate()`가 validation 비교표로
  방식별 기존 bundle을 선택한다. `restore_bundle()`이 구조/가중치/학습 당시 정규화를 복원한다.
- `predict_trials()`가 test를 같은 입력 순서/전처리/창 길이로 만들고 저장 scaler를 적용한다.
  Test에서 scaler를 다시 fit하지 않는다. 힘은 역정규화하고 N/mN 열로, 위치는 ID/확률로 저장한다.
  힘 지표는 현재 tip 학습 범위가 확인된ID18에서 평가하고 위치는 활성ID 전체를 구별한다.
- `independent_evaluation.py`가 정답과 예측을 비교한다. 구간 탐색은 저장 validation으로 하고
  test는 선택한 구간으로 평가한다. CSV/JSON 결과와 모델별 Excel은 별도 출력 경로이며
  Excel 요청 때만 `excel_export.py → excel_tables.py → excel_writer.py`를 사용한다.

**hrm_force 파일을 목적별로 읽는 지도**

| 현재 파일 | 실제 역할 | 핵심 작업에서의 위치 |
|---|---|---|
| independent_engine.py | 전체 조합 반복, scaler, 창 배치, 학습 루프, bundle 저장/복원 | 먼저 볼 학습 본체 |
| numeric_data.py | 숫자 X/Y 행 선택 및 연결, 원본 행 대응 | 현재 CSV 로더 |
| independent_data.py | 설정/분할/교정/라벨; 과거 audited 로더도 포함 | 새 데이터 준비와 과거 정책 혼재 |
| data.py | 열 그룹, hash, 숫자/시간/JSON 보조 및 과거 데이터 로더 | 일부 공통 함수가 현재도 필요 |
| models.py + independent_models.py | 실제11종 모델과 독립 힘/위치 모델 구성 | 현재 model_zoo 구현 본체 |
| independent_prediction.py | 저장 모델 선택/복원 후 test 예측 및 결과표 | 예측 본체 |
| independent_evaluation.py | 축별 힘/ID/구간/무부하 지표와 구간 탐색 | train/validation/test 공통 평가 |
| excel_export.py + excel_tables.py + excel_writer.py | 모델별 시트 선택, 행 정렬, Excel 쓰기 | Excel 내보내기 선택 기능 |
| engine.py + evaluation.py + folder_datasets.py + folder_prediction.py + time_repair.py | 이전 JSON/folder/추가학습·시간 복구 경로 | 현재 기능과 분리해 보관할 후보 |
| runtime.py | 이 PC NVIDIA 라이브러리 선택 | 학습 알고리즘과 무관한 환경 보조 |
| __init__.py | 패키지 표시 | 현재 기능 구현 없음 |

**현재 설정 또는 코드를 바꾸려면 어디를 보는가**

| 변경 목적 | 현재 수정 위치 |
|---|---|
| 사용할 모델 조합 | configs/train.yaml의 force_candidates / location_candidates |
| 모델 너비·층수 | 같은 설정의 force_params / location_params; 허용 옵션은 independent_models.DEFAULT_PARAMS / resolve_params |
| epoch·batch·학습률·창 길이·validation 비율 | configs/train.yaml의 max_epochs / batch_size / learning_rate / window_samples / validation_fraction |
| 길이·장력·각도 입력 그룹 | configs/train.yaml의 feature_groups |
| raw/Kalman 힘 정답 | configs/train.yaml의 force_source + force_columns; 현재 aligned XYZ 계약 검사 유지 |
| 숫자 행 선택/빈칸 처리 방식 | numeric_data.load_numeric_trial |
| loss/optimizer 로직 | independent_engine.train_branch |
| 새로운 네트워크 구조 | independent_models의 encoder 생성 및 models 기본 layer; 현재 루트 model_zoo.py만 수정해서는 반영되지 않음 |
| 평가식/구간 지표 | independent_evaluation.force_metrics / location_metrics |

현재 입력은 그룹을 실제 열 목록으로 바꾸는 방식이며 자유로운 input_columns 목록 인터페이스는 아직 없다.
사용자가 원하는 '입력/출력 열 지정 → 학습 → 실측/예측 저장'과 비교하면 이 제한도 정리 대상이다.

- 설계 판단: 숫자 결측 제거, train만으로 정규화, 파일/분할 경계 유지, scaler/입력 순서의 저장·복원,
  두 위치 loss 방식 및 힘 역정규화는 기능상 유지해야 한다. 그러나 각각 별도 파일일 필요는 없다.
  독립 분기 학습·무부하 비교·Excel 요구가 코드 증가의 일부를 설명하지만, 과거 호환과 세부 모듈 분리는
  구현 선택이다. 현재 사용성 문제를 '모두 필요한 파일이니 읽어야 한다'고 답하지 않는다.
- 단순화 방향은 사용자가 익숙한 train/predict/model_zoo/공통처리의4핵심 + 무부하 분석1개도 가능하다.
  앞선6개 제안에서 metrics를 공통처리에 합치는 선택이 가능하다는 뜻이며 아직 어느 재구성도 적용하지 않았다.
  같은 기능을 유지하며 기존 가중치 구조·정규화·결과 대응을 검증할 필요가 있다. 참조 저장소는
  창을 생성한 뒤 shuffle=True로 분할하므로, 파일 배치는 참고하되 현재 창 경계 분할을 그 방식으로 되돌리지 않는다.
- 수행/검증: 참조 GitHub 코드와 현재 파일/함수/import를 정적으로 대조하고 통합 기록에 읽는 지도를 추가했다.
  외부 저장소 clone/실행/수정, 새 학습·추론, 코드 이동·삭제는 하지 않았다. 실행 코드 변경이 없어
  단위 테스트는 재실행하지 않았다. 다음 재구성 시 사용자 직접 편집 가능성과 적은 파일 수를 우선한다.
