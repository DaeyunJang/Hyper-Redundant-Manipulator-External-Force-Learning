# HRM 프로젝트 작업 규칙

최신 합의: 2026-10-05. 한국어로 답한다. 먼저
[docs/CHATGPT_README.md](docs/CHATGPT_README.md)의 현재 상태와 최신 기록을 읽는다.
사용자가 문서 한 곳에 기록하도록 요청했으므로 요구사항·수행·검증·미완료·다음 작업을
해당 문서에 날짜와 함께 누적한다. 과거 문서 원본은 `archive/legacy_materials_20260928.tar.gz`에
보존되어 있다. 현재 구현과 과거 계획을 구별하고 실행하지 않은 작업을 완료로 쓰지 않는다.

- 사용자 설정은 `configs/train.yaml`. 독립 `force_net`/`location_net`을 가진 통합 모델이며
  모든 힘×위치×무부하 방식 조합을 새 가중치·새 optimizer로 학습한다. 분기 가중치 재사용,
  warm start, resume는 이 새 경로의 기능이 아니다. 기존 JSON 코드는 역사적 호환 경로다.
- 기본 입력26은 길이4+장력4+상대각18. 실제 tilt/pan 축의 rad·0·부호를 보존한다.
  그룹 선택은 설정에서 가능하다. timestamp·실험ID·F/T 정답을 X에 넣지 않는다.
- 기본 정답은 `fts_kalman.aligned_fx/fy/fz`, hrm_base, 기록 mN→학습 N.
  회귀 정답 부호·영점을 임의 변경하지 않는다. 향후 제어 연결에서만 역정규화 XYZ에 -1을 한 번 적용한다.
- 힘은 기본 tip 전용이며 무부하에서도 연속 출력한다. body 접촉의 tip 정답을 0으로 만들지 않는다.
  최신 우선순위는 ID18 전용 힘 정확도 개선이며 전용 모델은 필수다. 별도 body contact 감지
  모드에서 구간 인식 약90% 이상을 목표로 하되 달성을 주장하지 않는다. 전체 ID 힘 회귀는
  현재 필수 작업이 아니다. 운용 모드/제어 연결은 미구현이며 body 접촉 시 tip 출력의 정확도를 보장하지 않는다.
  위치 masked는 유부하 조건부 분류이며 자체 무부하 검출이 없다. class0는 명시적 무부하 클래스다.
  불확실 부하 라벨과 무효 정답은 위치 loss에서 제외하고 실제 접촉을 무부하로 바꾸지 않는다.
- 무부하 기록2로 정한 기준과 다른 기록 간 영점 이동의 한계를 보존한다. 확률은 보정된 물리적
  접촉 신뢰도로 보증하지 않는다. ID18-only test를 전체 body/3구간 독립 평가라고 부르지 않는다.
- 2026-09-29 최신 무부하 설정은 `calibration.center_method: mean`, `range_multiplier: 1.1`이다.
  기록2 앞70%의 평균을 판정용 실측 힘에서 한 번 빼고, 그 잔차의95%/99.5% 분위수 경계 반폭을
  모두10% 확대한다. 회귀 정답·원본 CSV는 보존한다. 보정된 힘에 offset을 두 번 적용하지 않는다.
  옵션이 없는 과거 설정은 median/1.0, 과거 bundle은 저장 교정을 유지한다.
  새 기준 비교·데이터 준비는 `results/train/20260929_185223_mean_zero_range110`에 있다.
  새 기준의 static 제외 끝단11종은 `results/train/20260929_195732_no_static_tip`에서 완료했다.
  새 무부하 기준의 전체 ID 위치 학습은 아직 미실행이다. Static 제외 시 ID1–6 각1녹화여서
  당시 전체 위치 학습은 미진행했다. 기존 tip은 dynamic 두 파일 train/static validation이었고,
  이번 tip은 summary_18 train/summary_18-2 validation이므로 static 학습 유무만의 비교가 아니다.
- 원본 CSV·메타데이터는 읽기 전용. 현재 폴더는 `datasets/train`과 `datasets/test`의 CSV다.
  2026-10-05 사용자가 분할 완료한 train48(dynamic30+static18)/test19를 확인했다.
  Test 폴더는 그대로 고정한다. 독립 녹화와 같은 실험 내 분할 평가의 구별은 이미 합의했다.
  새 기본 `validation_strategy: per_file_tail`, `validation_fraction: 0.2`는 각 train CSV의
  숫자 행 앞80% 학습/뒤20% 검증이다. 별도 질문 답변이 없어 알린 기본값이며 추후 사용자 답변이 우선한다.
  옵션 없는 과거 설정은 whole_csv를 유지한다. 사용자 요청대로 이번 새 학습은 미실행이다.
  Scaler는 train만, 분할 목록/hash·부모파일/원본시간·세션 관계 및 과거 역할과 중복 보호를 유지한다.
  라벨·timestamp 보정/제외는 `hrm_force/dataset_contracts.json`의 확인된 정확한 hash만 허용한다.
- F/T NaN/Inf/비수치는 무부하나 0으로 채우지 않는다.
  2026-10-05 최신 사용자 합의는 valid flag 확인 생략, 선택 X/Y의 빈칸·비수치 행 제외 후
  나머지 행을 원래 순서로 이어붙이는 것이다. 결측 전후 연결은 명시적으로 승인했으므로
  과거의 연결 금지 방침으로 되돌리거나 같은 확인을 반복하지 않는다. 원본 행/시간 대응은 보존하며
  서로 다른 파일 및 train/test 역할을 가로지르는 연결은 하지 않는다. 통합 기록34절 참조.
  `preprocessing: numeric_compact`로 구현했다. 옵션 없는 과거 설정/bundle은 기존 audited 정책이다.
  서로 다른 파일과 train/validation/test 경계를 창이 넘지 않으며 scaler는 train 범위만 사용한다.
  원본 행 인덱스 매핑을 CSV/Excel에서 보존한다. 통합 기록35절 참조. set-zero 안정화 자동 검출은 미구현이다.
  추론은 입력이 유효하면 정답 없이도 실행하며 정답 유효성과 평가 범위를 별도로 검사한다.
- 구간 경계는 validation만으로 탐색하고 탐색 점수를 독립 test 성능으로 말하지 않는다.
  정확 ID·구간 recall·무부하 검출·연속 힘 RMSE/MAE를 구분하고 support를 함께 보존한다.
- 결과는 `results/train/날짜_시간`, `results/predict/날짜_시간`. 주요 CSV는 비교표와 예측표 두 개,
  보조 파일은 해당 실행 폴더 내부에 모은다. 원본·기존 결과·부모 체크포인트를 덮어쓰지 않는다.
- 2026-09-29 요청: MATLAB 분석용 정답/예측 Excel은 모델별 시트로 정리한다.
  force 1파일, ID masked/class0 각각 1파일을 train/validation/test 역할별로 나눈다.
  저장된 전처리 정책에 맞는 유효 창만 내보내며 원본 행·시간·연속 구간 식별자를 남긴다.
  ID는 부하 라벨이 확정된 공통 행만 사용하며 GT로 masked 예측을0으로 바꾸지 않는다.
  현재 242조합에서 대표 분기를 고정 파트너 규칙으로 선택하며 재학습·test 기반 선택은 하지 않는다.
- ID18 전용 별도 실험은 `results/train/20260929_181303_id18_only`의 설정/고정 목록을 사용한다.
  다른 ID 녹화 전체를 scaler 전부터 제외했고 class0의 ID0/18만 학습했다.
  단일 ID의 조건부 정확도100%는 위치 식별 성능이 아니다. 이 실험의 모델 선택은
  validation 힘 RMSE 후 `--location-selection-metric load_balanced_accuracy`이며 기존 전체ID 기본 선택은 유지한다.
  Excel 내보내기는 학습된 무부하 방식만 생성하며 새 Excel은 첫 모델 시트를 활성화한다.
- 현지 환경은 `env_hrm_force_estimation`(uv Python3.10.20, torch2.7.1+cu126).
  이 PC의 드라이버 불일치는 `.runtime/nvidia-580.173.02`를 프로세스에만 적용하여 처리한다.
  다른 PC에 이 우회를 강제하지 않는다. 스크립트 `scripts/hrm_python.sh`를 사용할 수 있다.
- 수정 시 적절한 검증을 수행하고 실제 결과만 기록한다. 전체 검증:
  `bash scripts/hrm_python.sh -m unittest discover -s tests -v`.
- 다른 저장소·ROS·카메라·모터는 사용자 요청 없이 실행/수정하지 않는다.
  datasets/results/venv는 Git 제외이므로 clone만으로 전달됐다고 가정하지 않는다.
