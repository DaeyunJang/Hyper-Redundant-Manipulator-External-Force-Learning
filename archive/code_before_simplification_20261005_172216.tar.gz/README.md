# HRM 외력·접촉 위치 추정

케이블 길이 4개, 장력 4개, 상대각 18개로 연속 XYZ 힘과 접촉 위치 확률을 추정한다.
하나의 `HRMEstimator` 안에 독립적인 힘·위치 네트워크를 두며, 기본 설정은
11 × 11 조합과 두 무부하 처리 방식(`masked`, `class0`)을 각각 새로 학습한다.

요청·설계·데이터 검사·실험 결과·다음 작업은 **[통합 작업 기록](docs/CHATGPT_README.md)**
한 곳에서 관리한다. 사용자 설정은 **[configs/train.yaml](configs/train.yaml)** 하나다.

```bash
# 최초 환경 설치: uv가 PATH에 있어야 한다.
bash scripts/setup_environment.sh
source env_hrm_force_estimation/bin/activate

# datasets/train/*.csv의 각 파일 앞80% 학습 / 뒤20% validation
bash scripts/hrm_python.sh train.py --config configs/train.yaml

# 위 실행의 날짜 폴더를 지정: validation으로 선택하고 고정 test 목록 평가
bash scripts/hrm_python.sh predict.py --train-dir results/train/학습날짜_시간

# 저장 모델의 정답/예측을 모델별 Excel 시트로 내보내기 (재학습 없음)
bash scripts/hrm_python.sh scripts/export_model_workbooks.py --train-dir results/train/학습날짜_시간

# 데이터 준비만 실행
bash scripts/hrm_python.sh train.py --config configs/train.yaml --check-data

# 회귀 검증
bash scripts/hrm_python.sh -m unittest discover -s tests -v
```

주요 결과는 학습 폴더의 `comparison.csv`와 예측 폴더의 `predictions.csv`다.
모델·설정·분할·진단·그림은 같은 실행 폴더 내부에 모인다. 기존 결과를 덮어쓰지 않는다.

2026-10-05 현재 `datasets/train` 48개(dynamic30+static18), `datasets/test` 19개를 사용한다.
Test는 사용자가 만든 파일 그대로 고정하고 ID를 따로 떼어내지 않는다. Validation은
`validation_strategy: per_file_tail`, `validation_fraction: 0.2`로 train 각 파일 안에서만 확보한다.
`preprocessing: numeric_compact`는 선택 X/Y의 빈칸·비수치·NaN/Inf 행을 제외한 뒤
원래 순서로 연결한다. Valid flag와 timestamp 간격으로 추가 제외하지 않으며 파일/역할 경계는 유지한다.
새 데이터로 학습은 아직 실행하지 않았다. 이번 검사와 실행 명령은 통합 기록35절에 있다.

2026-09-28 완료 실행: [242조합 비교표](results/train/20260928_221428/comparison.csv),
[test 예측표](results/predict/20260928_224418/predictions.csv).
선택 기준·성능·무부하 분석·구간 해석은 통합 작업 기록의 최종 결과에 정리했다.

MATLAB용 Excel은 역할별 폴더에서 `force_estimation_all_models.xlsx`와
`id_estimation_masked.xlsx`, `id_estimation_class0.xlsx`로 저장한다.
각 파일의 CNN·LSTM 등 모델 시트에는 유효한 공통 행의 정답과 예측이 대응되어 있다.
힘은 mN 단위이며 파일·원본 행·시간·연속 구간·부하 상태 열도 함께 보존한다.
내보내기 구성과 해석은 통합 작업 기록의 13절을 참고한다.
2026-09-29 Excel: [train](results/train/20260929_130543_excel/train/),
[validation](results/train/20260929_130543_excel/validation/),
[test](results/predict/20260929_130543_excel/).
축별 RMSE·MAE 요약: [train/validation](results/train/20260929_171211_axis_rmse/force_axis_metrics.csv),
[test](results/predict/20260929_171211_axis_rmse/force_axis_metrics.csv).

ID18 녹화만 사용한 추가 실험: [학습](results/train/20260929_181303_id18_only/),
[test 요약](results/predict/20260929_181303_id18_only/summary/),
[test 모델별 Excel](results/predict/20260929_181303_id18_only/excel/).
이 실험의 위치 출력은 ID0/18 유무부하 검출이다. 단일ID 조건부 정확도100%를
접촉 위치 식별 성능으로 해석하지 않는다. 결과·재현 설정은 통합 작업 기록17절에 있다.

최신 무부하 라벨 설정은 **fit 평균 offset 보정 + 경계 반폭10% 확대**다.
[범위·포함률 비교 및 ID18 준비 설정](results/train/20260929_185223_mean_zero_range110/), 통합 기록19절 참고.
기존 학습 모델은 이전 교정을 유지한다. 새 기준의 static 제외 끝단11종 비교는 완료했다:
[test 축별 지표](results/predict/20260929_195732_no_static_tip/force_metrics.csv),
[모델별 실측/예측 Excel](results/predict/20260929_195732_no_static_tip/excel/force_estimation_all_models.xlsx).
Validation 선택 GRU의 test XYZ RMSE는147.88 mN이다. 이번에는 dynamic ID18 두 파일을
하나씩 train/validation으로 나눴으므로 기존보다 학습 데이터가 줄었다. 전체 ID 위치 학습은
당시 static 제외 시 녹화1개만 남는 ID1–6 때문에 진행하지 않았다. 통합 기록24절 참고.

기본 힘 모델은 **ID18 tip 전용**이다. 무부하에서도 회귀값을 0으로 바꾸지 않는다.
기록 mN을 학습 N으로 변환하고 저장된 부호를 유지한다. 향후 HRM 제어 연결에서만
역정규화된 XYZ에 -1을 한 번 곱해야 한다. ROS 연결은 이번 구현에 포함되지 않는다.

`datasets/`, `results/`, 가상환경, 로컬 GPU 보조 라이브러리는 Git에서 제외된다.
다른 PC에서는 데이터·결과를 별도로 옮기고 환경을 다시 설치한다.
정리한 이전 문서와 설정은 [역사 자료 압축본](archive/legacy_materials_20260928.tar.gz)에 보존했다.
