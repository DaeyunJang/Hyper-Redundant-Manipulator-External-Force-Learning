"""Render independent HRM comparison/replay figures without modifying result CSVs.

Example:
    python scripts/plot_independent_results.py --train-dir results/train/RUN \
        --predict-dir results/predict/RUN

Repeated pair runs are summarized by median and min/max, not confidence
intervals or independent-seed uncertainty. Test curves retain raw force signs
and amplitudes. Missing rows, invalid values, and time gaps split each trace.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
import numpy as np
import pandas as pd


AXES = ("fx", "fy", "fz")
MODE_COLORS = {"masked": "#2166ac", "class0": "#b2182b"}
REGION_COLORS = {"lower": "#0072b2", "middle": "#d55e00", "upper": "#009e73"}


def _boolean(series: pd.Series) -> np.ndarray:
    return series.astype(str).str.lower().isin(["true", "1", "1.0"]).to_numpy()


def _number(frame: pd.DataFrame, column: str) -> np.ndarray:
    if column not in frame:
        return np.full(len(frame), np.nan)
    return pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)


def _require(frame: pd.DataFrame, columns: list[str], label: str) -> None:
    missing = set(columns) - set(frame)
    if missing:
        raise ValueError(f"{label} missing required columns: {sorted(missing)}")


def continuous_parts(frame: pd.DataFrame, valid: np.ndarray,
                     gap_factor: float = 1.5) -> list[np.ndarray]:
    """Return positions that are adjacent in both original row and sensor time."""
    time = _number(frame, "elapsed_s")
    source_row = _number(frame, "source_row")
    differences = np.diff(time)
    positive = differences[np.isfinite(differences) & (differences > 0)]
    median = float(np.median(positive)) if len(positive) else float("nan")
    valid = np.asarray(valid, dtype=bool) & np.isfinite(time) & np.isfinite(source_row)
    positions = np.flatnonzero(valid)
    if not len(positions):
        return []
    previous, following = positions[:-1], positions[1:]
    contiguous = ((following - previous == 1)
                  & (source_row[following] - source_row[previous] == 1)
                  & (time[following] > time[previous]))
    if np.isfinite(median):
        contiguous &= time[following] - time[previous] <= median * gap_factor
    return np.split(positions, np.flatnonzero(~contiguous) + 1)


def _plot_trace(axis, frame: pd.DataFrame, values: np.ndarray, valid: np.ndarray,
                gap_factor: float, **style) -> bool:
    time = _number(frame, "elapsed_s")
    parts = continuous_parts(frame, valid & np.isfinite(values), gap_factor)
    for index, positions in enumerate(parts):
        line_style = dict(style)
        if index:
            line_style.pop("label", None)
        if len(positions) == 1:
            line_style.update(marker=".", markersize=2)
        axis.plot(time[positions], values[positions], **line_style)
    return bool(parts)


def _save(figure, destination: Path, dpi: int) -> Path:
    figure.savefig(destination, dpi=dpi, facecolor="white", bbox_inches="tight")
    plt.close(figure)
    return destination


def _summary(frame: pd.DataFrame, group: str, metric: str,
             order: list[str]) -> tuple[np.ndarray, np.ndarray]:
    grouped = frame.groupby(group)[metric].agg(["median", "min", "max"]).reindex(order)
    center = grouped["median"].to_numpy(dtype=float)
    span = np.vstack([center - grouped["min"].to_numpy(dtype=float),
                      grouped["max"].to_numpy(dtype=float) - center])
    return center, span


def plot_training(train_dir: Path, dpi: int = 180) -> list[Path]:
    frame = pd.read_csv(train_dir / "comparison.csv")
    _require(frame, ["force_model", "location_model", "mode", "force_rmse_xyz_mN",
                     "force_mae_xyz_mN", "location_macro_recall", "region_accuracy"], "comparison.csv")
    if "status" in frame:
        frame = frame.loc[frame["status"] == "complete"]
    if frame.empty:
        raise ValueError("No completed comparison rows to plot")
    destination = train_dir / "figures"
    destination.mkdir(parents=True, exist_ok=True)
    paths = []
    force_order = frame.groupby("force_model")["force_rmse_xyz_mN"].median().sort_values().index.tolist()
    x = np.arange(len(force_order))
    colors = ["#0072b2", "#d55e00", "#009e73", "#333333"]
    figure, axes = plt.subplots(2, 1, figsize=(max(10, len(force_order) * 1.0), 8), sharex=True,
                                constrained_layout=True)
    for plot_axis, metric in zip(axes, ("rmse", "mae")):
        suffixes = [name for name in (*AXES, "xyz") if f"force_{metric}_{name}_mN" in frame]
        width = 0.8 / len(suffixes)
        for index, name in enumerate(suffixes):
            values, spread = _summary(frame, "force_model", f"force_{metric}_{name}_mN", force_order)
            plot_axis.bar(x + (index - (len(suffixes) - 1) / 2) * width, values, width,
                          yerr=spread, capsize=2, color=colors[index], alpha=0.9,
                          label="XYZ pooled" if name == "xyz" else name.capitalize())
        plot_axis.set_ylabel(f"Validation {metric.upper()} (mN)")
        plot_axis.set_ylim(bottom=0)
        plot_axis.grid(axis="y", alpha=0.2)
        plot_axis.set_axisbelow(True)
    axes[0].legend(ncol=4, frameon=False)
    axes[-1].set_xticks(x, force_order, rotation=35, ha="right")
    axes[-1].set_xlabel("Force model")
    figure.suptitle("Force validation errors\nMedian across independently trained pair runs; whiskers = min/max (not confidence intervals)", fontsize=11)
    paths.append(_save(figure, destination / "validation_force_errors.png", dpi))

    modes = [mode for mode in ("masked", "class0") if mode in set(frame["mode"])]
    location_order = frame.groupby("location_model")["location_macro_recall"].median().sort_values(ascending=False).index.tolist()
    x = np.arange(len(location_order))
    figure, axes = plt.subplots(2, 1, figsize=(max(10, len(location_order) * 1.0), 8), sharex=True,
                                constrained_layout=True)
    width = 0.8 / max(1, len(modes))
    for plot_axis, metric, label in zip(axes, ("location_macro_recall", "region_accuracy"),
                                      ("Exact ID macro recall (%)", "Baseline region accuracy (%)")):
        for index, mode in enumerate(modes):
            values, spread = _summary(frame.loc[frame["mode"] == mode], "location_model", metric, location_order)
            plot_axis.bar(x + (index - (len(modes) - 1) / 2) * width, values * 100, width,
                          yerr=spread * 100, capsize=2, color=MODE_COLORS[mode], label=mode, alpha=0.9)
        plot_axis.set_ylabel(label)
        plot_axis.set_ylim(0, 100)
        plot_axis.grid(axis="y", alpha=0.2)
        plot_axis.set_axisbelow(True)
    axes[0].legend(frameon=False)
    axes[-1].set_xticks(x, location_order, rotation=35, ha="right")
    axes[-1].set_xlabel("Location model")
    figure.suptitle("Location validation: GT-loaded, supported-ID diagnostics\nMedian and min/max across force partners; region accuracy is an observed score, not a probability", fontsize=11)
    paths.append(_save(figure, destination / "validation_location_accuracy.png", dpi))
    return paths


def _filename(source: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", Path(source).stem)
    return f"{stem}_{hashlib.sha256(source.encode()).hexdigest()[:8]}"


def _force_values(frame: pd.DataFrame, kind: str, name: str) -> np.ndarray:
    column = f"{kind}_{name}_mN"
    return _number(frame, column) if column in frame else _number(frame, f"{kind}_{name}_N") * 1000.0


def plot_force_replay(frame: pd.DataFrame, source: str, destination: Path,
                      gap_factor: float, dpi: int) -> Path:
    groups = {mode: group.sort_values("source_row", kind="stable").reset_index(drop=True)
              for mode, group in frame.groupby("mode", sort=False)}
    reference = next(iter(groups.values()))
    target_valid = _boolean(reference["force_target_valid"]) if "force_target_valid" in reference else np.ones(len(reference), dtype=bool)
    figure, axes = plt.subplots(3, 1, figsize=(13, 8), sharex=True, constrained_layout=True)
    any_target = False
    for axis, name in zip(axes, AXES):
        any_target |= _plot_trace(axis, reference, _force_values(reference, "true", name), target_valid,
                                 gap_factor, color="#222222", linewidth=1.0, alpha=0.9, label="Reference F/T")
        for mode, group in groups.items():
            ready = _boolean(group["force_ready"]) if "force_ready" in group else np.ones(len(group), dtype=bool)
            model = str(group["force_model"].iloc[0]) if "force_model" in group else "force"
            _plot_trace(axis, group, _force_values(group, "pred", name), ready, gap_factor,
                        color=MODE_COLORS.get(mode, "#009e73"), linewidth=0.9,
                        linestyle="--" if mode == "class0" else "-", alpha=0.85,
                        label=f"{mode} / {model} (raw)")
        axis.set_ylabel(f"{name.capitalize()} (mN)")
        axis.grid(alpha=0.2)
    axes[0].legend(loc="upper right", frameon=True, fontsize=8)
    axes[-1].set_xlabel("Time from CSV start (s)")
    scope_unverified = ("force_scope_verified" in frame and not _boolean(frame["force_scope_verified"]).all())
    notes = ["Raw force predictions; no forced zeros"]
    if scope_unverified:
        notes.append("force application scope unverified for some/all rows")
    if not any_target:
        notes.append("reference force unavailable")
    figure.suptitle(f"{Path(source).name}\n" + "; ".join(notes), fontsize=11)
    return _save(figure, destination / f"{_filename(source)}_force.png", dpi)


def _time_edges(time: np.ndarray, fallback_dt: float) -> np.ndarray:
    if len(time) == 1:
        return np.array([time[0] - fallback_dt / 2, time[0] + fallback_dt / 2])
    midpoints = (time[1:] + time[:-1]) / 2
    return np.r_[time[0] - (time[1] - time[0]) / 2, midpoints,
                 time[-1] + (time[-1] - time[-2]) / 2]


def plot_location_replay(frame: pd.DataFrame, source: str, mode: str,
                         destination: Path, gap_factor: float, dpi: int) -> Path:
    frame = frame.sort_values("source_row", kind="stable").reset_index(drop=True)
    time = _number(frame, "elapsed_s")
    ready = _boolean(frame["location_ready"]) if "location_ready" in frame else np.ones(len(frame), dtype=bool)
    probability = np.column_stack([_number(frame, f"p{segment}") for segment in range(1, 19)])
    ready &= np.isfinite(probability).any(axis=1)
    positive = np.diff(time)
    positive = positive[np.isfinite(positive) & (positive > 0)]
    dt = float(np.median(positive)) if len(positive) else 1.0
    figure, axes = plt.subplots(3, 1, figsize=(13, 9), sharex=True,
                                gridspec_kw={"height_ratios": [4, 1.3, 2]}, constrained_layout=True)
    colormap = plt.get_cmap("viridis").copy()
    colormap.set_bad("#eeeeee")
    axes[0].set_facecolor("#eeeeee")
    for positions in continuous_parts(frame, ready, gap_factor):
        axes[0].pcolormesh(_time_edges(time[positions], dt), np.arange(0.5, 19.5),
                           np.ma.masked_invalid(probability[positions].T), cmap=colormap,
                           vmin=0, vmax=1, shading="flat", rasterized=True)
    figure.colorbar(ScalarMappable(norm=Normalize(0, 1), cmap=colormap), ax=axes[0],
                   label="Original segment probability (not accuracy)", pad=0.01)
    axes[0].set_yticks(np.arange(1, 19))
    axes[0].set_ylabel("Segment ID")
    axes[0].set_ylim(0.5, 18.5)
    axes[0].set_title("Fixed 0–1 color scale; gray = unavailable / unsupported / gap", fontsize=10)
    if mode == "class0":
        _plot_trace(axes[1], frame, _number(frame, "p0"), ready, gap_factor,
                    color=MODE_COLORS[mode], linewidth=1.0, label="p0: no-load probability")
        if "load_state_gt" in frame:
            known = frame["load_state_gt"].isin(["loaded", "unloaded"]).to_numpy()
            gt = frame["load_state_gt"].eq("unloaded").to_numpy(dtype=float)
            axes[1].scatter(time[known], gt[known], marker=".", s=2, color="black", alpha=0.25,
                            label="GT unloaded (threshold label)", rasterized=True)
        axes[1].legend(loc="upper right", fontsize=8)
    else:
        axes[1].text(0.5, 0.5, "p0 unavailable — masked is unverified; no deployment load detector",
                     transform=axes[1].transAxes, ha="center", va="center", fontsize=10)
    axes[1].set_ylabel("No-load\nprobability")
    axes[1].set_ylim(-0.04, 1.04)
    axes[1].grid(alpha=0.2)
    region_plotted = False
    for prefix, style in (("baseline", "-"), ("optimized", "--")):
        for name, color in REGION_COLORS.items():
            column = f"{prefix}_region_{name}_probability"
            if column not in frame:
                continue
            region_plotted |= _plot_trace(axes[2], frame, _number(frame, column), ready, gap_factor,
                                           color=color, linewidth=0.9, linestyle=style,
                                           label=f"{prefix}: {name}")
    if region_plotted:
        axes[2].legend(loc="upper right", ncol=3, fontsize=7, framealpha=0.85)
    else:
        axes[2].text(0.5, 0.5, "Region probabilities unavailable", ha="center", va="center", transform=axes[2].transAxes)
    axes[2].set_ylabel("Region probability\nsum (not accuracy)")
    axes[2].set_ylim(-0.04, 1.04)
    axes[2].set_xlabel("Time from CSV start (s)")
    axes[2].grid(alpha=0.2)
    model = str(frame["location_model"].iloc[0]) if "location_model" in frame else "location"
    meaning = "conditional diagnostic; deployment unverified" if mode == "masked" else "original class0 probabilities; segment sum = 1 − p0"
    figure.suptitle(f"{Path(source).name} | {mode} / {model}\n{meaning}", fontsize=11)
    return _save(figure, destination / f"{_filename(source)}_{mode}_location.png", dpi)


def plot_prediction(predict_dir: Path, gap_factor: float = 1.5, dpi: int = 180) -> list[Path]:
    frame = pd.read_csv(predict_dir / "predictions.csv", dtype={"source_time_ns": str}, low_memory=False)
    _require(frame, ["source_file", "source_row", "elapsed_s", "mode"], "predictions.csv")
    if frame.empty:
        raise ValueError("No prediction rows to plot")
    destination = predict_dir / "figures"
    destination.mkdir(parents=True, exist_ok=True)
    paths = []
    for source, rows in frame.groupby("source_file", sort=False):
        paths.append(plot_force_replay(rows, source, destination, gap_factor, dpi))
        for mode, group in rows.groupby("mode", sort=True):
            paths.append(plot_location_replay(group, source, mode, destination, gap_factor, dpi))
    return paths


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-dir", type=Path)
    parser.add_argument("--predict-dir", type=Path)
    parser.add_argument("--gap-factor", type=float, default=1.5,
                        help="Break traces above this multiple of the median positive sample interval")
    parser.add_argument("--dpi", type=int, default=180)
    args = parser.parse_args(argv)
    if args.train_dir is None and args.predict_dir is None:
        parser.error("At least one of --train-dir or --predict-dir is required")
    if not np.isfinite(args.gap_factor) or args.gap_factor <= 1:
        parser.error("--gap-factor must be finite and greater than 1")
    if args.dpi < 50:
        parser.error("--dpi must be at least 50")
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False,
                         "axes.spines.right": False, "savefig.dpi": args.dpi})
    for role, directory in (("train", args.train_dir), ("predict", args.predict_dir)):
        if directory is None:
            continue
        directory = directory.resolve()
        paths = plot_training(directory, args.dpi) if role == "train" else plot_prediction(directory, args.gap_factor, args.dpi)
        manifest = {"source_directory": str(directory), "figures": [path.name for path in paths],
                    "gap_factor": args.gap_factor, "dpi": args.dpi,
                    "source_results_modified": False,
                    "probability_color_limits": [0, 1],
                    "pair_run_whiskers": "minimum and maximum; not confidence intervals"}
        (directory / "figures" / "plot_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        print(f"{role}: {len(paths)} figures saved in {directory / 'figures'}")


if __name__ == "__main__":
    main()
