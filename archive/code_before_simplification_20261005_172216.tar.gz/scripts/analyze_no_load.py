#!/usr/bin/env python3
"""Read-only raw/Kalman no-load diagnostics; freeze validation2 thresholds.

Writes exactly analysis.json and no_load.png into one fresh timestamp directory.
The separately recorded validation1 data never fits or changes the thresholds.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime
import json
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from hrm_force.data import json_write, sha256
from hrm_force.independent_data import (
    _frame, _force_contract, _times, _timing_audit, _timing_columns, _validity,
    calibrate_no_load, load_config,
)


OLD_HALF_WIDTH_MN = np.array([45.4, 43.6, 72.9])


def read_forces(path, config):
    prefix, columns = _force_contract(config)
    flags = [f"{prefix}.matched", f"{prefix}.aligned_force_valid"]
    frame_col = f"{prefix}.aligned_frame_id"
    frame = _frame(path, columns + flags + [frame_col, "source_time_ns", "bag_receive_time_ns"]
                   + _timing_columns([prefix]))
    values, valid, reasons = _validity(frame, columns, flags, [prefix], config, frame_col)
    time_bad, timing = _timing_audit(frame, [prefix], config)
    valid &= ~time_bad
    times, origin, _ = _times(frame)
    return {"values_mN": values, "valid": valid, "seconds": times / 1e9,
            "rows": len(values), "invalid_rows": int((~valid).sum()),
            "invalid_reasons_overlapping": reasons, "timing": timing,
            "timestamp_origin_ns": origin}


def distribution(values):
    return {"rows": len(values), "mean_mN": values.mean(0), "median_mN": np.median(values, axis=0),
            "std_mN": values.std(0, ddof=1), "minimum_mN": values.min(0), "maximum_mN": values.max(0),
            "q005_mN": np.quantile(values, .005, axis=0), "q995_mN": np.quantile(values, .995, axis=0),
            "axis_correlation": np.corrcoef(values.T)}


def coverage(values_mN, calibration):
    scores = np.max(np.abs(values_mN / 1000 - calibration["center_N"])
                    / np.asarray(calibration["scale_N"]), axis=1)
    off, on = calibration["off_score"], calibration["on_score"]
    return {"rows": len(scores), "unloaded_fraction": float(np.mean(scores <= off)),
            "uncertain_fraction": float(np.mean((scores > off) & (scores < on))),
            "loaded_false_alarm_fraction": float(np.mean(scores >= on)),
            "inside_on_threshold_fraction": float(np.mean(scores < on)),
            "maximum_score": float(np.max(scores)),
            "score_q95": float(np.quantile(scores, .95)), "score_q995": float(np.quantile(scores, .995))}


def legacy_coverage(values_mN):
    outside = np.abs(values_mN) > OLD_HALF_WIDTH_MN
    return {"zero_centered_half_width_mN": OLD_HALF_WIDTH_MN,
            "loaded_false_alarm_fraction": float(np.mean(outside.any(1))),
            "axis_outside_fraction": outside.mean(0),
            "unloaded_fraction": float(np.mean(~outside.any(1))),
            "interpretation": "historical Kalman 1-sigma box; raw application is diagnostic only"}


def drift(record, calibration):
    rows = np.flatnonzero(record["valid"])
    values, times = record["values_mN"][rows], record["seconds"][rows]
    centered_time = times - times.mean()
    slope = (centered_time[:, None] * (values - values.mean(0))).sum(0) / np.square(centered_time).sum()
    blocks = []
    for indices in np.array_split(rows, 4):
        block = record["values_mN"][indices]
        blocks.append({"start_s": float(record["seconds"][indices[0]]),
                       "end_s": float(record["seconds"][indices[-1]]),
                       **distribution(block), "new_threshold_coverage": coverage(block, calibration)})
    consecutive = np.diff(rows) == 1
    autocorrelation = [float(np.corrcoef(values[:-1, axis][consecutive], values[1:, axis][consecutive])[0, 1])
                       for axis in range(3)]
    return {"linear_slope_mN_per_minute": slope * 60,
            "last_minus_first_quarter_median_mN": blocks[-1]["median_mN"] - blocks[0]["median_mN"],
            "adjacent_valid_row_autocorrelation": autocorrelation, "quarter_blocks": blocks,
            "interpretation": "descriptive within-recording drift; correlated rows are not independent replicates"}


def metadata(folder, tracked):
    session_path, config_path = folder / "session.json", folder / "recording_config.json"
    for path in (session_path, config_path):
        tracked[path] = sha256(path)
    session, config = json.loads(session_path.read_text()), json.loads(config_path.read_text())
    snapshot = session["snapshot"]
    filter_keys = ["set_lpf", "set_maf", "lpf_weight", "maf_buffer_size"]
    observed = snapshot.get("last_observed_filter_setting", {}).get("message", {})
    filters = []
    for path in folder.joinpath("csv").glob("data_filter_setting__*.csv"):
        tracked[path] = sha256(path)
        frame = pd.read_csv(path, usecols=filter_keys)
        filters.extend(frame.drop_duplicates().to_dict("records"))
    offsets = []
    offset_columns = [f"wrench.force.{axis}" for axis in "xyz"]
    for path in folder.joinpath("csv").glob("fts_data_offset__*.csv"):
        tracked[path] = sha256(path)
        frame = pd.read_csv(path, usecols=offset_columns)
        values = frame.to_numpy(float)
        offsets.append({"path": str(path.relative_to(ROOT)), "rows": len(values),
                        "coordinate_frame": "sensor", "source_unit": "mN",
                        "first_force_offset": values[0].tolist(), "last_force_offset": values[-1].tolist(),
                        "distinct_force_offsets": len(frame.drop_duplicates())})
    serial = snapshot.get("runtime_parameters", {}).get("nodes", {}).get("/serial_read", {})
    serial_values = {key: value.get("value") for key, value in serial.get("parameters", {}).items()}
    return {"session_id": session["session_id"], "start_requested_local": session.get("start_requested_local"),
            "force_alignment_snapshot": snapshot.get("force_alignment"),
            "recording_force_alignment_defaults": config.get("force_alignment"),
            "summary_max_matching_skew_ms": config.get("summary_csv", {}).get("max_time_difference_ms"),
            "source_unit_statement": config.get("notes", {}).get("source_units", {}).get("fts_force"),
            "initial_observed_filter": {key: observed.get(key) for key in filter_keys},
            "recorded_filter_settings": filters, "force_offsets": offsets,
            "serial_runtime_parameter_status": serial.get("status"), "serial_runtime_parameters": serial_values,
            "kalman_process_measurement_parameters": "not exposed in captured serial runtime parameters"}


def plot(records, calibrations, result, output):
    fig, axes = plt.subplots(3, 2, figsize=(15, 10), sharex="col")
    colors = ["tab:blue", "tab:orange", "tab:green"]
    for column, name in enumerate(("validation2", "validation1")):
        raw, kalman = records[name]["raw"], records[name]["kalman"]
        cal = calibrations["kalman"]
        for axis in range(3):
            ax = axes[axis, column]
            for record, color, label, alpha, width in ((raw, "0.65", "Raw aligned", .55, .55),
                                                       (kalman, colors[axis], "Kalman aligned", .9, .8)):
                values = record["values_mN"][:, axis].copy()
                values[~record["valid"]] = np.nan
                step = max(1, len(values) // 4000)
                ax.plot(record["seconds"][::step], values[::step], color=color, label=label, alpha=alpha, lw=width)
            ax.axhspan(cal["off_lower_N"][axis] * 1000, cal["off_upper_N"][axis] * 1000,
                       color="green", alpha=.12, label="New unloaded band")
            for index, bound in enumerate((cal["on_lower_N"][axis], cal["on_upper_N"][axis])):
                ax.axhline(bound * 1000, color="firebrick", ls="--", lw=1.1,
                           label="New loaded boundary" if index == 0 else None)
            for index, bound in enumerate((-OLD_HALF_WIDTH_MN[axis], OLD_HALF_WIDTH_MN[axis])):
                ax.axhline(bound, color="black", ls=":", lw=.8,
                           label="Historical zero-centered 1-sigma" if index == 0 else None)
            if name == "validation2":
                cut_time = kalman["seconds"][cal["split_row"]]
                ax.axvline(cut_time, color="purple", lw=1.1, label="70% fit / 30% holdout")
            ax.set_ylabel(f"F{'xyz'[axis]} [mN]")
            ax.grid(alpha=.15)
            if axis == 0:
                suffix = "calibration + temporal holdout" if name == "validation2" else "separate recording; unchanged bounds"
                ax.set_title(f"{name}: {suffix}")
            if axis == 2:
                ax.set_xlabel("Elapsed time [s]")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, ncol=3, loc="lower center", fontsize=9)
    hold = result["sources"]["kalman"]["calibration"]["holdout_coverage"]
    independent = result["sources"]["kalman"]["validation1"]["new_threshold_coverage"]
    fig.suptitle("Measured no-load: fixed validation2 Kalman bounds\n"
                 f"New false alarm / uncertain: holdout {hold['loaded_false_alarm_fraction']:.2%} / {hold['uncertain_fraction']:.2%}; "
                 f"validation1 {independent['loaded_false_alarm_fraction']:.2%} / {independent['uncertain_fraction']:.2%}", fontsize=13)
    fig.tight_layout(rect=(0, .065, 1, .93))
    fig.savefig(output / "no_load.png", dpi=160)
    plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--output")
    args = parser.parse_args(argv)
    config = load_config(args.config)
    output = Path(args.output) if args.output else ROOT / "results" / "train" / (
        datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d_%H%M%S") + "_no_load_analysis")
    output.mkdir(parents=True, exist_ok=False)
    folders = {"validation2": ROOT / "datasets/aidin_FT_sensor_validation_2",
               "validation1": ROOT / "datasets/aidin_FT_sensor_validation_1"}
    tracked = {folder / "csv/summary.csv": sha256(folder / "csv/summary.csv") for folder in folders.values()}
    settings = {name: metadata(folder, tracked) for name, folder in folders.items()}
    result = {"analysis": "read_only_no_load_distribution_and_frozen_threshold_transfer",
              "primary_training_source": "kalman", "calibration_recording": "validation2",
              "supplementary_recording": "validation1", "thresholds_refit_on_supplementary_recording": False,
              "metadata": settings, "metadata_comparison": {}, "sources": {},
              "limitations": [
                  "This evaluates false alarms on known no-load recordings; sensitivity to small real loads is not measured.",
                  "Temporal holdout rows and neighboring rows are correlated; rates are empirical coverage, not confidence intervals.",
                  "Validation1 is a separate recording approximately two minutes later, not a different-day/environment validation.",
                  "Recorded force offsets differ; matching frame and LPF/MAF settings do not establish identical tare or Kalman state.",
                  "No per-trial regression targets or offsets are changed. Calibration center affects derived load labels only.",
                  "Raw thresholds are analyzed separately; Kalman thresholds are never described as calibrated for raw force.",
                  "Recorded sensor units remain the project's mN convention; this analysis does not independently verify physical calibration.",
              ]}
    for key in ("force_alignment_snapshot", "summary_max_matching_skew_ms", "source_unit_statement",
                "initial_observed_filter", "recorded_filter_settings", "serial_runtime_parameters"):
        result["metadata_comparison"][key + "_equal"] = settings["validation2"][key] == settings["validation1"][key]
    records = {name: {} for name in folders}
    calibrations = {}
    for source in ("raw", "kalman"):
        source_config = copy.deepcopy(config)
        source_config["force_source"] = source
        prefix = "fts" if source == "raw" else "fts_kalman"
        source_config["force_columns"] = [f"{prefix}.aligned_f{axis}" for axis in "xyz"]
        source_config["calibration"]["path"] = str(folders["validation2"] / "csv/summary.csv")
        calibration = calibrate_no_load(source_config)
        calibrations[source] = calibration
        result["sources"][source] = {"calibration": calibration}
        for name, folder in folders.items():
            record = read_forces(folder / "csv/summary.csv", source_config)
            records[name][source] = record
            values = record["values_mN"][record["valid"]]
            result["sources"][source][name] = {
                "rows": record["rows"], "invalid_rows": record["invalid_rows"],
                "duration_s": float(record["seconds"][-1] - record["seconds"][0]),
                "distribution": distribution(values), "new_threshold_coverage": coverage(values, calibration),
                "historical_threshold_coverage": legacy_coverage(values), "drift": drift(record, calibration),
                "timing_audit": record["timing"],
            }
        ref = result["sources"][source]["validation2"]["distribution"]
        later = result["sources"][source]["validation1"]["distribution"]
        result["sources"][source]["validation1_minus_validation2_median_mN"] = later["median_mN"] - ref["median_mN"]
    for name in folders:
        raw = result["sources"]["raw"][name]["distribution"]["std_mN"]
        filtered = result["sources"]["kalman"][name]["distribution"]["std_mN"]
        result.setdefault("kalman_to_raw_std_ratio", {})[name] = filtered / raw
    plot(records, calibrations, result, output)
    if any(sha256(path) != before for path, before in tracked.items()):
        raise RuntimeError("An input file changed during analysis")
    result["original_hashes_verified_unchanged"] = {str(path.relative_to(ROOT)): before for path, before in tracked.items()}
    json_write(output / "analysis.json", result)
    print(output)
    for source in ("raw", "kalman"):
        item = result["sources"][source]
        print(source, "center_mN", np.asarray(item["calibration"]["center_N"]) * 1000,
              "off_half_width_mN", np.asarray(item["calibration"]["off_half_width_N"]) * 1000,
              "on_half_width_mN", np.asarray(item["calibration"]["on_half_width_N"]) * 1000)
        print("holdout", item["calibration"]["holdout_coverage"])
        print("validation1", item["validation1"]["new_threshold_coverage"])
        print("historical false alarms", {name: item[name]["historical_threshold_coverage"]["loaded_false_alarm_fraction"] for name in folders})


if __name__ == "__main__":
    main()
