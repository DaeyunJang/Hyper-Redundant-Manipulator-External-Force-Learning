"""Measure selected bundles' batch-one forward time; no sensor/I/O latency claim."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hrm_force.runtime import ensure_driver_runtime
ensure_driver_runtime()

import numpy as np
import torch
from hrm_force.independent_engine import restore_bundle, write_json


@torch.inference_mode()
def measure(checkpoint, device, samples, warmup):
    model, bundle = restore_bundle(checkpoint, device)
    raw = torch.zeros((1, bundle['config']['window_samples'], bundle['input_dim']), device=device)
    scales = {
        branch: {key: torch.tensor(value, dtype=torch.float32, device=device)
                 for key, value in bundle['scalers'][branch].items()}
        for branch in ('force', 'location')
    }

    def forward():
        f, p = scales['force'], scales['location']
        xyz = model.force_net((raw - f['x_mean']) / f['x_std']) * f['y_std'] + f['y_mean']
        probability = model.location_net((raw - p['x_mean']) / p['x_std']).softmax(-1)
        return xyz, probability

    for _ in range(warmup):
        forward()
    if device == 'cuda':
        torch.cuda.synchronize()
    durations = []
    for _ in range(samples):
        start = time.perf_counter_ns()
        xyz, probability = forward()
        if device == 'cuda':
            torch.cuda.synchronize()
        durations.append((time.perf_counter_ns() - start) / 1e6)
    if not torch.isfinite(xyz).all() or not torch.isfinite(probability).all():
        raise ValueError('Nonfinite benchmark output')
    return {
        'device': device, 'mode': bundle['mode'], 'force_model': bundle['force_name'],
        'location_model': bundle['location_name'], 'checkpoint': str(checkpoint),
        'batch': 1, 'window': bundle['config']['window_samples'], 'input_dim': bundle['input_dim'],
        'threads': torch.get_num_threads(), 'warmup': warmup, 'samples': samples,
        'median_ms': float(np.median(durations)), 'p95_ms': float(np.quantile(durations, .95)),
        'minimum_ms': float(np.min(durations)), 'maximum_ms': float(np.max(durations)),
        'cudnn_benchmark': torch.backends.cudnn.benchmark,
        'cudnn_deterministic': torch.backends.cudnn.deterministic,
        'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--predict-dir', required=True, type=Path)
    parser.add_argument('--samples', type=int, default=100)
    parser.add_argument('--warmup', type=int, default=20)
    args = parser.parse_args()
    if args.samples < 1 or args.warmup < 0:
        parser.error('samples must be positive and warmup nonnegative')
    report = json.loads((args.predict_dir / 'metrics.json').read_text())
    measurements = []
    for item in report['selection']:
        for device in ['cpu'] + (['cuda'] if torch.cuda.is_available() else []):
            measurements.append(measure(Path(item['checkpoint']), device, args.samples, args.warmup))
    output = args.predict_dir / 'inference_timing.json'
    write_json(output, {
        'measurement': 'Synchronized wall time of both independent networks, branch X scaling, force inverse scaling and location softmax.',
        'limitations': [
            'Synthetic zero input, already on target device; a compute benchmark, not an accuracy experiment.',
            'Excludes sensor/filter delay, first 30-row history collection, parsing, disk I/O, host/device transfer and ROS scheduling.',
            'No real-time deadline or end-to-end latency guarantee; hardware and other workloads affect timings.',
        ],
        'torch': str(torch.__version__),
        'gpu': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'measurements': measurements,
    })
    print(output)


if __name__ == '__main__':
    main()
