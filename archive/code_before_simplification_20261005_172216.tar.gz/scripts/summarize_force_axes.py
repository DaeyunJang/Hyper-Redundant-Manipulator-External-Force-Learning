#!/usr/bin/env python3
"""Calculate per-axis metrics directly from the frozen model-sheet workbooks."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import posixpath
import re
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
AXES = ('fx', 'fy', 'fz')
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def sheet_paths(archive):
    workbook = ET.fromstring(archive.read('xl/workbook.xml'))
    targets = {item.attrib['Id']: posixpath.normpath(posixpath.join('xl', item.attrib['Target']))
               for item in ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))}
    return {sheet.attrib['name']: targets[sheet.attrib[f'{{{REL}}}id']]
            for sheet in workbook.find('s:sheets', NS)}


def read_table(archive, member, count):
    # This reader intentionally targets this repository's audited inline-string XLSX writer.
    content = archive.read(member)
    header = re.search(rb'<row r="1"[^>]*>.*?</row>', content)
    first = header.group()
    columns = {cell.findtext('is/t'): re.match(r'[A-Z]+', cell.attrib['r']).group()
               for cell in ET.fromstring(first)}
    content = content[header.end():]
    result = {}
    for name, column in columns.items():
        if name == 'load_state':
            pattern = rb'<c r="' + column.encode() + rb'(\d+)"[^>]*><is><t>([^<]+)</t></is></c>'
            values = re.findall(pattern, content)
            array = np.asarray([value.decode() for _, value in values])
        else:
            pattern = rb'<c r="' + column.encode() + rb'(\d+)"[^>]*><v>([^<]+)</v></c>'
            values = re.findall(pattern, content)
            array = np.asarray([float(value) for _, value in values], dtype=np.float64)
            if not np.isfinite(array).all():
                raise ValueError(f'Nonfinite value in {member}: {name}')
        rows = np.asarray([int(row) for row, _ in values])
        if not np.array_equal(rows, np.arange(2, count + 2)):
            raise ValueError(f'Missing or out-of-order cells in {member}: {name}')
        result[name] = array
    return pd.DataFrame(result)


def metrics(truth, prediction):
    if truth.shape != prediction.shape or truth.ndim != 2 or truth.shape[1] != 3:
        raise ValueError('Expected aligned Nx3 ground truth and prediction')
    if not len(truth) or not np.isfinite(truth).all() or not np.isfinite(prediction).all():
        raise ValueError('Expected nonempty, finite force rows')
    error = prediction - truth
    rmse = np.sqrt(np.mean(error ** 2, axis=0))
    output = {'samples': len(truth)}
    for j, axis in enumerate(AXES):
        output[f'rmse_{axis}_mN'] = float(rmse[j])
        output[f'mae_{axis}_mN'] = float(np.mean(np.abs(error[:, j])))
        output[f'bias_{axis}_mN'] = float(np.mean(error[:, j]))
        output[f'gt_std_{axis}_mN'] = float(np.std(truth[:, j]))
    output['rmse_xyz_mN'] = float(np.sqrt(np.mean(error ** 2)))
    if not np.isclose(output['rmse_xyz_mN'] ** 2, np.mean(rmse ** 2), rtol=1e-12):
        raise ValueError('Pooled and per-axis RMSE identity failed')
    return output


def summarize(manifest_path):
    manifest_path = Path(manifest_path).resolve()
    manifest = json.loads(manifest_path.read_text())
    if manifest['status'] != 'complete':
        raise ValueError('Only completed workbook exports can be summarized')
    comparison = pd.read_csv(Path(manifest['source_training_run']) / 'comparison.csv')
    records, details, sources = [], [], []
    max_validation_difference = 0.0
    for book in manifest['workbooks']:
        if book['branch'] != 'force':
            continue
        path, role = Path(book['path']), book['role']
        if digest(path) != book['sha256']:
            raise ValueError(f'Workbook changed since export: {path}')
        sources.append({'role': role, 'path': str(path), 'sha256': book['sha256']})
        common = None
        with zipfile.ZipFile(path) as archive:
            sheets = sheet_paths(archive)
            for entry in book['sheets']:
                name = entry['sheet']
                frame = read_table(archive, sheets[name], entry['rows'])
                cohort_columns = [f'gt_{axis}_mN' for axis in AXES] + ['file_id', 'source_row', 'load_state']
                cohort = frame[cohort_columns]
                if common is None:
                    common = cohort.copy()
                elif not common.equals(cohort):
                    raise ValueError(f'Model cohorts or GT differ in {role}: {name}')
                gt = frame[[f'gt_{axis}_mN' for axis in AXES]].to_numpy()
                pred = frame[[f'pred_{axis}_mN' for axis in AXES]].to_numpy()
                values = metrics(gt, pred)
                row = {'dataset_role': role, 'model': name, 'samples': values['samples']}
                row.update({f'{metric}_{axis}_mN': values[f'{metric}_{axis}_mN']
                            for metric in ('rmse', 'mae') for axis in AXES})
                records.append(row)
                diagnostic = {'dataset_role': role, 'model': name, 'all': values,
                              'by_load_state': {}, 'by_source_file': {}}
                for state in ('loaded', 'unloaded', 'uncertain'):
                    keep = (frame['load_state'] == state).to_numpy()
                    if keep.any():
                        diagnostic['by_load_state'][state] = metrics(gt[keep], pred[keep])
                for file_id in frame['file_id'].unique():
                    keep = (frame['file_id'] == file_id).to_numpy()
                    diagnostic['by_source_file'][str(int(file_id))] = metrics(gt[keep], pred[keep])
                details.append(diagnostic)
                if role == 'validation':
                    match = comparison[(comparison['mode'] == 'masked') &
                                       (comparison['force_model'] == name.lower()) &
                                       (comparison['location_model'] == 'mlp')]
                    if len(match) != 1:
                        raise ValueError(f'Expected one frozen validation comparison for {name}')
                    for metric in ('rmse', 'mae'):
                        for axis in AXES:
                            difference = abs(values[f'{metric}_{axis}_mN'] - float(match.iloc[0][f'force_{metric}_{axis}_mN']))
                            max_validation_difference = max(max_validation_difference, difference)
                            if difference > 1e-8:
                                raise ValueError(f'Validation metric mismatch: {name}, {metric}, {axis}')
                print(f'{role:10s} {name:13s} n={len(frame):6d} RMSE mN: ' +
                      '/'.join(f'{values[f"rmse_{axis}_mN"]:.6f}' for axis in AXES), flush=True)
        if digest(path) != book['sha256']:
            raise ValueError('Workbook changed while metrics were computed')
    run = datetime.now().strftime('%Y%m%d_%H%M%S') + '_axis_rmse'
    report = {'created_at': datetime.now().isoformat(), 'status': 'complete',
              'source_manifest': str(manifest_path), 'workbooks': sources,
              'units': 'mN', 'force_scope': 'ID18 tip',
              'rmse_definition': 'sqrt(mean((prediction_axis - ground_truth_axis)^2)) across exported rows; no offset removal',
              'all_rows': 'All exported force rows, including loaded, unloaded and uncertain; sample-weighted across files.',
              'new_training_or_inference': False, 'existing_model_selection_changed': False,
              'source_workbooks_unchanged': True,
              'validation_axis_rmse_mae_max_difference_from_comparison_mN': max_validation_difference,
              'sources': manifest['sources'], 'diagnostics': details}
    table = pd.DataFrame(records)
    for destination, roles in [('train', ['train', 'validation']), ('predict', ['test'])]:
        selected = table[table['dataset_role'].isin(roles)]
        if selected.empty:
            continue
        folder = ROOT / 'results' / destination / run
        folder.mkdir(parents=True, exist_ok=False)
        selected.to_csv(folder / 'force_axis_metrics.csv', index=False, float_format='%.10f')
        (folder / 'analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        print(f'Saved: {folder}', flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--export-manifest', required=True, type=Path)
    summarize(parser.parse_args().export_manifest)
