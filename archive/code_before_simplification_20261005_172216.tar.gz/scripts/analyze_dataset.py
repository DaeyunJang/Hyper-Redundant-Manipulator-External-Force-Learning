#!/usr/bin/env python3
"""Describe the frozen development split without inspecting test force outcomes."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from hrm_force.data import json_write, sha256
from hrm_force.independent_data import load_config, prepare_data
from hrm_force.independent_engine import fit_scaler


MAGNITUDE_EDGES_N = np.array([0, .1, .2, .5, 1., 2., 5., 10., np.inf])
DIRECTION_NAMES = ["-Fx", "+Fx", "-Fy", "+Fy", "-Fz", "+Fz"]


def condition(path):
    return "static_filename" if "static" in Path(path).stem.lower() else "nonstatic_filename_unspecified"


def safe_quantiles(values, quantiles):
    return np.quantile(values, quantiles, axis=0) if len(values) else None


def force_summary(force):
    force = np.asarray(force, dtype=np.float64).reshape(-1, 3)
    if not len(force):
        return {"rows": 0, "axis_q05_q50_q95_mN": None, "magnitude_q05_q50_q95_mN": None,
                "magnitude_histogram_fraction": [0.] * 8, "dominant_signed_axis_fraction": [0.] * 6}
    magnitude = np.linalg.norm(force, axis=1)
    dominant = np.abs(force).argmax(1)
    categories = dominant * 2 + (force[np.arange(len(force)), dominant] >= 0)
    return {"rows": len(force), "axis_minimum_mN": force.min(0) * 1000,
            "axis_maximum_mN": force.max(0) * 1000,
            "axis_q05_q50_q95_mN": np.quantile(force, [.05, .5, .95], axis=0) * 1000,
            "magnitude_q05_q50_q95_mN": np.quantile(magnitude, [.05, .5, .95]) * 1000,
            "magnitude_maximum_mN": float(magnitude.max() * 1000),
            "magnitude_histogram_fraction": np.histogram(magnitude, MAGNITUDE_EDGES_N)[0] / len(force),
            "dominant_signed_axis_fraction": np.bincount(categories, minlength=6) / len(force),
            "mean_unit_direction": (force / np.maximum(magnitude[:, None], 1e-12)).mean(0)}


def z_summary(values, mean, std, groups):
    if not len(values):
        return {"rows": 0}
    z = (values.astype(np.float64) - mean) / np.maximum(std, 1e-8)
    outside = np.abs(z) > 3
    return {"rows": len(values), "mean_z_per_feature": z.mean(0),
            "median_z_per_feature": np.median(z, axis=0),
            "outside_abs_z3_fraction_per_feature": outside.mean(0),
            "any_abs_z3_fraction": float(outside.any(1).mean()),
            "any_abs_z5_fraction": float((np.abs(z) > 5).any(1).mean()),
            "median_feature_rms_z": float(np.median(np.sqrt(np.square(z).mean(1)))),
            "group_any_abs_z3_fraction": {key: float(outside[:, indices].any(1).mean()) for key, indices in groups.items()}}


def group_indices(columns):
    result = {}
    for index, name in enumerate(columns):
        key = "wire_length" if name.startswith("wire.") else "loadcell_tension" if name.startswith("loadcell.") else "relative_angle" if name.startswith("relative_angle_") else "other"
        result.setdefault(key, []).append(index)
    return result


def descriptive_association(trial, global_std, groups):
    endpoints = trial.endpoints
    states = trial.load_state[endpoints]
    loaded, unloaded = trial.x[endpoints[states == 1]], trial.x[endpoints[states == 0]]
    if len(loaded) < 20 or len(unloaded) < 20:
        return {"available": False, "loaded_rows": len(loaded), "unloaded_rows": len(unloaded)}
    difference = loaded.mean(0, dtype=np.float64) - unloaded.mean(0, dtype=np.float64)
    standardized = difference / np.maximum(global_std, 1e-8)
    return {"available": True, "loaded_rows": len(loaded), "unloaded_rows": len(unloaded),
            "loaded_minus_unloaded_mean_raw_units": difference,
            "global_train_std_units": standardized,
            "group_rms_standardized_mean_difference": {key: float(np.sqrt(np.square(standardized[indices]).mean()))
                                                        for key, indices in groups.items()},
            "interpretation": "within-file association; NOT external-force deformation; pose, motion and load schedule may confound"}


def inspect_static_id3_signal(path):
    """Record a specifically observed measurement anomaly, without changing data."""
    import pandas as pd
    frame = pd.read_csv(path, usecols=["relative_angle_1", "tilt_relative_01_rad"])
    angle = frame["relative_angle_1"].to_numpy(float)
    finite = np.isfinite(angle)
    adjacent = finite[1:] & finite[:-1]
    return {"file": str(Path(path).relative_to(ROOT)), "sha256": sha256(Path(path)),
            "signal": "relative_angle_1", "rows": len(angle),
            "minimum_rad": float(np.min(angle[finite])), "maximum_rad": float(np.max(angle[finite])),
            "adjacent_sign_flip_fraction": float(np.mean((angle[1:] * angle[:-1] < 0)[adjacent])),
            "median_absolute_adjacent_step_rad": float(np.median(np.abs(np.diff(angle))[adjacent])),
            "maximum_difference_from_original_tilt_relative_01_rad": float(np.max(np.abs(angle - frame["tilt_relative_01_rad"].to_numpy(float)))),
            "interpretation": "Observed alternating-angle anomaly candidate; cause unverified. Preserved in the frozen validation; no correction or exclusion."}


def angle_signal_timing(trial, columns, gap_factor):
    delta_ns = np.diff(trial.timestamps)
    positive = delta_ns[delta_ns > 0]
    median_ns = float(np.median(positive)) if len(positive) else float("nan")
    good_time = (delta_ns > 0) & (delta_ns <= gap_factor * median_ns)
    usable_pair = trial.input_valid[:-1] & trial.input_valid[1:] & good_time
    channels = {}
    for index, name in enumerate(columns):
        if not name.startswith("relative_angle_"):
            continue
        values = trial.x[:, index].astype(np.float64)
        valid = trial.input_valid & np.isfinite(values)
        pairs = usable_pair & np.isfinite(values[:-1]) & np.isfinite(values[1:])
        steps = np.abs(np.diff(values))[pairs]
        rates = steps / (delta_ns[pairs] * 1e-9)
        channels[name] = {"valid_rows": int(valid.sum()), "valid_contiguous_pairs": int(pairs.sum()),
                          "value_q05_q50_q95_rad": safe_quantiles(values[valid], [.05, .5, .95]),
                          "adjacent_sign_flip_fraction": float(np.mean((values[:-1] * values[1:] < 0)[pairs])) if pairs.any() else None,
                          "absolute_step_q50_q95_max_rad": [float(np.median(steps)), float(np.quantile(steps, .95)), float(np.max(steps))] if len(steps) else None,
                          "apparent_absolute_rate_q50_q95_rad_s": safe_quantiles(rates, [.5, .95])}
    return {"timestamp_policy": "loader-validated/recovered relative timestamps, unchanged raw sample order",
            "median_interval_ms": median_ns / 1e6, "nominal_sample_rate_hz": 1e9 / median_ns,
            "positive_interval_q05_q50_q95_max_ms": [float(np.quantile(positive, q) / 1e6) for q in (.05, .5, .95, 1)],
            "nonincreasing_step_count": int((delta_ns <= 0).sum()),
            "gap_factor": gap_factor, "gap_step_count": int((delta_ns > gap_factor * median_ns).sum()),
            "channels": channels,
            "interpretation": "descriptive measurement transitions on adjacent valid rows; apparent rates are not verified physical joint velocities"}


def rank_angle_steps(trial_summaries):
    ranking = []
    for item in trial_summaries:
        for channel, stats in item["angle_signal_timing"]["channels"].items():
            if stats["absolute_step_q50_q95_max_rad"] is not None:
                ranking.append({"file": item["file"], "id": item["id"], "role": item["role"], "channel": channel,
                                "median_absolute_step_rad": stats["absolute_step_q50_q95_max_rad"][0],
                                "adjacent_sign_flip_fraction": stats["adjacent_sign_flip_fraction"]})
    return sorted(ranking, key=lambda item: item["median_absolute_step_rad"], reverse=True)[:18]


def pooled_role(trials, indices, scaler, groups):
    chosen = [trials[index] for index in indices]
    x = np.concatenate([item.x[item.input_valid] for item in chosen])
    endpoints = [(item, item.endpoints) for item in chosen]
    states = np.concatenate([item.load_state[rows] for item, rows in endpoints])
    force = np.concatenate([item.force[rows[item.load_state[rows] == 1]] for item, rows in endpoints])
    return {"trial_count": len(indices), "valid_input_rows": len(x), "eligible_endpoints": len(states),
            "conditions": {key: sum(condition(item.path) == key for item in chosen)
                           for key in ("static_filename", "nonstatic_filename_unspecified")},
            "load_state_count": {str(value): int((states == value).sum()) for value in (-2, -1, 0, 1)},
            "load_state_fraction": {str(value): float((states == value).mean()) for value in (-2, -1, 0, 1)},
            "loaded_force": force_summary(force),
            "input_relative_to_global_train": z_summary(x, scaler["x_mean"], scaler["x_std"], groups)}, x


def range_similarity(train, validation):
    first, second = train["loaded_force"], validation["loaded_force"]
    if not first["rows"] or not second["rows"]:
        return {"available": False}
    a, b = np.asarray(first["axis_q05_q50_q95_mN"]), np.asarray(second["axis_q05_q50_q95_mN"])
    intersection = np.maximum(0, np.minimum(a[2], b[2]) - np.maximum(a[0], b[0]))
    union = np.maximum(a[2], b[2]) - np.minimum(a[0], b[0])
    return {"available": True, "axis_central90_interval_jaccard": intersection / np.maximum(union, 1e-12),
            "magnitude_histogram_overlap": float(np.minimum(first["magnitude_histogram_fraction"], second["magnitude_histogram_fraction"]).sum()),
            "dominant_direction_histogram_overlap": float(np.minimum(first["dominant_signed_axis_fraction"], second["dominant_signed_axis_fraction"]).sum()),
            "validation_to_train_median_magnitude_ratio": float(second["magnitude_q05_q50_q95_mN"][1] / first["magnitude_q05_q50_q95_mN"][1])}


def figure(result, output):
    ids = np.arange(1, 19)
    rows = result["by_id"]
    fig, axes = plt.subplots(3, 2, figsize=(16, 15))
    width = .34
    for offset, part, color in ((-.18, "train", "tab:blue"), (.18, "validation", "tab:orange")):
        static = [rows[str(i)][part]["conditions"]["static_filename"] for i in ids]
        other = [rows[str(i)][part]["conditions"]["nonstatic_filename_unspecified"] for i in ids]
        axes[0, 0].bar(ids + offset, other, width, color=color, label=part + ": other filename")
        axes[0, 0].bar(ids + offset, static, width, bottom=other, color=color, hatch="//", alpha=.5, label=part + ": static filename")
        loaded = [rows[str(i)][part]["load_state_fraction"]["1"] * 100 for i in ids]
        axes[0, 1].plot(ids, loaded, "o-", color=color, label=part)
    axes[0, 0].set_title("Independent trials / recording conditions")
    axes[0, 0].set_ylabel("Trial count")
    axes[0, 0].legend(fontsize=8, ncol=2)
    axes[0, 1].set_title("Loaded fraction at usable endpoints")
    axes[0, 1].set_ylabel("Threshold-defined loaded [%]")
    axes[0, 1].legend()
    for offset, key, label in ((-.18, "input_relative_to_global_train", "Global train scale"),
                               (.18, "input_relative_to_same_id_train", "Same-ID train scale")):
        fractions = [rows[str(i)]["validation"][key]["any_abs_z3_fraction"] * 100 for i in ids]
        axes[1, 0].bar(ids + offset, fractions, width, label=label)
    axes[1, 0].set_title("Validation input shift: any feature outside train ±3 std")
    axes[1, 0].set_ylabel("Valid input rows [%]")
    axes[1, 0].legend(fontsize=9)
    for offset, part, color in ((-.15, "train", "tab:blue"), (.15, "validation", "tab:orange")):
        q = np.array([rows[str(i)][part]["loaded_force"]["magnitude_q05_q50_q95_mN"] for i in ids])
        axes[1, 1].errorbar(ids + offset, q[:, 1], yerr=np.stack([q[:, 1]-q[:, 0], q[:, 2]-q[:, 1]]),
                           fmt="o", color=color, capsize=2, label=part)
    axes[1, 1].set_title("Loaded force magnitude: median and 5–95% range")
    axes[1, 1].set_ylabel("Force magnitude [mN]")
    axes[1, 1].legend()
    matrix = np.array([rows[str(i)]["validation"]["input_relative_to_same_id_train"]["mean_z_per_feature"] for i in ids])
    im = axes[2, 0].imshow(np.clip(matrix, -5, 5), aspect="auto", cmap="coolwarm", vmin=-5, vmax=5)
    axes[2, 0].set_yticks(np.arange(18), ids)
    feature_labels = [f"X{i + 1}" for i in range(len(result["feature_columns"]))]
    for group, indices in result["feature_groups"].items():
        prefix = {"wire_length": "W", "loadcell_tension": "L", "relative_angle": "A"}.get(group, "X")
        for number, index in enumerate(indices, 1):
            feature_labels[index] = f"{prefix}{number}"
    axes[2, 0].set_xticks(np.arange(len(feature_labels)), feature_labels, rotation=90, fontsize=7)
    axes[2, 0].set_ylabel("Contact ID")
    axes[2, 0].set_title("Validation mean in same-ID train std units (clipped ±5)")
    fig.colorbar(im, ax=axes[2, 0], fraction=.025)
    for key, label in (("magnitude_histogram_overlap", "Magnitude bins"), ("dominant_direction_histogram_overlap", "Dominant signed axis")):
        axes[2, 1].plot(ids, [rows[str(i)]["force_range_similarity"][key] for i in ids], "o-", label=label)
    axes[2, 1].set_ylim(0, 1.05)
    axes[2, 1].set_title("Train–validation loaded-force distribution overlap")
    axes[2, 1].set_ylabel("Histogram overlap (1 = identical bin shares)")
    axes[2, 1].legend()
    for index, ax in enumerate(axes.flat):
        if index != 4:
            ax.set_xticks(ids)
            ax.set_xlabel("Contact ID")
            ax.grid(axis="y", alpha=.2)
    fig.suptitle("Frozen development split diagnostics — test outcomes excluded\n"
                 "Recording condition and force range can confound apparent contact-location performance", fontsize=15)
    fig.tight_layout(rect=(0, 0, 1, .96))
    fig.savefig(output / "dataset.png", dpi=150)
    plt.close(fig)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--train-run", required=True)
    args = parser.parse_args(argv)
    run = Path(args.train_run).resolve()
    output = run / "diagnostics"
    output.mkdir(parents=True, exist_ok=True)
    if (output / "dataset.json").exists() or (output / "dataset.png").exists():
        raise FileExistsError("Dataset diagnostics already exist; do not overwrite")
    cfg = load_config(args.config)
    prepared = prepare_data(cfg, None)
    import json
    frozen_audit = json.loads((run / "data_audit.json").read_text())
    if prepared["split"] != frozen_audit["split"] or [t.sha256 for t in prepared["trials"]] != [t["sha256"] for t in frozen_audit["trials"]]:
        raise ValueError("Current source files/split do not match the frozen training run")
    trials, split = prepared["trials"], prepared["split"]
    scale = fit_scaler(trials, split["train"], "all")
    columns = prepared["audit"]["feature_columns"]
    groups = group_indices(columns)
    result = {"analysis": "descriptive_frozen_development_dataset", "training_run": str(run),
              "source_and_split_match_training_run": True, "feature_columns": columns,
              "feature_groups": groups, "global_train_scaler": scale,
              "force_unit": "mN in reported summaries, N in source loader",
              "magnitude_histogram_edges_N": [0, .1, .2, .5, 1, 2, 5, 10, "inf"],
              "direction_histogram_names": DIRECTION_NAMES,
              "test_usage": "file identity and validity metadata only; no test force/input distribution analysis",
              "threshold_calibration_sha256": prepared["calibration"]["sha256"],
              "excluded_files": prepared["audit"].get("excluded_files", []), "by_id": {}, "trials": [],
              "limitations": [
                  "Loaded states are calibration-threshold labels; cross-session tare transfer uncertainty remains.",
                  "Static/nonstatic labels come from filenames; other filenames do not establish dynamic protocol.",
                  "CSV trials are held out whole, but posture/motion and force-direction ranges can differ across roles.",
                  "Per-feature |z|>3 is a descriptive train-scale exceedance, not a calibrated anomaly probability.",
                  "Many features/rows are correlated; any-feature exceedance rises with feature count.",
                  "Loaded-minus-unloaded averages are confounded by pose, motion, load timing and sensor bias; they do not measure causal external-force deformation.",
                  "No matched motor-position/pose comparison is performed; base observability cannot be decided from these associations alone.",
                  "Histogram overlap depends on the stated fixed binning; it is not a physical identifiability score.",
                  "Development diagnostics do not alter the frozen split, calibration, model selection or source files.",
              ]}
    for segment in range(1, 19):
        by_role = {role: [index for index in split[role] if trials[index].effective_id == segment]
                   for role in ("train", "validation")}
        entry, arrays = {}, {}
        for role, indices in by_role.items():
            entry[role], arrays[role] = pooled_role(trials, indices, scale, groups)
            entry[role]["files"] = [str(Path(trials[index].path).relative_to(ROOT)) for index in indices]
        mean, std = arrays["train"].mean(0, dtype=np.float64), arrays["train"].std(0, dtype=np.float64)
        entry["same_id_train_mean"] = mean
        entry["same_id_train_std"] = std
        entry["same_id_near_constant_features"] = [columns[i] for i in np.flatnonzero(std < 1e-8)]
        entry["validation"]["input_relative_to_same_id_train"] = z_summary(arrays["validation"], mean, std, groups)
        entry["force_range_similarity"] = range_similarity(entry["train"], entry["validation"])
        result["by_id"][str(segment)] = entry
    for role in ("train", "validation"):
        for index in split[role]:
            t = trials[index]
            result["trials"].append({"file": str(Path(t.path).relative_to(ROOT)), "sha256": t.sha256,
                                      "id": t.effective_id, "role": role, "condition": condition(t.path),
                                      "rows": len(t.x), "eligible_endpoints": len(t.endpoints),
                                      "input_relative_to_global_train": z_summary(t.x[t.input_valid], scale["x_mean"], scale["x_std"], groups),
                                      "angle_signal_timing": angle_signal_timing(t, columns, cfg["gap_factor"]),
                                      "loaded_unloaded_association": descriptive_association(t, scale["x_std"], groups)})
    result["base_vs_rest_association"] = {}
    for named_condition in ("static_filename", "nonstatic_filename_unspecified"):
        result["base_vs_rest_association"][named_condition] = {}
        for label, allowed in (("id1_to_4", range(1, 5)), ("id5_to_18", range(5, 19))):
            selected = [item for item in result["trials"] if item["id"] in allowed and item["condition"] == named_condition
                        and item["loaded_unloaded_association"]["available"]]
            result["base_vs_rest_association"][named_condition][label] = {
                "trial_count": len(selected), "aggregation": "median of trial-level descriptive RMS differences; equal trial weight",
                "group_median_standardized_mean_difference": {key: float(np.median([item["loaded_unloaded_association"]["group_rms_standardized_mean_difference"][key]
                                                                                   for item in selected])) if selected else None for key in groups}}
    result["test_metadata_only"] = [{key: trials[index].info.get(key) for key in
                                     ("path", "sha256", "rows", "effective_id", "input_invalid_rows", "force_invalid_rows", "window_endpoints", "prediction_endpoints", "timestamp_repair")}
                                    for index in split["test"]]
    result["overall_development"] = {role: pooled_role(trials, split[role], scale, groups)[0]
                                      for role in ("train", "validation")}
    result["largest_median_angle_steps"] = rank_angle_steps(result["trials"])
    result["observed_signal_checks"] = [inspect_static_id3_signal(trials[index].path)
                                         for index in split["validation"]
                                         if trials[index].effective_id == 3 and condition(trials[index].path) == "static_filename"]
    figure(result, output)
    if any(sha256(Path(t.path)) != t.sha256 for t in trials):
        raise RuntimeError("Source changed during analysis")
    result["source_hashes_unchanged_after_analysis"] = True
    json_write(output / "dataset.json", result)
    print(output)
    for segment, entry in result["by_id"].items():
        print("ID", segment, "train/val", entry["train"]["trial_count"], entry["validation"]["trial_count"],
              "val_any_abs_z3_global/id", round(entry["validation"]["input_relative_to_global_train"]["any_abs_z3_fraction"], 4),
              round(entry["validation"]["input_relative_to_same_id_train"]["any_abs_z3_fraction"], 4),
              "force_overlap", entry["force_range_similarity"]["magnitude_histogram_overlap"],
              entry["force_range_similarity"]["dominant_direction_histogram_overlap"])


if __name__ == "__main__":
    main()
