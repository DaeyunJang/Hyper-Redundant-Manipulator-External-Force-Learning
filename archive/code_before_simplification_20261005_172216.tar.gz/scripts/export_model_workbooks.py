#!/usr/bin/env python3
"""Export frozen force/ID models as separate Excel model sheets."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hrm_force.runtime import ensure_driver_runtime
ensure_driver_runtime()
from hrm_force.excel_export import main

if __name__ == '__main__':
    main()
