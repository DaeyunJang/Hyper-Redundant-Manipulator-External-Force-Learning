#!/usr/bin/env python3
"""Isolated CPU/CUDA convolution backend timings; no training data or model edits.

Each child builds identical seeded weights and inputs, compares output/parameter
gradients with a float64 CPU reference, and times a few forward/backward steps.
Invoke using ``bash scripts/hrm_python.sh scripts/benchmark_convolution.py``.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

MODES = ("cudnn_deterministic", "cudnn_autotune", "native_cuda", "cpu")


def worker(args):
    import torch
    from torch.nn import functional as F
    from hrm_force.independent_models import build_branch

    torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    gpu = args.mode != "cpu"
    device = torch.device("cuda" if gpu else "cpu")
    torch.backends.cudnn.enabled = args.mode != "native_cuda"
    torch.backends.cudnn.deterministic = args.mode == "cudnn_deterministic"
    torch.backends.cudnn.benchmark = args.mode == "cudnn_autotune"
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    net_cpu = build_branch(args.model, 26, 30, 18)
    x_cpu = torch.randn(args.batch_size, 30, 26)
    target_cpu = torch.randint(18, (args.batch_size,))
    reference = copy.deepcopy(net_cpu).double()
    ref_out = reference(x_cpu.double())
    ref_loss = F.cross_entropy(ref_out, target_cpu)
    ref_loss.backward()
    reference_grads = {name: parameter.grad.detach().clone() for name, parameter in reference.named_parameters()}
    net = net_cpu.to(device)
    x, target = x_cpu.to(device), target_cpu.to(device)
    if gpu:
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()

    def step():
        net.zero_grad(set_to_none=True)
        out = net(x)
        loss = F.cross_entropy(out, target)
        loss.backward()
        return out, loss

    cold_start = time.perf_counter()
    output, loss = step()
    if gpu:
        torch.cuda.synchronize()
    cold_seconds = time.perf_counter() - cold_start
    output_error = float((output.detach().cpu().double() - ref_out.detach()).abs().max())
    gradient_errors = {
        name: float((parameter.grad.detach().cpu().double() - reference_grads[name]).abs().max())
        for name, parameter in net.named_parameters()
    }
    gradient_error = max(gradient_errors.values())
    gradients_finite = all(bool(parameter.grad.isfinite().all()) for parameter in net.parameters())
    for _ in range(args.warmup):
        step()
    if gpu:
        torch.cuda.synchronize()
    durations = []
    for _ in range(args.steps):
        before = time.perf_counter()
        step()
        if gpu:
            torch.cuda.synchronize()
        durations.append(time.perf_counter() - before)
    return {
        "model": args.model, "backend": args.mode, "device": str(device),
        "gpu": torch.cuda.get_device_name() if gpu else None,
        "torch": str(torch.__version__), "cuda": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "shape": [args.batch_size, 30, 26], "output_classes": 18,
        "seed": args.seed, "threads": args.threads,
        "cudnn_enabled": torch.backends.cudnn.enabled,
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
        "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cold_seconds": cold_seconds, "step_seconds": durations,
        "median_step_seconds": statistics.median(durations),
        "maximum_gpu_memory_bytes": torch.cuda.max_memory_allocated() if gpu else None,
        "reference": "CPU float64, identical float32-initialized weights and identical inputs",
        "loss": float(loss.detach().cpu()), "reference_loss": float(ref_loss.detach()),
        "maximum_output_absolute_error": output_error,
        "maximum_parameter_gradient_absolute_error": gradient_error,
        "parameter_gradient_absolute_errors": gradient_errors,
        "all_gradients_finite": gradients_finite,
        "optimizer_updates": 0,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--model", choices=["tcn", "residual_tcn"])
    parser.add_argument("--mode", choices=MODES)
    parser.add_argument("--models", nargs="+", default=["tcn", "residual_tcn"])
    parser.add_argument("--modes", nargs="+", choices=MODES, default=list(MODES))
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--steps", type=int, default=3)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--threads", type=int, default=4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--timeout", type=float, default=120)
    parser.add_argument("--output")
    args = parser.parse_args()
    if args.worker:
        print(json.dumps(worker(args)), flush=True)
        return
    output = Path(args.output) if args.output else ROOT / ".runtime" / ("benchmark_convolution_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".json")
    output.parent.mkdir(parents=True, exist_ok=True)
    results = {"created_at": datetime.now().astimezone().isoformat(), "benchmark_only": True,
               "source_files_modified": False, "independent_process_per_case": True, "results": []}
    print(f"Result: {output}", flush=True)
    for model in args.models:
        for mode in args.modes:
            print(f"Starting {model}/{mode}", flush=True)
            command = [sys.executable, str(Path(__file__).resolve()), "--worker", "--model", model,
                       "--mode", mode, "--batch-size", str(args.batch_size), "--steps", str(args.steps),
                       "--warmup", str(args.warmup), "--threads", str(args.threads), "--seed", str(args.seed)]
            try:
                completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=args.timeout)
                if completed.returncode:
                    entry = {"model": model, "backend": mode, "error": completed.stderr, "returncode": completed.returncode}
                else:
                    entry = json.loads(completed.stdout.strip().splitlines()[-1])
                    print(f"{model}/{mode}: {entry['median_step_seconds'] * 1000:.3f} ms, "
                          f"out error {entry['maximum_output_absolute_error']:.3g}, "
                          f"grad error {entry['maximum_parameter_gradient_absolute_error']:.3g}", flush=True)
            except subprocess.TimeoutExpired:
                entry = {"model": model, "backend": mode, "error": "timeout", "timeout_seconds": args.timeout}
                print(f"{model}/{mode}: timeout", flush=True)
            results["results"].append(entry)
            output.write_text(json.dumps(results, indent=2) + "\n")
    print(f"Complete: {output}", flush=True)


if __name__ == "__main__":
    main()
